"""
kordialmabotu.bot - Kordinat Alma Botu (Coordinate Getting Bot)

Sonoyuncu sunucusunda hesapları otomatik açar, giriş yapar, dünyaya girer ve
koordinatları ekrandan okuyup dosyaya kaydeder. Hata/Ban/Ölü ekranlarını izler.
F8 tuşu ile başlatılır/durdurulur.
"""

import os
import sys
import io
import re
import json
import time
import threading
import subprocess
import traceback
from datetime import datetime

import cv2
import keyboard
import mss
import pyautogui
import pyperclip
import numpy as np


# ---------------------------------------------------------------------------
# stdout/stderr encoding safety (utf-8 with replace)
# ---------------------------------------------------------------------------
try:
    if sys.stdout is not None and not getattr(sys.stdout, 'closed', True):
        if isinstance(sys.stdout, io.TextIOWrapper):
            sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except (AttributeError, ValueError, OSError):
    pass
try:
    if sys.stderr is not None and not getattr(sys.stderr, 'closed', True):
        if isinstance(sys.stderr, io.TextIOWrapper):
            sys.stderr.reconfigure(encoding='utf-8', errors='replace')
except (AttributeError, ValueError, OSError):
    pass


# ---------------------------------------------------------------------------
# pyautogui safety
# ---------------------------------------------------------------------------
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.1


# ---------------------------------------------------------------------------
# Module-level path setup
# ---------------------------------------------------------------------------
USER_PROFILE = os.environ.get('USERPROFILE', '')
possible_base_dirs = []
exe_dir = os.path.dirname(sys.executable)
argv_dir = os.path.dirname(sys.argv[0]) if sys.argv and sys.argv[0] else ''
cwd = os.getcwd()
test_dir = os.path.join(cwd, 'test')

possible_base_dirs.append(exe_dir)
if argv_dir and argv_dir not in possible_base_dirs:
    possible_base_dirs.append(argv_dir)
if cwd not in possible_base_dirs:
    possible_base_dirs.append(cwd)
if test_dir not in possible_base_dirs:
    possible_base_dirs.append(test_dir)

# BASE_DIR determination: find a directory containing 'kordinatalma' subfolder,
# preferring a non-temp dir.
def _is_temp_dir(path):
    path_upper = path.upper()
    temp_paths = [
        os.environ.get('TEMP', ''),
        os.environ.get('TMP', ''),
        os.path.join(os.environ.get('USERPROFILE', ''), 'AppData', 'Local', 'Temp'),
    ]
    for temp_path in temp_paths:
        if temp_path and temp_path.upper() in path_upper:
            return True
    return False


BASE_DIR = None
# First pass: prefer non-temp dirs that have the kordinatalma subfolder
for d in possible_base_dirs:
    test_kordinatalma = os.path.join(d, 'kordinatalma')
    if os.path.isdir(test_kordinatalma) and not _is_temp_dir(d):
        BASE_DIR = d
        break
# Fallback: any dir with kordinatalma subfolder
if BASE_DIR is None:
    for d in possible_base_dirs:
        test_kordinatalma = os.path.join(d, 'kordinatalma')
        if os.path.isdir(test_kordinatalma):
            BASE_DIR = d
            break
# Last resort: first dir
if BASE_DIR is None and possible_base_dirs:
    BASE_DIR = possible_base_dirs[0]
elif BASE_DIR is None:
    BASE_DIR = cwd

MODULE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FOLDER = os.path.join(BASE_DIR, 'data')
KORDINATALMA_FOLDER = os.path.join(BASE_DIR, 'kordinatalma')
if not os.path.exists(KORDINATALMA_FOLDER):
    try:
        os.makedirs(KORDINATALMA_FOLDER, exist_ok=True)
    except OSError:
        pass

# Account/coords/log file paths
SIFRELER_DOSYA = os.path.join(KORDINATALMA_FOLDER, 'sifreler.txt')
HESAPLAR_DOSYA = os.path.join(KORDINATALMA_FOLDER, 'hesaplar.txt')
KORDI_DOSYA = os.path.join(KORDINATALMA_FOLDER, 'kordinatlar.txt')
BAN_DOSYA = os.path.join(KORDINATALMA_FOLDER, 'ban.txt')
HATA_DOSYA = os.path.join(KORDINATALMA_FOLDER, 'hata.txt')

# Image paths for screen detection
IMAGES = {
    'death': os.path.join(KORDINATALMA_FOLDER, 'death.png'),
    'ban': os.path.join(KORDINATALMA_FOLDER, 'ban.png'),
    'hata': os.path.join(KORDINATALMA_FOLDER, 'hata.png'),
    'giris': os.path.join(KORDINATALMA_FOLDER, 'giris.png'),
    'oyna': os.path.join(KORDINATALMA_FOLDER, 'oyna.png'),
    'multi': os.path.join(KORDINATALMA_FOLDER, 'multi.png'),
}

# Sonoyuncu client executable path
SONOYUNCU_CLIENT = os.path.join(
    os.environ.get('USERPROFILE', ''),
    'AppData', 'Roaming', '.sonoyuncu', 'sonoyuncuclient.exe'
)

# Coords for launcher/server/world UI clicks
COORDS = {
    'username': (730, 410),
    'password': (785, 482),
    'giris': (789, 635),
    'odak': (500, 300),
    'coklu': (798, 519),
    'sunucu': (774, 343),
    'son_tik': (666, 475),
    'oyun_modu': (745, 391),
    'respawn': (798, 523),
}

# Worlds list: (name, x, y) for world selection clicks
DUNYALAR = [
    ('Sancak', 666, 475),
    ('Yakamoz', 690, 463),
    ('Avrasya', 732, 479),
    ('Pruva', 767, 466),
    ('Velena', 797, 460),
    ('Flador', 836, 465),
    ('Astra', 908, 482),
]

# Screen region for coordinate OCR (top-left and bottom-right)
TOP = 412
BOTTOM = 621
LEFT = 273
RIGHT = 378

# OCR threshold for template matching
OCR_THRESHOLD = 0.08

# Digit templates for read_number / find_password (loaded lazily)
templates = {}
minus_path = os.path.join(KORDINATALMA_FOLDER, 'minus.png')
for _i in range(0, 10):
    _path = os.path.join(KORDINATALMA_FOLDER, str(_i) + '.png')
    if os.path.exists(_path):
        templates[str(_i)] = cv2.imread(_path, cv2.IMREAD_GRAYSCALE)
if os.path.exists(minus_path):
    templates['-'] = cv2.imread(minus_path, cv2.IMREAD_GRAYSCALE)


# ---------------------------------------------------------------------------
# Safe printing
# ---------------------------------------------------------------------------
def safe_print(*args, **kwargs):
    """Güvenli print fonksiyonu - stdout/stderr kapalıysa hata vermez"""
    try:
        if os.environ.get('DEBUG_RES'):
            for arg in args:
                print('[DEBUG]', arg, file=sys.stderr, flush=True)
        else:
            print(*args, **kwargs)
    except (ValueError, OSError, AttributeError):
        pass


# ---------------------------------------------------------------------------
# Client check
# ---------------------------------------------------------------------------
def is_client_running():
    """Client'ın çalışıp çalışmadığını kontrol eder"""
    for _ in range(0, 5):
        try:
            result = subprocess.run(
                ['tasklist', '/FI', 'IMAGENAME eq javaw.exe'],
                capture_output=True, text=True,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            if 'javaw.exe' in (result.stdout or ''):
                return True
        except Exception as e:
            _ = e
            safe_print('Client Check Error (Ignored): ', e)
        time.sleep(1.5)
    return False


# ---------------------------------------------------------------------------
# Safe image locate
# ---------------------------------------------------------------------------
def safe_locate(image_path, confidence):
    """pyautogui.locateOnScreen wrapped in try/except"""
    try:
        result = pyautogui.locateOnScreen(
            image_path, confidence=confidence, grayscale=True
        )
        return result
    except Exception as e:
        _ = e
        return None


# ---------------------------------------------------------------------------
# Screen state detectors
# ---------------------------------------------------------------------------
def is_death_screen(confidence):
    """Ölüm ekranı mı kontrol et"""
    return safe_locate(IMAGES['death'], confidence)


def is_ban_screen(confidence):
    """Ban ekranı mı kontrol et"""
    return safe_locate(IMAGES['ban'], confidence)


def is_hata_screen(confidence):
    """Hata ekranı mı kontrol et"""
    return safe_locate(IMAGES['hata'], confidence)


# ---------------------------------------------------------------------------
# OCR: read a number from image using cv2 template matching
# ---------------------------------------------------------------------------
def read_number(img):
    """Read a number from image (OCR via cv2 template matching)"""

    def process_with_threshold(bin_img):
        detections = []
        result = ''
        last_x = -9999
        for char, tpl in templates.items():
            if tpl is None:
                continue
            th, tw = tpl.shape[:2]
            h_img, w_img = bin_img.shape[:2]
            if tw > w_img or th > h_img:
                continue
            # '8' gets more scale candidates than other digits
            if char == '8':
                scales = np.linspace(0.6, 1.5, 12)
            else:
                scales = np.linspace(0.7, 1.3, 9)
            for scale in scales:
                t = cv2.resize(tpl, (max(1, int(tw * scale)), max(1, int(th * scale))))
                if t.shape[0] > h_img or t.shape[1] > w_img:
                    continue
                res = cv2.matchTemplate(bin_img, t, cv2.TM_CCOEFF_NORMED)
                yloc, xloc = np.where(res >= OCR_THRESHOLD)
                for x, y in zip(xloc, yloc):
                    score = float(res[y, x])
                    detections.append((char, int(x), score, t.shape[1]))
        detections.sort(key=lambda c: c[1])
        for char, x, score, width in detections:
            if x - last_x < width * 0.6:
                continue
            result += char
            last_x = x
        return result

    processed_img = cv2.threshold(img, 180, 255, cv2.THRESH_BINARY)[1]
    processed_img = cv2.adaptiveThreshold(
        img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
    )
    return process_with_threshold(processed_img)


# ---------------------------------------------------------------------------
# Get coordinates from screen once
# ---------------------------------------------------------------------------
def get_coordinates_once():
    """Ekranın koordinat panelinden X, Y, Z değerlerini bir kez oku"""
    try:
        with mss.mss() as sct:
            screen = np.array(sct.grab(sct.monitors[1]))
    except Exception:
        return (None, None, None)
    gray = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)
    panel = gray[TOP:BOTTOM, LEFT:RIGHT]
    h = panel.shape[0] if panel.size > 0 else 0
    if h == 0:
        return (None, None, None)
    # Try reading the panel as a whole line of text
    line = read_number(panel)
    line = line.replace('--', '-')
    line = re.sub(r'[^-0-9]', '', line)
    # Split into X, Y, Z by '-' separator (negative coords start with -)
    raw_X = line
    raw_Y = line
    raw_Z = line
    clean_X = raw_X
    clean_Y = raw_Y
    clean_Z = raw_Z
    return (clean_X, clean_Y, clean_Z)


# ---------------------------------------------------------------------------
# Save coordinates to JSON file
# ---------------------------------------------------------------------------
def save_coordinates(account, world, x, y, z):
    """Koordinatları JSON dosyasına kaydet"""
    try:
        with open(KORDI_DOSYA, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception:
        data = {}
    data.setdefault(account, {})
    data[account].setdefault('x', []).append(x)
    data[account].setdefault('y', []).append(y)
    data[account].setdefault('w', []).append(world)
    with open(KORDI_DOSYA, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)
    with open(KORDI_DOSYA, 'a', encoding='utf-8') as f:
        f.write(' | ' + datetime.now().strftime('%d-%m %H:%M') + '\n')


# ---------------------------------------------------------------------------
# Get next account from hesaplar.txt
# ---------------------------------------------------------------------------
def get_next_account():
    """Bir sonraki hesabı al - Birden fazla yerde arama yapar"""
    safe_print('[DEBUG] get_next_account() çağrıldı')
    safe_print('[DEBUG] HESAPLAR_DOSYA: ', HESAPLAR_DOSYA)
    safe_print('[DEBUG] Dosya var mı: ', os.path.exists(HESAPLAR_DOSYA))
    safe_print('[DEBUG] sys.frozen: ', getattr(sys, 'frozen', False))

    def is_temp_dir(path):
        """Geçici dizin olup olmadığını kontrol et"""
        path_upper = path.upper()
        temp_paths = [
            os.environ.get('TEMP', ''),
            os.environ.get('TMP', ''),
            'APPDATA\\LOCAL\\TEMP',
        ]
        for temp_path in temp_paths:
            if temp_path and temp_path.upper() in path_upper:
                return True
        return False

    possible_paths = []
    test_dirs = []
    if 'BASE_DIR' in globals():
        safe_print('[DEBUG] BASE_DIR bulundu: ', BASE_DIR)
        test_dirs.append(BASE_DIR)
    else:
        safe_print('[DEBUG] BASE_DIR henüz tanımlanmamış')

    argv_dir = os.path.dirname(sys.argv[0]) if sys.argv and sys.argv[0] else ''
    safe_print('[DEBUG] sys.argv[0] dizini eklendi: ', argv_dir)
    if argv_dir:
        test_dirs.append(argv_dir)

    cwd_local = os.getcwd()
    safe_print('[DEBUG] Çalışma dizini: ', cwd_local)
    safe_print('[DEBUG] Çalışma dizini eklendi: ', cwd_local)
    test_dirs.append(cwd_local)

    exe_dir_local = os.path.dirname(sys.executable)
    safe_print('[DEBUG] sys.executable dizini: ', exe_dir_local)
    safe_print('[DEBUG] sys.executable dizini eklendi: ', exe_dir_local)
    test_dirs.append(exe_dir_local)

    safe_print('[DEBUG] Toplam ', len(test_dirs), ' dizin bulundu: ', test_dirs)

    # Priority path
    if os.path.exists(HESAPLAR_DOSYA):
        safe_print('[DEBUG] ✓ Öncelikli: ', HESAPLAR_DOSYA, ' (var: ', True, ')')
        possible_paths.append(HESAPLAR_DOSYA)

    # Look for kordinatalma/hesaplar.txt in candidate dirs
    for d in test_dirs:
        kordinatalma_dir = os.path.join(d, 'kordinatalma')
        if os.path.isdir(kordinatalma_dir):
            file_path = os.path.join(kordinatalma_dir, 'hesaplar.txt')
            if file_path not in possible_paths:
                possible_paths.append(file_path)
                safe_print('[DEBUG] Eklendi: ', file_path)

    safe_print('[DEBUG] Denenecek yollar (', len(possible_paths), ' adet):')
    for i, p in enumerate(possible_paths):
        safe_print('[DEBUG]   ', i, '. ', p)

    for file_path in possible_paths:
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                safe_print(
                    '[DEBUG]      İçerik: ',
                    (content[:50] + '...') if len(content) > 50 else content,
                )
                safe_print('[DEBUG] Hesap dosyası bulundu: ', file_path)
                lines = content.splitlines()
                valid_lines = [l for l in lines if l.strip()]
                if not valid_lines:
                    safe_print('[DEBUG] Hesap dosyası boş: ', file_path)
                    continue
                for account_line in valid_lines:
                    account_line = account_line.strip()
                    if ':' in account_line:
                        account, password = account_line.split(':', 1)
                        safe_print(
                            '[DEBUG] Hesap bulundu: ', account,
                            ' (şifre: ', '*' * len(password), ')'
                        )
                        return account, password
                    else:
                        safe_print(
                            '[DEBUG] Hesap bulundu: ', account_line,
                            ' (şifre yok)'
                        )
                        return account_line, None
            except Exception as e:
                safe_print('[DEBUG] ', file_path, ' okuma hatası: ', e)

    safe_print('[DEBUG] Hesap dosyası hiçbir yerde bulunamadı')
    return None, None


# ---------------------------------------------------------------------------
# Remove account from hesaplar.txt
# ---------------------------------------------------------------------------
def remove_account(account):
    """Hesabı dosyadan sil (kullanıcıadı veya kullanıcıadı:şifre formatında)"""
    # Search candidate dirs like get_next_account does
    test_dirs = []
    if 'BASE_DIR' in globals():
        test_dirs.append(BASE_DIR)
    if sys.argv and sys.argv[0]:
        test_dirs.append(os.path.dirname(sys.argv[0]))
    test_dirs.append(os.getcwd())
    test_dirs.append(os.path.dirname(sys.executable))

    paths_to_check = [HESAPLAR_DOSYA]
    for d in test_dirs:
        kordinatalma_dir = os.path.join(d, 'kordinatalma')
        if os.path.isdir(kordinatalma_dir):
            fp = os.path.join(kordinatalma_dir, 'hesaplar.txt')
            if fp not in paths_to_check:
                paths_to_check.append(fp)

    for path in paths_to_check:
        try:
            if not os.path.exists(path):
                continue
            with open(path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            new_lines = []
            for line in lines:
                line_stripped = line.strip()
                if not line_stripped:
                    continue
                account_in_file = (
                    line_stripped.split(':', 1)[0]
                    if ':' in line_stripped else line_stripped
                )
                if account_in_file != account:
                    new_lines.append(line)
            with open(path, 'w', encoding='utf-8') as f:
                f.writelines(new_lines)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Find password (from file, or via OCR on screen)
# ---------------------------------------------------------------------------
def find_password(account):
    """Hesap için şifreyi SIFRELER_DOSYA'dan bul; yoksa ekrandan OCR ile oku"""
    try:
        if os.path.exists(SIFRELER_DOSYA):
            with open(SIFRELER_DOSYA, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if ':' in line:
                        name, _, pwd = line.partition(':')
                        if name == account:
                            m = re.search(r'\d+$', pwd)
                            if m:
                                return m.group()
    except Exception:
        pass

    # OCR path: read digits from screen region using templates
    if not templates:
        safe_print('⚠️ Görsel dosyası bulunamadı: ', 'digit templates')
        return None

    try:
        with mss.mss() as sct:
            screen = np.array(sct.grab(sct.monitors[1]))
        gray = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)
        panel = gray[TOP:BOTTOM, LEFT:RIGHT]
        result = read_number(panel)
        result = result.replace('--', '-')
        result = re.sub(r'[^-0-9]', '', result)
        return result if result else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Wait for an image to appear on screen
# ---------------------------------------------------------------------------
def wait_for_image(img_path, timeout, confidence, stop_event):
    """Bir görselin ekranda görünmesini bekle"""
    if not os.path.exists(img_path):
        safe_print('⚠️ Görsel dosyası bulunamadı: ', img_path)
        return None
    start = time.time()
    check_count = 0
    while time.time() - start < timeout:
        if stop_event is not None and stop_event.is_set():
            return None
        check_count += 1
        loc = safe_locate(img_path, confidence)
        if loc:
            return loc
        safe_print('  Bekleniyor... (', check_count, '/', int(timeout), 's)')
        time.sleep(0.2)
    return None


# ---------------------------------------------------------------------------
# Close the game (kill sonoyuncu + javaw)
# ---------------------------------------------------------------------------
def close_game():
    """Oyun penceresini kapat"""
    os.system('taskkill /f /im sonoyuncuclient.exe >nul 2>&1')
    os.system('taskkill /f /im javaw.exe >nul 2>&1')
    time.sleep(2)


# ---------------------------------------------------------------------------
# Click helper: moveTo + click + release modifier keys
# ---------------------------------------------------------------------------
def click_at(x, y, clicks=1):
    """moveTo + click + release stuck modifier keys"""
    pyautogui.moveTo(x, y, duration=0.3)
    pyautogui.click(clicks=clicks)
    for key in ('shift', 'ctrl', 'alt', 'win'):
        try:
            pyautogui.keyUp(key)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Log to file
# ---------------------------------------------------------------------------
def log_to_file(dosya, text):
    """Dosyaya metin logla"""
    try:
        with open(dosya, 'a', encoding='utf-8') as f:
            f.write(text + '\n')
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Launcher login
# ---------------------------------------------------------------------------
def launcher_login(username, password, stop_event):
    """Launcher'a kullanıcı adı/şifre ile giriş yap"""
    click_at(COORDS['odak'][0], COORDS['odak'][1], clicks=2)

    # Username field
    click_at(COORDS['username'][0], COORDS['username'][1], clicks=2)
    pyautogui.hotkey('ctrl', 'a')
    pyautogui.press('backspace')
    pyperclip.copy(username)
    pyautogui.hotkey('ctrl', 'v')

    # Password field
    click_at(COORDS['password'][0], COORDS['password'][1], clicks=2)
    pyautogui.hotkey('ctrl', 'a')
    pyautogui.press('backspace')
    if password:
        pyperclip.copy(password)
        pyautogui.hotkey('ctrl', 'v')

    # Click login button
    click_at(COORDS['giris'][0], COORDS['giris'][1])
    safe_print(username + ' giriş yapıldı...')

    start_check = time.time()
    while time.time() - start_check < 30:
        if stop_event is not None and stop_event.is_set():
            return False
        # Check hata (error) screen
        if is_hata_screen(0.8):
            safe_print('!!! HATA EKRANI (Giriş) !!!')
            log_to_file(HATA_DOSYA, username + ' - hata.png')
            remove_account(username)
            close_game()
            return False
        # Check ban screen
        if is_ban_screen(0.8):
            safe_print('BAN EKRANI TESPİT EDİLDİ!')
            log_to_file(BAN_DOSYA, username)
            remove_account(username)
            close_game()
            return False
        # Check oyna (play) button -> success
        loc = safe_locate(IMAGES['oyna'], 0.8)
        if loc:
            center = pyautogui.center(loc)
            click_at(center.x, center.y)
            return True
        time.sleep(0.5)
    return False


# ---------------------------------------------------------------------------
# Get coordinates (with retry)
# ---------------------------------------------------------------------------
def get_coordinates():
    """Ekrandan X, Y, Z koordinatlarını oku (retry ile)"""
    for _ in range(5):
        x, y, z = get_coordinates_once()
        if x is not None:
            return x, y, z
        safe_print(' okunamadı, tekrar...')
        time.sleep(0.5)
    return None, None, None


# ---------------------------------------------------------------------------
# GameBot class
# ---------------------------------------------------------------------------
class GameBot:
    def __init__(self):
        self.__class__  # ensure class cell
        self.running = False
        self.current_account = None
        self.current_world = None
        self.completed_count = 0
        self.stop_event = threading.Event()

    def add_log(self, msg):
        """CMD log'a yeni satır ekle"""
        timestamp = datetime.now().strftime('%H:%M:%S')
        log_entry = '[' + timestamp + '] ' + msg + '\n'
        try:
            print(log_entry, end='')
        except Exception:
            pass

    def run(self):
        """Ana çalışma döngüsü"""
        safe_print('[DEBUG] GameBot.run() başladı')
        self.running = True
        safe_print('[DEBUG] Bot running=True, process_one_account() çağrılıyor...')
        try:
            while self.running and not self.stop_event.is_set():
                try:
                    self.process_one_account()
                except Exception as e:
                    safe_print('[DEBUG] HATA: ', e)
                    traceback.print_exc(limit=5)
        finally:
            self.running = False
            self.stop_event.clear()
            self.add_log('⏹️ Bot durduruldu!')

    def process_one_account(self):
        """Tek bir hesabı işle"""
        safe_print('[DEBUG] process_one_account() başladı')
        if self.stop_event.is_set():
            safe_print('[DEBUG] Stop event set, çıkılıyor')
            return

        account_data = get_next_account()
        if account_data is None or account_data[0] is None:
            safe_print('⚠️ Tüm hesaplar işlendi!')
            safe_print('[DEBUG] Hesap bulunamadı. HESAPLAR_DOSYA: ', HESAPLAR_DOSYA)
            self.add_log('⏹️ Bot durduruldu (hesap yok)')
            self.running = False
            return

        account, password = account_data
        self.current_account = account
        safe_print('[DEBUG] Hesap bulundu, işlem başlıyor: ', account)

        if not password:
            safe_print('⚠️ ' + account + ' şifre yok, atlanıyor.')
            return

        safe_print('▶️ ' + account + ' başlıyor...')

        # Start the game client
        client_path = os.environ.get('SONOYUNCU_CLIENT', SONOYUNCU_CLIENT)
        safe_print('Client başlatılıyor...')
        safe_print('[DEBUG] Client yolu: ', client_path)
        safe_print('[DEBUG] Client var mı: ', os.path.exists(client_path))

        try:
            subprocess.Popen([client_path], cwd=os.path.dirname(client_path))
            safe_print('[DEBUG] Client subprocess ile başlatıldı')
        except Exception as e:
            safe_print('[DEBUG] subprocess hatası: ', e, ', os.startfile deneniyor...')
            try:
                os.startfile(client_path)
                safe_print('[DEBUG] Client os.startfile ile başlatıldı')
            except Exception as e2:
                _ = e2
                safe_print('[DEBUG] os.startfile hatası: ', e2)
                safe_print('❌ Client başlatılamadı: ', client_path)
                return

        # Wait for client to be running
        for i in range(0, 14):
            if self.stop_event.is_set():
                return
            if is_client_running():
                safe_print('[DEBUG] Client başladı (javaw.exe bulundu)')
                break
            time.sleep(1)
        else:
            safe_print('❌ Client bulunamadı: ', client_path)
            return
        safe_print('[DEBUG] Client yolu kontrol edildi: ', client_path)

        # Wait for login screen
        safe_print('Client açılması bekleniyor...')
        loc = wait_for_image(IMAGES['giris'], 120, 0.8, self.stop_event)
        if not loc:
            safe_print(account + ' giriş ekranı bulunamadı, atlanıyor.')
            return

        # Perform login
        if not launcher_login(account, password, self.stop_event):
            safe_print(account + ' giriş başarısız.')
            return

        # Check for ban screen (post-login)
        for i in range(0, 8):
            if self.stop_event.is_set():
                return
            if is_ban_screen(0.8):
                safe_print('🚫 ' + account + ' BANLI!')
                log_to_file(BAN_DOSYA, account)
                remove_account(account)
                close_game()
                return
            time.sleep(0.5)

        # Wait for multiplayer screen
        loc = wait_for_image(IMAGES['multi'], 50, 0.8, self.stop_event)
        if not loc:
            safe_print('⚠️ Multiplayer ekranı gelmedi!')
            return
        click_at(COORDS['coklu'][0], COORDS['coklu'][1])

        # Click server
        for i in range(0, 2):
            if self.stop_event.is_set():
                return
            click_at(COORDS['sunucu'][0], COORDS['sunucu'][1])
            pyautogui.press('enter')
            # Release any stuck modifiers
            for key in ('shift', 'ctrl', 'alt'):
                try:
                    pyautogui.keyUp(key)
                except Exception:
                    pass
            time.sleep(0.5)

        # Check for server ban
        for i in range(0, 6):
            if self.stop_event.is_set():
                return
            if is_ban_screen(0.8):
                safe_print(account + ' sunucudan BANLI!')
                log_to_file(BAN_DOSYA, account)
                remove_account(account)
                close_game()
                return
            time.sleep(0.5)

        # World scanning
        safe_print('Dünya tarama başlıyor...')
        pyautogui.rightClick()
        time.sleep(0.35)
        click_at(COORDS['oyun_modu'][0], COORDS['oyun_modu'][1])

        world_name = None
        wx = None
        wy = None
        for i in range(0, 9):
            if self.stop_event.is_set():
                return
            if i < len(DUNYALAR):
                entry_attempt = DUNYALAR[i]
                world_name, wx, wy = entry_attempt
                safe_print(world_name + ' giriliyor...')
                click_at(wx, wy)
                time.sleep(0.5)
                # Check if dead
                if is_death_screen(0.8):
                    click_at(COORDS['respawn'][0], COORDS['respawn'][1])
                    pyautogui.press('t')
                    time.sleep(0.3)
                    pyperclip.copy('/spawn')
                    pyautogui.hotkey('ctrl', 'v')
                    pyautogui.press('enter')
                    time.sleep(0.43)
                # Jump a few times and walk forward
                pyautogui.keyDown('space')
                for _ in range(0, 28):
                    if self.stop_event.is_set():
                        pyautogui.keyUp('space')
                        return
                    time.sleep(0.05)
                pyautogui.keyUp('space')
                pyautogui.press('a')
                pyautogui.press('w')
                if wx is not None and wy is not None:
                    pyautogui.moveTo(wx, wy, duration=0.15)
                click_at(COORDS['son_tik'][0], COORDS['son_tik'][1])

                # Try to get coordinates
                x, y, z = get_coordinates()
                if x is None:
                    safe_print(world_name + ' okunamadı, tekrar...')
                    continue
                safe_print('✅ ' + account + ' -> X:' + str(x) + ' Y:' + str(y) + ' Z:' + str(z))
                save_coordinates(account, world_name, x, y, z)
                self.current_world = world_name
                self.completed_count += 1
                safe_print('✔️ ' + account + ' TAMAMLANDI.')
                safe_print('⏳ Sonraki hesaba geçiliyor...')
                close_game()
                return
            time.sleep(0.3)

        # No world worked
        close_game()


# ---------------------------------------------------------------------------
# F8 start/stop controls
# ---------------------------------------------------------------------------
game_thread = None
bot = GameBot()
f8_pressed = False
last_press_time = 0.0


def start_bot_with_f8():
    """F8 tuşu ile botu başlatır."""
    safe_print('[DEBUG] start_bot_with_f8() çağrıldı')
    global game_thread
    if game_thread is not None:
        safe_print('[DEBUG] game_thread.running: ', getattr(bot, 'running', False))
        safe_print('[DEBUG] game_thread.is_alive(): ', game_thread.is_alive())
        if game_thread.is_alive():
            safe_print('⚠️ Bot zaten çalışıyor.')
            return
    safe_print('▶️ **Bot Başlatıldı!** (F8 ile) İşlemler başlıyor...')
    safe_print('▶️ Bot F8 tuşu ile başlatıldı!')
    bot.stop_event.clear()
    bot.running = True
    game_thread = threading.Thread(target=bot.run, daemon=True)
    game_thread.start()
    safe_print(
        '[DEBUG] Bot running=True yapıldı, thread çalışıyor mu: ',
        game_thread.is_alive(),
    )


def stop_bot_with_f8():
    """F8 tuşu ile botu durdurur ve scripti kapatır."""
    safe_print('⏹️ **Bot Durduruluyor...** (F8 ile)')
    if bot is not None:
        bot.stop_event.set()
        bot.running = False
    if game_thread is not None and game_thread.is_alive():
        safe_print('⏹️ Bot F8 tuşu ile durduruldu ve script kapatılıyor...')
        game_thread.join(timeout=2.0)
        safe_print('✅ Script kapatılıyor...')
    else:
        safe_print('⚠️ Bot zaten durdurulmuş. Script kapatılıyor...')
    sys.exit(0)


def keyboard_listener_thread():
    """F8 tuşu dinleyicisi - ayrı thread'de çalışır (başlat/durdur toggle)"""
    global f8_pressed, last_press_time
    f8_pressed = False
    last_press_time = 0.0
    while True:
        try:
            if keyboard.is_pressed('f8'):
                current_time = time.time()
                if current_time - last_press_time > 0.5:
                    if f8_pressed:
                        stop_bot_with_f8()
                    else:
                        start_bot_with_f8()
                    f8_pressed = not f8_pressed
                    last_press_time = current_time
        except Exception:
            pass
        time.sleep(0.1)


def auto_start_if_configured():
    """Çevre değişkeni ile otomatik başlat (varsa)"""
    if os.environ.get('AUTO_START_BOT') == '1':
        start_bot_with_f8()


if __name__ == '__main__':
    auto_start_if_configured()
    keyboard_listener_thread()
