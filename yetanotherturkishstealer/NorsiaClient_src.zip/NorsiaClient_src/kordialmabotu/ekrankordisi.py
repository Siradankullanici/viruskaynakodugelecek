"""kordialmabotu.ekrankordisi - Ekran koordinatısı alma aracı."""
import pyautogui
import keyboard
import time


def main():
    """Mouse ile koordinat al"""
    print('Hazır.')
    print("Mouse'u istediğin yere götür.")
    print("'G' tuşuna bas → koordinatı al")
    print("'ESC' tuşuna bas → çıkış")
    while True:
        if keyboard.is_pressed('g'):
            x, y = pyautogui.position()
            print('Koordinat alındı → X: ' + str(x) + ', Y: ' + str(y))
            time.sleep(0.3)
        if keyboard.is_pressed('esc'):
            print('Çıkılıyor...')
            break
        time.sleep(0.05)


if __name__ == '__main__':
    main()
