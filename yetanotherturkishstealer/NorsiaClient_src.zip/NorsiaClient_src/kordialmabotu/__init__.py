"""kordialmabotu paketi - Koord alma botu."""
