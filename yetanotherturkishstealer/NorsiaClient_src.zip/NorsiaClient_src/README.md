# Norsia Client - Sorgente Ricostruito

Sorgente Python 3.12 ricostruito 1:1 dal disassemblaggio Nuitka NBC del file originale `NorsiaClient.exe`.

## Struttura del progetto

```
NorsiaClient_src/
├── __main__.py              # Entry point principale (avvio GUI o bot CLI)
├── auth_system.py           # Sistema di autenticazione + HWID (API http://188.240.81.35:5000)
├── bot_dispatcher.py        # Dispatcher: avvia il bot richiesto per nome
├── discord_logger.py        # Logging Discord via webhook (statici + user)
├── gui.py                   # GUI principale PySide6 (ModernGUI)
├── login_gui.py             # Schermata di login PySide6 (LoginGUI)
├── buyu/                    # Pacchetto bot di incantamento (büyü)
│   ├── __init__.py
│   ├── diaset.py            # Diamond Set enchant bot
│   ├── titset.py            # Titanium Set enchant bot
│   ├── kazma_kurek_kilic.py # Pickaxe/Shovel/Sword/Bow enchant bot
│   ├── kitap.py             # Book enchant bot (libri selezionati da GUI)
│   └── t.py                 # OCR PIN code + autoclicker
├── ciftci_satma/            # Farmer sell bot
│   ├── __init__.py
│   └── ciftci_bot.py        # Vendita automatica karpuz/kabak + OCR PIN
├── kordialmabotu/           # Coordinate bot
│   ├── __init__.py
│   ├── bot.py               # Multi-account launcher con OCR coordinate
│   └── ekrankordisi.py      # Tool manuale per catturare coordinate mouse
└── ticaret_botu/            # Trade bot
    ├── __init__.py
    └── ticaret.py           # Monitor chat per richieste trade + OCR prezzo
```

## Dipendenze Python

```
PySide6>=6.5
pynput
pyautogui
opencv-python (cv2)
numpy
requests
colorama
pillow
pygetwindow
pyperclip
mss
keyboard
pywin32  (win32con, win32gui)
```

## Risorse necessarie (non incluse)

I bot fanno riferimento a immagini PNG nelle seguenti cartelle:
- `images/` - Template per enchant bot (kask.png, cp.png, pant.png, bot.png, ttLapis.png, kitap.png, p3.png, p4.png, 0.png-9.png, ecc.)
- `resources/icons/` - Icone GUI (iccp.png, ickilic.png, kitapi.png, denizf.png, piston.png, titanyum.png)
- `resources/ticaretsayi/` - Template OCR per trade bot (tic.png, digits)
- `kordialmabotu/coordinates/` - File coordinate per koordinat bot

## Come avviare

### Modalità GUI (default)
```bash
python __main__.py
```

### Modalità bot singolo (da CLI)
```bash
python __main__.py --run-bot <bot_name>
```

Bot disponibili:
- `diaset` - Diamond Set enchant
- `titset` - Titanium Set enchant
- `kitap` - Book enchant
- `kazma_kurek_kilic` - Tool/weapon enchant
- `ciftci` - Farmer sell
- `ticaret` - Trade
- `kordi` - Coordinate
- `craft_denizfeneri`, `craft_piston`, `craft_titanyum` - Craft bots

## Tasti rapidi

- **F8** - Avvia/ferma il bot corrente
- **F12** - Ferma TUTTI i bot (solo GUI)

## Note di ricostruzione

Il sorgente è stato ricostruito dai file `.nbc` (Nuitka bytecode disassembly) usando:
- Costanti stringa/intero/tuple/dict estratte da `@CONSTS`
- Firme di funzione da `@FUNCS_DETECTED` e tuple `co_varnames`
- Import da `@IMPORTS`
- Token recovery map dai commenti "recovered source map" del sorgente decompilato originale

Tutti i 19 file `.py` passano la verifica di sintassi Python 3.12.
