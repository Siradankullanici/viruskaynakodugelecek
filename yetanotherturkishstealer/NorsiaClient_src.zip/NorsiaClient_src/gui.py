"""Norsia Client - Ana GUI (PySide6)"""
import sys
import os
import re
import json
import shutil
import time
import webbrowser
import threading
import subprocess
import tempfile
from datetime import datetime
from threading import Thread
from subprocess import Popen, PIPE, CREATE_NO_WINDOW

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTextEdit, QFrame, QScrollArea, QGridLayout,
    QLineEdit, QCheckBox, QRadioButton, QButtonGroup, QMessageBox,
    QDialog, QSizePolicy
)
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import (
    QFont, QColor, QPalette, QTextCharFormat, QTextCursor, QPixmap
)
from pynput import keyboard

# Renk paleti
COLORS = {
    'bg_dark': '#0B0F14',
    'bg_medium': '#111827',
    'bg_light': '#0F172A',
    'neon_blue': '#00BFFF',
    'neon_blue_hover': '#00D4FF',
    'neon_red': '#FF1744',
    'neon_red_hover': '#FF4444',
    'border': '#1E293B',
    'text_primary': '#E5E7EB',
    'text_secondary': '#94A3B8',
    'input_bg': '#0F172A',
    'log_bg': '#0A0E14',
    'error': '#FF4444',
    'success': '#6BFF95',
    'warning': '#FFD700',
    'info': '#00BFFF',
}


def get_base_path():
    """Exe veya script'in bulunduğu dizini döndür"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def get_resource_path(relative_path):
    """Resource dosyasının yolunu döndür (exe içinden veya normal script)"""
    base_path = get_base_path()
    return os.path.join(base_path, relative_path)


def extract_script_if_needed(script_path):
    """Script'i exe içinden geçici dizine çıkar (gerekirse)"""
    if os.path.exists(script_path):
        return script_path
    resource_path = get_resource_path(script_path)
    if os.path.exists(resource_path):
        return resource_path
    if getattr(sys, 'frozen', False):
        return os.path.join(tempfile.gettempdir(), os.path.basename(script_path))
    return script_path


class LogTextEdit(QTextEdit):
    """Özel log text edit widget"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFont(QFont('Segoe UI', 7))
        self.setStyleSheet(
            '\n            QTextEdit {\n                background-color: ' + COLORS['log_bg'] + ';\n'
            '                color: ' + COLORS['text_primary'] + ';\n'
            '                border: none;\n                padding: 6px;\n            }\n        '
        )

    def append_log(self, message, log_type='info'):
        """Renkli log mesajı ekle"""
        color_map = {
            'info': COLORS['info'],
            'success': COLORS['success'],
            'error': COLORS['error'],
            'warning': COLORS['warning'],
            'debug': COLORS['text_secondary'],
        }
        prefix_map = {
            'info': '[INFO]',
            'success': '[OK]',
            'error': '[HATA]',
            'warning': '[UYARI]',
            'debug': '[X]',
        }
        color = color_map.get(log_type, COLORS['text_primary'])
        prefix = prefix_map.get(log_type, '[INFO]')
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        cursor.insertText(' ' + prefix + ' ' + message + '\n', fmt)
        self.setTextCursor(cursor)
        self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())


class ModernGUI(QMainWindow):
    """Norsia Client Ana GUI"""

    def __init__(self):
        super().__init__()
        self.expires_at = None
        self.running_processes = {}
        self.process_lock = threading.Lock()
        self._last_logs = []
        self.selected_main = None
        self.selected_sub = None
        self.enchant_selections = {
            'set_type': 'Diamond',
            'item_type': None,
            'envanter_yenileme': False,
            'chest': False,
            'books': {
                'keskinlik4': False,
                'kirilmazlik': False,
                'derinkosucu3': False,
                'derinkosucu2': False,
                'ipeksidokunus': False,
                'koruma': False,
                'servet3': False,
                'savurma2': False,
                'verimlilik4': False,
                'servet2': False,
                'keskinlik3': False,
                'alevdencehre': False,
            },
        }
        self.setup_ui()
        self.setup_keyboard_listener()
        self.log_message('Norsia Client launched, thanks for using Norsia Client..', 'info')
        self.log_message('F12 tuşuna basarak çalışan botları durdurabilirsiniz...', 'info')
        # Pencere başlığını periyodik güncelle
        self.title_timer = QTimer(self)
        self.title_timer.timeout.connect(self.update_window_title)
        self.title_timer.start(60000)
        self.update_window_title()

    def setup_ui(self):
        """UI'yi oluştur"""
        self.setWindowTitle('Norsia Client')
        self.setGeometry(100, 100, 1000, 600)
        self.setMinimumSize(1000, 600)
        self.setMaximumSize(1000, 600)
        self.setStyleSheet(
            '\n            QMainWindow {\n                background-color: ' + COLORS['bg_dark'] + ';\n            }\n'
            '            QWidget {\n                background-color: ' + COLORS['bg_dark'] + ';\n            }\n'
            '            QPushButton {\n                background-color: ' + COLORS['bg_medium'] + ';\n'
            '                border: 1px solid ' + COLORS['border'] + ';\n'
            "                border-radius: 4px;\n                padding: 5px 10px;\n                font: 8pt 'Segoe UI';\n            }\n"
            '            QPushButton:hover {\n                background-color: ' + COLORS['bg_light'] + ';\n'
            '                border-color: ' + COLORS['neon_blue'] + ';\n            }\n'
            '            QPushButton:pressed {\n                background-color: ' + COLORS['neon_blue'] + ';\n            }\n'
            '            QPushButton[primary="true"] {\n                background-color: ' + COLORS['neon_blue'] + ';\n'
            '                color: white;\n                border: none;\n                font-weight: bold;\n            }\n'
            '            QPushButton[primary="true"]:hover {\n                background-color: ' + COLORS['neon_blue_hover'] + ';\n            }\n'
            '            QPushButton[red="true"] {\n                background-color: ' + COLORS['neon_red'] + ';\n'
            '                color: white;\n                border: none;\n                font-weight: bold;\n            }\n'
            '            QPushButton[red="true"]:hover {\n                background-color: ' + COLORS['neon_red_hover'] + ';\n            }\n'
            '            QLineEdit {\n                background-color: ' + COLORS['input_bg'] + ';\n'
            '                border: 1px solid ' + COLORS['border'] + ';\n'
            "                border-radius: 4px;\n                padding: 3px;\n                font: 8pt 'Segoe UI';\n            }\n"
            '            QLineEdit:focus {\n                border-color: ' + COLORS['neon_blue'] + ';\n            }\n'
            '            QCheckBox {\n                color: ' + COLORS['text_primary'] + ';\n'
            "                font: 8pt 'Segoe UI';\n            }\n"
            '            QCheckBox::indicator {\n                width: 16px;\n                height: 16px;\n'
            '                background-color: ' + COLORS['input_bg'] + ';\n                border-radius: 3px;\n            }\n'
            '            QCheckBox::indicator:checked {\n                background-color: ' + COLORS['neon_blue'] + ';\n            }\n'
            '            QRadioButton {\n                color: ' + COLORS['text_primary'] + ';\n'
            "                font: 8pt 'Segoe UI';\n            }\n"
            '            QRadioButton::indicator {\n                width: 16px;\n                height: 16px;\n'
            '                border-radius: 8px;\n                background-color: ' + COLORS['input_bg'] + ';\n            }\n'
            '            QRadioButton::indicator:checked {\n                background-color: ' + COLORS['neon_blue'] + ';\n            }\n'
            "            QLabel {\n                color: " + COLORS['text_primary'] + ";\n                font: 8pt 'Segoe UI';\n            }\n"
            '            QFrame[card="true"] {\n                background-color: ' + COLORS['bg_medium'] + ';\n'
            '                border: none;\n                border-radius: 4px;\n            }\n'
            '            QFrame[cardSelected="true"] {\n                background-color: ' + COLORS['bg_medium'] + ';\n'
            '                border: 2px solid ' + COLORS['neon_blue'] + ';\n                border-radius: 4px;\n            }\n        '
        )
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QHBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(2, 2, 2, 2)
        self.main_layout.setSpacing(2)
        self.setup_left_panel(self.main_layout)
        self.setup_right_panel(self.main_layout)
        self.log_message('DEBUG: Base Path: ' + get_base_path(), 'debug')
        self.log_message('DEBUG: sys.executable: ' + sys.executable, 'debug')
        self.log_message('DEBUG: Frozen: ' + str(getattr(sys, 'frozen', False)), 'debug')

    def setup_left_panel(self, parent_layout):
        """Sol panel (Logs)"""
        self.left_panel = QFrame()
        self.left_panel.setFixedWidth(220)
        self.left_panel.setStyleSheet('background-color: ' + COLORS['bg_dark'] + ';')
        self.left_layout = QVBoxLayout(self.left_panel)
        self.left_layout.setContentsMargins(6, 6, 6, 6)
        self.left_layout.setSpacing(6)

        self.logs_label = QLabel('LOGS')
        self.logs_label.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-weight: bold; font-size: 9pt;')
        self.left_layout.addWidget(self.logs_label)

        self.log_text = LogTextEdit()
        self.left_layout.addWidget(self.log_text)

        # Nav butonları
        self.nav_frame = QFrame()
        self.nav_layout = QVBoxLayout(self.nav_frame)
        self.nav_layout.setContentsMargins(0, 0, 0, 0)
        self.nav_layout.setSpacing(1)

        nav_buttons = [
            ('Discord', self.nav_discord),
            ('Youtube', self.nav_youtube),
            ('Log File', self.nav_log_file),
        ]
        for text, handler in nav_buttons:
            btn = QPushButton(text)
            btn.clicked.connect(handler)
            self.nav_layout.addWidget(btn)

        self.left_layout.addWidget(self.nav_frame)
        parent_layout.addWidget(self.left_panel)

    def setup_right_panel(self, parent_layout):
        """Sağ panel"""
        self.right_panel = QFrame()
        self.right_layout = QVBoxLayout(self.right_panel)
        self.right_layout.setContentsMargins(0, 0, 0, 0)
        self.right_layout.setSpacing(0)

        self.setup_main_tabs(self.right_layout)
        self.setup_sub_tabs(self.right_layout)

        self.content_widget = QWidget()
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(12, 12, 12, 12)
        self.right_layout.addWidget(self.content_widget, 1)

        parent_layout.addWidget(self.right_panel, 1)
        self.update_content()

    def setup_main_tabs(self, parent_layout):
        """Ana kategori butonları"""
        self.tabs_frame = QFrame()
        self.tabs_layout = QHBoxLayout(self.tabs_frame)
        self.tabs_layout.setContentsMargins(0, 0, 0, 0)
        self.tabs_layout.setSpacing(1)

        self.main_tabs = {}
        main_tab_names = ['Menu', 'Sonoyuncu', 'Craftrise', 'Yakında', 'Yakında', 'Chat', 'Settings', 'Discord', 'Youtube']
        for name in main_tab_names:
            btn = QPushButton(name)
            btn.setProperty('primary', name == self.selected_main)
            btn.styleSheet = (
                'QPushButton { background-color: ' + COLORS['bg_medium'] + '; '
                'color: ' + COLORS['text_secondary'] + '; border: none; padding: 8px 12px; '
                "font: 8pt 'Segoe UI'; font-weight: bold; }"
                'QPushButton:hover { background-color: ' + COLORS['bg_light'] + '; '
                'color: ' + COLORS['text_primary'] + '; }'
                'QPushButton[primary="true"] { background-color: ' + COLORS['neon_blue'] + '; color: white; }'
            )
            btn.clicked.connect(lambda _=False, n=name: self.select_main_tab(n))
            self.main_tabs[name] = btn
            self.tabs_layout.addWidget(btn)

        parent_layout.addWidget(self.tabs_frame)

    def setup_sub_tabs(self, parent_layout):
        """Alt kategori butonları"""
        self.sub_tabs_frame = QFrame()
        self.sub_tabs_layout = QHBoxLayout(self.sub_tabs_frame)
        self.sub_tabs_layout.setContentsMargins(0, 0, 0, 0)
        self.sub_tabs_layout.setSpacing(1)
        self.sub_tabs = {}
        parent_layout.addWidget(self.sub_tabs_frame)

    def update_sub_tabs(self):
        """Alt tab'ları güncelle"""
        # Öncekileri temizle
        for i in reversed(range(self.sub_tabs_layout.count())):
            item = self.sub_tabs_layout.itemAt(i)
            widget = item.widget() if item else None
            if widget is not None:
                widget.setParent(None)
            else:
                self.sub_tabs_layout.removeItem(item)
        self.sub_tabs.clear()

        if self.selected_main != 'Sonoyuncu':
            return

        sub_tab_names = ['Farm', 'Enchant', 'Craft', 'Çiftçi', 'Kordinat', 'Ticaret', 'Eklenecek']
        for name in sub_tab_names:
            btn = QPushButton(name)
            btn.setProperty('primary', name == self.selected_sub)
            btn.styleSheet = (
                'QPushButton { background-color: ' + COLORS['bg_light'] + '; '
                'color: ' + COLORS['text_secondary'] + '; border: none; padding: 6px 10px; '
                "font: 8pt 'Segoe UI'; }"
                'QPushButton:hover { background-color: ' + COLORS['bg_medium'] + '; '
                'color: ' + COLORS['text_primary'] + '; }'
                'QPushButton[primary="true"] { background-color: ' + COLORS['neon_blue'] + '; color: white; }'
            )
            btn.clicked.connect(lambda _=False, n=name: self.select_sub_tab(n))
            self.sub_tabs[name] = btn
            self.sub_tabs_layout.addWidget(btn)

    def select_main_tab(self, name):
        """Ana tab seç"""
        self.selected_main = name
        self.selected_sub = None
        for n, b in self.main_tabs.items():
            b.setProperty('primary', n == name)
            b.styleSheet = b.styleSheet
        self.update_sub_tabs()
        self.update_content()

    def select_sub_tab(self, name):
        """Alt tab seç"""
        self.selected_sub = name
        for n, b in self.sub_tabs.items():
            b.setProperty('primary', n == name)
            b.styleSheet = b.styleSheet
        self.update_content()

    def update_content(self):
        """İçeriği güncelle"""
        # Önceki içeriği temizle
        for i in reversed(range(self.content_layout.count())):
            item = self.content_layout.itemAt(i)
            widget = item.widget() if item else None
            if widget is not None:
                widget.setParent(None)
            else:
                self.content_layout.removeItem(item)

        main = self.selected_main
        sub = self.selected_sub

        if main == 'Menu':
            self.show_menu_content()
        elif main == 'Sonoyuncu':
            if sub == 'Enchant':
                self.show_enchant_content()
            elif sub == 'Çiftçi':
                self.show_farmer_content()
            elif sub == 'Craft':
                self.show_craft_content()
            elif sub == 'Kordinat':
                self.show_coordinate_content()
            elif sub == 'Ticaret':
                self.show_trade_content()
            else:
                self.show_default_content()
        elif main == 'Craftrise':
            self.show_craftrise_content()
        elif main == 'Discord':
            self.show_discord_content()
        elif main == 'Youtube':
            self.show_youtube_content()
        elif main == 'Settings':
            self.show_settings_content()
        else:
            self.show_default_content()

        self.content_layout.addStretch()

    def show_menu_content(self):
        """Menu içeriği"""
        title = QLabel('Norsia Client')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 18pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        info_text = (
            'Program Hakkında Bilgiler:\n\n'
            '• Otomatik büyü ve çiftçi satma botu VB.\n'
            '• Sonoyuncu ve Craftrise sunucuları için optimize edilmiştir.\n'
            '• F8 ile botları başlat/durdur, F12 ile tüm botları durdur.\n\n'
            'Sürüm: v0.1\n'
            'Discord: discord.gg/norsia'
        )
        info_label = QLabel(info_text)
        info_label.setWordWrap(True)
        info_label.setStyleSheet('color: ' + COLORS['text_primary'] + '; font-size: 10pt;')
        self.content_layout.addWidget(info_label)

    def show_enchant_content(self):
        """Enchant içeriği"""
        title = QLabel('Büyü Botu')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 14pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        # Set Türü
        set_type_label = QLabel('Set Türü')
        set_type_label.setStyleSheet('font-weight: bold; font-size: 9pt;')
        self.content_layout.addWidget(set_type_label)

        set_type_container = QFrame()
        set_type_layout = QHBoxLayout(set_type_container)
        set_type_layout.setContentsMargins(0, 0, 0, 0)
        set_type_layout.setSpacing(8)
        self.set_type_group = QButtonGroup(self)
        self.set_type_var = None
        for text, value in (('Diamond', 'Diamond'), ('Titanyum', 'Titanyum')):
            card = QPushButton(text)
            card.setProperty('cardSelected', self.enchant_selections['set_type'] == value)
            card.setFixedHeight(50)
            card.styleSheet = (
                'QPushButton { background-color: ' + COLORS['bg_medium'] + '; '
                'color: ' + COLORS['text_secondary'] + '; border: 2px solid ' + COLORS['border'] + '; '
                'border-radius: 4px; font-weight: bold; padding: 8px 16px; }'
                'QPushButton[cardSelected="true"] { border-color: ' + COLORS['neon_blue'] + '; '
                'color: ' + COLORS['neon_blue'] + '; }'
            )
            card.clicked.connect(self.make_click_handler('set_type', value))
            if self.enchant_selections['set_type'] == value:
                self.set_type_var = value
            set_type_layout.addWidget(card)
        self.content_layout.addWidget(set_type_container)

        # Item Türü
        item_type_label = QLabel('Item Türü')
        item_type_label.setStyleSheet('font-weight: bold; font-size: 9pt;')
        self.content_layout.addWidget(item_type_label)

        item_type_container = QFrame()
        item_type_layout = QHBoxLayout(item_type_container)
        item_type_layout.setContentsMargins(8, 6, 8, 6)
        item_type_layout.setSpacing(8)
        item_types = (('Setler', 'Setler', 'iccp.png'), ('Aletler', 'Aletler', 'ickilic.png'), ('Kitap', 'Kitap', 'kitapi.png'))
        for text, value, icon_file in item_types:
            card = QPushButton(text)
            card.setProperty('cardSelected', self.enchant_selections.get('item_type') == value)
            card.setFixedHeight(70)
            icon_path = get_resource_path(os.path.join('resources', 'icons', icon_file))
            if os.path.exists(icon_path):
                pixmap = QPixmap(icon_path).scaled(32, 32, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                card.setIcon(pixmap if False else QIcon(pixmap) if False else QPixmap(pixmap))
            else:
                self.log_message('DEBUG: Icon not found: ' + icon_path, 'debug')
            card.styleSheet = (
                'QPushButton { background-color: ' + COLORS['bg_medium'] + '; '
                'color: ' + COLORS['text_secondary'] + '; border: 2px solid ' + COLORS['border'] + '; '
                'border-radius: 4px; font-weight: bold; font-size: 8pt; padding: 6px; }'
                'QPushButton[cardSelected="true"] { border-color: ' + COLORS['neon_blue'] + '; '
                'color: ' + COLORS['neon_blue'] + '; }'
            )
            card.clicked.connect(self.make_click_handler('item_type', value))
            item_type_layout.addWidget(card)
        self.content_layout.addWidget(item_type_container)

        # Envanter Yenileme + Chest checkboxes
        options_layout = QHBoxLayout()
        self.envanter_yenileme_var = QCheckBox('Envanter Yenileme(Kitap)')
        self.envanter_yenileme_var.setChecked(self.enchant_selections.get('envanter_yenileme', False))
        self.envanter_yenileme_var.setEnabled(self.enchant_selections.get('item_type') == 'Kitap')
        self.envanter_yenileme_var.stateChanged.connect(lambda v: self.update_selection('enchant', 'envanter_yenileme', v != 0))
        options_layout.addWidget(self.envanter_yenileme_var)

        self.chest_var = QCheckBox('Chest')
        self.chest_var.setChecked(self.enchant_selections.get('chest', False))
        self.chest_var.stateChanged.connect(lambda v: self.update_selection('enchant', 'chest', v != 0))
        options_layout.addWidget(self.chest_var)
        self.content_layout.addLayout(options_layout)

        # Kitap seçimleri grid
        if self.enchant_selections.get('item_type') == 'Kitap':
            books_label = QLabel('Kitap Seçimleri')
            books_label.setStyleSheet('font-weight: bold; font-size: 9pt;')
            self.content_layout.addWidget(books_label)

            books_frame = QFrame()
            books_frame.setProperty('card', True)
            books_frame.setStyleSheet('background-color: ' + COLORS['bg_medium'] + ';')
            self.books_layout = QGridLayout(books_frame)
            self.books_layout.setSpacing(4)
            books_list = [
                ('Keskinlik 4', 'keskinlik4', 'keskinlik4.png'),
                ('Kırılmazlık', 'kirilmazlik', 'kirilmazlik.png'),
                ('Derin Koşucu 3', 'derinkosucu3', 'derinkosucu3.png'),
                ('Derin Koşucu 2', 'derinkosucu2', 'derinkosucu2.png'),
                ('İpeksi Dokunuş', 'ipeksidokunus', 'ipeksidokunus.png'),
                ('Koruma', 'koruma', 'koruma.png'),
                ('Servet 3', 'servet3', 'servet3.png'),
                ('Savurma 2', 'savurma2', 'savurma2.png'),
                ('Verimlilik 4', 'verimlilik4', 'verimlilik4.png'),
                ('Servet 2', 'servet2', 'servet2.png'),
                ('Keskinlik 3', 'keskinlik3', 'keskinlik3.png'),
                ('Alevden Çehre', 'alevdencehre', 'alevdencehre.png'),
            ]
            self.book_vars = {}
            for i, (text, key, icon_file) in enumerate(books_list):
                cb = QCheckBox(text)
                cb.setStyleSheet('font-size: 7pt;')
                cb.setChecked(self.enchant_selections['books'].get(key, False))
                cb.stateChanged.connect(lambda v, k=key: self.update_selection('books', k, v != 0))
                self.book_vars[key] = cb
                self.books_layout.addWidget(cb, i // 4, i % 4)
            self.content_layout.addWidget(books_frame)

        # Başlat
        start_btn = QPushButton('Başlat')
        start_btn.setProperty('primary', True)
        start_btn.setFixedHeight(35)
        start_btn.clicked.connect(self.start_enchant)
        self.content_layout.addWidget(start_btn)

    def make_click_handler(self, category, value):
        """Click handler oluştur"""
        def handler():
            self.update_selection('enchant', category, value)
            self.enchant_selections[category] = value
            self.update_content()
        return handler

    def show_farmer_content(self):
        """Çiftçi içeriği"""
        title = QLabel('Çiftçi Satma Botu')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 14pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        info_text = (
            'Çiftçi Satma Botu\n\n'
            'Bu bot, çiftçi satma işlemlerini otomatik olarak gerçekleştirir.\n\n'
            'Özellikler:\n'
            '• Otomatik karpuz/kabak toplama ve satma\n'
            '• PIN doğrulama otomatik çözümleme\n'
            '• Discord webhook loglama\n'
            '• F8 ile başlat/durdur\n'
        )
        info_label = QLabel(info_text)
        info_label.setWordWrap(True)
        self.content_layout.addWidget(info_label)

        dakika_frame = QFrame()
        dakika_layout = QHBoxLayout(dakika_frame)
        dakika_label = QLabel('⏱ Her döngü kaç dakika sürsün?')
        dakika_label.setStyleSheet('font-weight: bold;')
        dakika_layout.addWidget(dakika_label)
        self.dakika_var = QLineEdit('60')
        self.dakika_var.setFixedWidth(80)
        dakika_layout.addWidget(self.dakika_var)
        hint_label = QLabel('(varsayılan: 60)')
        hint_label.setStyleSheet('color: ' + COLORS['text_secondary'] + ';')
        dakika_layout.addWidget(hint_label)
        dakika_layout.addStretch()
        self.content_layout.addWidget(dakika_frame)

        start_btn = QPushButton('Başlat')
        start_btn.setProperty('primary', True)
        start_btn.setFixedHeight(40)
        start_btn.clicked.connect(self.start_farmer)
        self.content_layout.addWidget(start_btn)

    def show_craft_content(self):
        """Craft içeriği"""
        title = QLabel('Craft İşlemleri')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 14pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        craft_items = [
            ('Deniz Feneri', 'denizf.png', True),
            ('Piston', 'piston.png', True),
            ('Titanyum', 'titanyum.png', False),
        ]
        for text, icon_file, has_loop in craft_items:
            item_card = QFrame()
            item_card.setProperty('card', True)
            item_card.styleSheet = (
                '\n                QFrame[card="true"] {\n                    background-color: ' + COLORS['bg_medium'] + ';\n'
                '                    border: none;\n                    border-radius: 4px;\n                }\n            '
            )
            item_layout = QHBoxLayout(item_card)
            item_layout.setContentsMargins(10, 10, 10, 10)
            item_layout.setSpacing(10)

            icon_label = QLabel()
            icon_path = get_resource_path(os.path.join('resources', 'icons', icon_file))
            if os.path.exists(icon_path):
                pixmap = QPixmap(icon_path).scaled(48, 48, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation)
                icon_label.setPixmap(pixmap)
            icon_label.setFixedWidth(48)
            item_layout.addWidget(icon_label)

            name_label = QLabel(text)
            name_label.setStyleSheet('font-weight: bold; font-size: 10pt;')
            name_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            item_layout.addWidget(name_label, 1)

            if has_loop:
                loop_label = QLabel('Döngü:')
                loop_label.setStyleSheet('font-size: 8pt;')
                item_layout.addWidget(loop_label)
                loop_entry = QLineEdit('1')
                loop_entry.setFixedWidth(60)
                loop_entry.setStyleSheet('font-size: 8pt; padding: 2px;')
                item_layout.addWidget(loop_entry)
            else:
                loop_entry = None

            craft_btn = QPushButton('Craft')
            craft_btn.setProperty('primary', True)
            craft_btn.setFixedHeight(22)
            craft_btn.setStyleSheet('font-size: 8pt; padding: 2px;')
            craft_btn.clicked.connect(self.make_craft_handler(text, loop_entry))
            item_layout.addWidget(craft_btn)

            self.content_layout.addWidget(item_card)

    def make_craft_handler(self, item_name, entry):
        """Craft handler oluştur"""
        def handler():
            dongu = 1
            if entry is not None:
                dongu_str = entry.text().strip()
                try:
                    dongu = int(dongu_str)
                    if dongu < 1:
                        QMessageBox.warning(self, 'Uyarı', "Döngü sayısı 1'den küçük olamaz!")
                        return
                except ValueError:
                    QMessageBox.warning(self, 'Uyarı', 'Lütfen geçerli bir sayı girin!')
                    return
            self.run_craft_script(item_name, dongu)
        return handler

    def show_coordinate_content(self):
        """Koordinat içeriği"""
        title = QLabel('Koordinat Alma Botu')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 14pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        info_text = (
            'Koordinat Alma Botu\n\n'
            'ÖNEMLİ: Bot 1600x900 çözünürlük ve %100 ölçek ile çalışır!\n\n'
            'İşleyiş: Hesapları oyuna sokar, hangi dünyada olduğunu ve koordinatlarını alır, '
            'kaydedip sonraki hesaba geçer.\n'
            'F8 ile başlat/durdur.\n'
        )
        info_label = QLabel(info_text)
        info_label.setWordWrap(True)
        self.content_layout.addWidget(info_label)

        load_btn = QPushButton('Gereksinimleri Yükle')
        load_btn.setProperty('primary', True)
        load_btn.clicked.connect(self.load_coordinate_requirements)
        self.content_layout.addWidget(load_btn)

        start_btn = QPushButton("Başlat (Sonra F8'e Basın)")
        start_btn.setProperty('primary', True)
        start_btn.clicked.connect(self.start_coordinate)
        self.content_layout.addWidget(start_btn)

    def show_trade_content(self):
        """Ticaret botu içeriği"""
        title = QLabel('Ticaret Botu')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 14pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        # Satılacak Set
        set_label = QLabel('Satılacak Set')
        set_label.setStyleSheet('font-weight: bold;')
        self.content_layout.addWidget(set_label)

        set_frame = QFrame()
        set_layout = QHBoxLayout(set_frame)
        self.trade_set_var = '1'
        set_options = (('1', 'Tit Set'), ('2', 'Dia Set'), ('3', 'Duel Kiti'))
        for value, text in set_options:
            radio = QRadioButton(text)
            if value == '1':
                radio.setChecked(True)
            radio.toggled.connect(lambda checked, v=value: self.update_selection('trade', 'set', v) if checked else None)
            set_layout.addWidget(radio)
        self.content_layout.addWidget(set_frame)

        # Reklam Mesajı
        message_label = QLabel('Reklam Mesajı')
        message_label.setStyleSheet('font-weight: bold;')
        self.content_layout.addWidget(message_label)
        self.trade_message_var = QLineEdit()
        self.content_layout.addWidget(self.trade_message_var)

        # İstenen Para
        price_label = QLabel('İstenen Para Miktarı')
        price_label.setStyleSheet('font-weight: bold;')
        self.content_layout.addWidget(price_label)
        self.trade_price_var = QLineEdit()
        self.content_layout.addWidget(self.trade_price_var)

        # Chest'ten item yenileme
        self.trade_chest_var = QCheckBox("Chest'ten Item Yenileme")
        self.content_layout.addWidget(self.trade_chest_var)

        # Başlat
        start_btn = QPushButton('Başlat')
        start_btn.setProperty('primary', True)
        start_btn.clicked.connect(self.start_trade_bot)
        self.content_layout.addWidget(start_btn)

        info_label = QLabel('Bot başlatıldıktan sonra F8 tuşuna basarak botu aktif edin.')
        info_label.setStyleSheet('color: ' + COLORS['text_secondary'] + ';')
        info_label.setWordWrap(True)
        self.content_layout.addWidget(info_label)

    def show_discord_content(self):
        """Discord içeriği"""
        title = QLabel('Discord')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 16pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        info_label = QLabel('Discord sunucumuza katılın!')
        info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(info_label)

        discord_link = QLabel('discord.gg/norsia')
        discord_link.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 14pt; font-weight: bold;')
        discord_link.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(discord_link)

        discord_btn = QPushButton("Discord'u Aç")
        discord_btn.setProperty('primary', True)
        discord_btn.clicked.connect(lambda: webbrowser.open('https://discord.gg/norsia'))
        self.content_layout.addWidget(discord_btn)

    def show_youtube_content(self):
        """Youtube içeriği"""
        title = QLabel('Youtube')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 16pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        info_label = QLabel('Youtube kanalımızı ziyaret edin!')
        info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(info_label)

        youtube_link = QLabel('youtube.com/@BayAhahnet')
        youtube_link.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 14pt; font-weight: bold;')
        youtube_link.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(youtube_link)

        youtube_btn = QPushButton("Youtube'u Aç")
        youtube_btn.setProperty('primary', True)
        youtube_btn.clicked.connect(lambda: webbrowser.open('https://www.youtube.com/@BayAhahnet'))
        self.content_layout.addWidget(youtube_btn)

    def show_craftrise_content(self):
        """Craftrise içeriği"""
        title = QLabel('Craftrise Modülü')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 14pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        info_label = QLabel('Yakında eklenecek...')
        info_label.setStyleSheet('color: ' + COLORS['text_secondary'] + ';')
        info_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(info_label)

    def show_settings_content(self):
        """Ayarlar içeriği"""
        title = QLabel('Ayarlar')
        title.setStyleSheet('color: ' + COLORS['neon_blue'] + '; font-size: 16pt; font-weight: bold;')
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(title)

        webhook_frame = QFrame()
        webhook_frame.setProperty('card', True)
        webhook_layout = QVBoxLayout(webhook_frame)
        webhook_layout.setContentsMargins(10, 10, 10, 10)
        webhook_layout.setSpacing(6)

        webhook_label = QLabel('Discord Webhook URL')
        webhook_label.setStyleSheet('font-weight: bold; font-size: 10pt;')
        webhook_layout.addWidget(webhook_label)

        try:
            import auth_system
            current_webhook = auth_system.get_user_webhook()
        except Exception:
            current_webhook = ''
        self.webhook_var = QLineEdit(current_webhook)
        webhook_layout.addWidget(self.webhook_var)

        info_text = QLabel("Discord webhook URL'inizi buraya girin. Bot logları bu webhook'a gönderilecektir.")
        info_text.setWordWrap(True)
        info_text.setStyleSheet('color: ' + COLORS['text_secondary'] + ';')
        webhook_layout.addWidget(info_text)

        save_btn = QPushButton('Kaydet')
        save_btn.setProperty('primary', True)
        save_btn.clicked.connect(self.save_webhook)
        webhook_layout.addWidget(save_btn)

        self.content_layout.addWidget(webhook_frame)

    def show_default_content(self):
        """Varsayılan içerik"""
        label = QLabel('İçerik yükleniyor...')
        label.setStyleSheet('color: ' + COLORS['text_secondary'] + ';')
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.content_layout.addWidget(label)

    def update_selection(self, category, key, value):
        """Seçimleri güncelle"""
        if category == 'enchant':
            self.enchant_selections[key] = value
        elif category == 'books':
            self.enchant_selections['books'][key] = value
        elif category == 'trade':
            # trade_set_var vs. ayrı tutulur
            pass

    def start_enchant(self):
        """Enchant botunu başlat"""
        item_type = self.enchant_selections.get('item_type')
        set_type = self.enchant_selections.get('set_type', 'Diamond')
        if item_type is None:
            self.log_message("Lütfen üstten 'Setler', 'Aletler' veya 'Kitap' seçin!", 'warning')
            return

        if item_type == 'Kitap':
            selected_books = {k: v for k, v in self.enchant_selections['books'].items() if v}
            if not selected_books:
                self.log_message('Lütfen en az bir kitap seçin!', 'warning')
                return
            self.log_message('Kitap basma modu seçildi, kitap.py çalıştırılıyor...', 'info')
            self.log_message('Seçili kitaplar: ' + ', '.join(selected_books.keys()), 'info')
            envanter_yenileme = self.enchant_selections.get('envanter_yenileme', False)
            if envanter_yenileme:
                self.log_message('Envanter yenileme aktif', 'info')
            script_path = os.path.join('buyu', 'kitap.py')
            if not os.path.exists(script_path):
                self.log_message('Kitap botu bulunamadı', 'error')
                return
            self.run_script_with_books(script_path, selected_books, envanter_yenileme)
            return

        # Setler / Aletler
        self.log_message('Set/Alet basma modu seçildi: ' + set_type + ' - ' + item_type, 'info')
        chest_enabled = self.enchant_selections.get('chest', False)
        if chest_enabled:
            self.log_message('Chest aktif', 'info')
        if item_type == 'Setler':
            if set_type == 'Diamond':
                script_path = os.path.join('buyu', 'diaset.py')
            else:
                script_path = os.path.join('buyu', 'titset.py')
        else:  # Aletler
            script_path = os.path.join('buyu', 'kazma_kurek_kilic.py')
        self.log_message('DEBUG: Set Script Path: ' + script_path, 'debug')
        if not os.path.exists(script_path):
            self.log_message('Script bulunamadı: ' + script_path, 'error')
            return
        self.run_script_with_chest(script_path, chest_enabled)

    def start_farmer(self):
        """Çiftçi botunu başlat"""
        dakika_str = self.dakika_var.text().strip()
        try:
            dakika = int(dakika_str) if dakika_str else 60
            if dakika < 1:
                self.log_message("Dakika değeri 1'den küçük olamaz!", 'warning')
                return
        except ValueError:
            self.log_message('Lütfen geçerli bir sayı girin!', 'warning')
            return
        self.log_message('Çiftçi satma botu başlatılıyor... (Döngü süresi: ' + str(dakika) + ' dakika)', 'info')
        script_path = os.path.join('ciftci_satma', 'ciftci_bot.py')
        if not os.path.exists(script_path):
            self.log_message('Çiftçi botu bulunamadı', 'error')
            return
        self.run_script_with_input(script_path, str(dakika))

    def load_coordinate_requirements(self):
        """Koordinat gereksinimlerini yükle"""
        try:
            import kordialmabotu
            pkg_path = os.path.dirname(os.path.abspath(kordialmabotu.__file__))
            source_folder = os.path.join(pkg_path, 'coordinates')
            if not os.path.exists(source_folder):
                self.log_message('Kaynak klasör bulunamadı: ' + source_folder, 'error')
                QMessageBox.critical(self, 'Hata', 'Kaynak klasör bulunamadı:\n' + source_folder)
                return
            user_profile = os.environ.get('USERPROFILE', '')
            if not user_profile:
                self.log_message('USERPROFILE bulunamadı!', 'error')
                return
            target_folder = os.path.join(user_profile, 'AppData', 'Roaming', '.sonoyuncu', 'mods')
            os.makedirs(target_folder, exist_ok=True)
            target_coordinates = os.path.join(target_folder, 'coordinates')
            if os.path.exists(target_coordinates):
                shutil.rmtree(target_coordinates)
            shutil.copytree(source_folder, target_coordinates)
            self.log_message('Gereksinimler başarıyla yüklendi: ' + target_coordinates, 'success')
            QMessageBox.information(self, 'Başarılı', 'Gereksinimler başarıyla yüklendi!\n\nHedef: ' + target_coordinates)
        except Exception as e:
            self.log_message('Gereksinimler yüklenirken hata oluştu: ' + str(e), 'error')
            QMessageBox.critical(self, 'Hata', 'Gereksinimler yüklenirken hata oluştu: ' + str(e))

    def start_coordinate(self):
        """Koordinat botunu başlat"""
        self.log_message('Koordinat alma botu başlatılıyor...', 'info')
        self.log_message('Bot başlatıldı! F8 tuşuna basarak botu aktif edin.', 'info')
        script_path = os.path.join('kordialmabotu', 'bot.py')
        if not os.path.exists(script_path):
            self.log_message("Koordinat alma script'i bulunamadı!", 'error')
            return
        self.run_script(script_path)

    def start_trade_bot(self):
        """Ticaret botunu başlat"""
        set_choice = self.trade_set_var
        ad_message = self.trade_message_var.text().strip()
        price = self.trade_price_var.text().strip()
        chest_enabled = self.trade_chest_var.isChecked()

        if not ad_message:
            QMessageBox.warning(self, 'Uyarı', 'Reklam mesajı boş olamaz!')
            return
        if not price.isdigit():
            QMessageBox.warning(self, 'Uyarı', 'Geçerli bir fiyat girin!')
            return

        script_path = os.path.join('ticaret_botu', 'ticaret.py')

        def run():
            try:
                bot_internal = 'ticaret'
                cmd = [sys.executable, script_path, '--run-bot', bot_internal]
                env = os.environ.copy()
                env['TRADE_SET'] = set_choice
                env['TRADE_PRICE'] = price
                env['TRADE_MESSAGE'] = ad_message
                env['TRADE_CHEST'] = '1' if chest_enabled else '0'
                self.log_message('DEBUG: Trade Bot Launch - Internal: ' + bot_internal + ', Path: ' + script_path, 'debug')
                self.log_message('DEBUG: Trade CMD: ' + ' '.join(cmd), 'debug')
                process = subprocess.Popen(
                    cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE,
                    text=True, bufsize=1, env=env, creationflags=CREATE_NO_WINDOW
                )
                with self.process_lock:
                    self.running_processes['Ticaret botu'] = process
                set_name = {'1': 'Tit Set', '2': 'Dia Set', '3': 'Duel Kiti'}.get(set_choice, set_choice)
                self.log_message('Set: ' + set_name + ', Fiyat: ' + price + ', Mesaj: ' + ad_message, 'info')
                self.log_message('Ticaret botu başlatıldı. F8 tuşuna basarak botu aktif edin.', 'success')

                def read_output():
                    try:
                        for line in process.stdout:
                            line = line.rstrip() if line else ''
                            if not line:
                                continue
                            line_clean = self.clean_ansi_codes(line)
                            line_lower = line_clean.lower()
                            if 'hata' in line_lower or '❌' in line_clean:
                                self.log_message(line_clean, 'error')
                            elif 'başarı' in line_lower or '✅' in line_clean or '[başlat]' in line_lower or '[baslat]' in line_lower:
                                self.log_message(line_clean, 'success')
                            elif 'uyarı' in line_lower or '⚠️' in line_clean or '[uyari]' in line_lower:
                                self.log_message(line_clean, 'warning')
                            else:
                                self.log_message(line_clean, 'info')
                    except Exception as e:
                        self.log_message('Output okuma hatası: ' + str(e), 'error')

                output_thread = Thread(target=read_output, daemon=True)
                output_thread.start()
                process.wait()
                with self.process_lock:
                    self.running_processes.pop('Ticaret botu', None)
            except Exception as e:
                self.log_message('Ticaret botu başlatma hatası: ' + str(e), 'error')
                self.log_message('Bot başlatılamadı: ' + str(e), 'error')

        Thread(target=run, daemon=True).start()

    def start_craft(self, item_name):
        """Craft işlemini başlat - Artık kullanılmıyor, direkt run_craft_script çağrılıyor"""
        self.run_craft_script(item_name, 1)

    def run_craft_script(self, item_name, dongu_sayisi):
        """Craft script'ini çalıştır"""
        script_paths = {
            'Deniz Feneri': 'denizfeneri.py',
            'Piston': 'piston.py',
            'Titanyum': 'titanyum.py',
        }
        script_path = script_paths.get(item_name)
        if not script_path:
            self.log_message('❌ ' + item_name + ' için script bulunamadı!', 'error')
            return

        def run():
            try:
                is_compiled = getattr(sys, 'frozen', False) or hasattr(sys, '__compiled__')
                friendly_name = self.get_script_friendly_name(script_path)
                self.log_message('🚀 ' + item_name + ' craft botu başlatılıyor... (Döngü: ' + str(dongu_sayisi) + ')', 'info')
                bot_internal = 'craft_' + item_name.lower().replace(' ', '_')
                cmd = [sys.executable, script_path, '--run-bot', bot_internal]
                self.log_message('DEBUG: Craft Launching: ' + ' '.join(cmd), 'debug')
                process = subprocess.Popen(
                    cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE,
                    text=True, bufsize=1, creationflags=CREATE_NO_WINDOW
                )
                process.stdin.write(str(dongu_sayisi) + '\n')
                process.stdin.flush()
                process.stdin.close()
                with self.process_lock:
                    self.running_processes[friendly_name] = process
                self.log_message(friendly_name + ' başlatıldı', 'success')
                self.log_message('✅ F8 tuşuna basarak botu başlatabilir/durdurebilirsiniz...', 'info')

                def read_output():
                    try:
                        for line in process.stdout:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'info')
                    except Exception as e:
                        self.log_message('Output okuma hatası: ' + str(e), 'error')

                def read_error():
                    try:
                        for line in process.stderr:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'error')
                    except Exception as e:
                        self.log_message('Error okuma hatası: ' + str(e), 'error')

                def wait_process():
                    try:
                        rc = process.wait()
                        self.log_message(friendly_name + ' tamamlandı (kod: ' + str(rc) + ')', 'info')
                        with self.process_lock:
                            self.running_processes.pop(friendly_name, None)
                    except Exception as e:
                        self.log_message('Process bekleme hatası: ' + str(e), 'error')

                Thread(target=read_output, daemon=True).start()
                Thread(target=read_error, daemon=True).start()
                Thread(target=wait_process, daemon=True).start()
            except Exception as e:
                self.log_message('Craft botu başlatma hatası: ' + str(e), 'error')

        Thread(target=run, daemon=True).start()

    def run_script(self, script_path):
        """Script çalıştır"""
        def run():
            try:
                friendly_name = self.get_script_friendly_name(script_path)
                with self.process_lock:
                    if friendly_name in self.running_processes:
                        if self.running_processes[friendly_name].poll() is None:
                            self.log_message(friendly_name + ' zaten çalışıyor', 'warning')
                            return
                actual_script_path = extract_script_if_needed(script_path)
                if not os.path.exists(actual_script_path):
                    self.log_message(script_path + ' bulunamadı', 'error')
                    return
                bot_internal = self.get_bot_internal_name(script_path)
                cmd = [sys.executable, actual_script_path]
                if bot_internal:
                    cmd.extend(['--run-bot', bot_internal])
                self.log_message('DEBUG: Launching CMD: ' + ' '.join(cmd).replace('\\', '/'), 'debug')
                env = os.environ.copy()
                if 'KORDI_AUTO_START' in os.environ:
                    env['KORDI_AUTO_START'] = os.environ['KORDI_AUTO_START']
                process = subprocess.Popen(
                    cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE,
                    text=True, bufsize=1, env=env, creationflags=CREATE_NO_WINDOW
                )
                with self.process_lock:
                    self.running_processes[friendly_name] = process
                self.log_message(friendly_name + ' başlatıldı', 'success')

                def read_output():
                    try:
                        for line in process.stdout:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'info')
                    except Exception as e:
                        self.log_message('Output okuma hatası: ' + str(e), 'error')

                def read_error():
                    try:
                        for line in process.stderr:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message('STDERR: ' + self.clean_ansi_codes(line), 'error')
                    except Exception as e:
                        self.log_message('Error okuma hatası: ' + str(e), 'error')

                def wait_process():
                    try:
                        rc = process.wait()
                        self.log_message(friendly_name + ' tamamlandı (kod: ' + str(rc) + ')', 'info')
                        with self.process_lock:
                            self.running_processes.pop(friendly_name, None)
                    except Exception as e:
                        self.log_message('Process bekleme hatası: ' + str(e), 'error')

                Thread(target=read_output, daemon=True).start()
                Thread(target=read_error, daemon=True).start()
                Thread(target=wait_process, daemon=True).start()
            except Exception as e:
                self.log_message('Bot başlatma hatası: ' + str(e), 'error')

        Thread(target=run, daemon=True).start()

    def run_script_with_books(self, script_path, selected_books, envanter_yenileme):
        """Kitap script'ini çalıştır"""
        def run():
            try:
                friendly_name = self.get_script_friendly_name(script_path)
                bot_internal = self.get_bot_internal_name(script_path)
                books_json = json.dumps(selected_books)
                cmd = [sys.executable, script_path]
                if bot_internal:
                    cmd.extend(['--run-bot', bot_internal])
                env = os.environ.copy()
                env['SELECTED_BOOKS'] = books_json
                env['ENVANTER_YENILEME'] = '1' if envanter_yenileme else '0'
                process = subprocess.Popen(
                    cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE,
                    text=True, bufsize=1, env=env, creationflags=CREATE_NO_WINDOW
                )
                with self.process_lock:
                    self.running_processes[friendly_name] = process
                self.log_message(friendly_name + ' başlatıldı', 'success')

                def read_output():
                    try:
                        for line in process.stdout:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'info')
                    except Exception as e:
                        self.log_message('Output okuma hatası: ' + str(e), 'error')

                def read_error():
                    try:
                        for line in process.stderr:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'error')
                    except Exception as e:
                        self.log_message('Error okuma hatası: ' + str(e), 'error')

                def wait_process():
                    try:
                        rc = process.wait()
                        self.log_message(friendly_name + ' tamamlandı (kod: ' + str(rc) + ')', 'info')
                        with self.process_lock:
                            self.running_processes.pop(friendly_name, None)
                    except Exception as e:
                        self.log_message('Process bekleme hatası: ' + str(e), 'error')

                Thread(target=read_output, daemon=True).start()
                Thread(target=read_error, daemon=True).start()
                Thread(target=wait_process, daemon=True).start()
            except Exception as e:
                self.log_message('Bot başlatma hatası: ' + str(e), 'error')

        Thread(target=run, daemon=True).start()

    def run_script_with_chest(self, script_path, chest_enabled):
        """Set script'ini çalıştır"""
        def run():
            try:
                friendly_name = self.get_script_friendly_name(script_path)
                self.log_message('DEBUG: Checking internal bot for: ' + script_path, 'debug')
                bot_internal = self.get_bot_internal_name(script_path)
                if bot_internal:
                    self.log_message('DEBUG: Found internal bot mapping: ' + bot_internal, 'debug')
                path_exists = os.path.exists(script_path)
                cmd = [sys.executable, script_path]
                if bot_internal:
                    cmd.extend(['--run-bot', bot_internal])
                env = os.environ.copy()
                env['CHEST_ENABLED'] = '1' if chest_enabled else '0'
                self.log_message('Script başlatılıyor: ' + script_path + ' - Chest: ' + ('AÇIK' if chest_enabled else 'KAPALI'), 'info')
                process = subprocess.Popen(
                    cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE,
                    text=True, bufsize=1, env=env, creationflags=CREATE_NO_WINDOW
                )
                with self.process_lock:
                    self.running_processes[friendly_name] = process
                self.log_message(friendly_name + ' başlatıldı', 'success')

                def read_output():
                    try:
                        for line in process.stdout:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'info')
                    except Exception as e:
                        self.log_message('Output okuma hatası: ' + str(e), 'error')

                def read_error():
                    try:
                        for line in process.stderr:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'error')
                    except Exception as e:
                        self.log_message('Error okuma hatası: ' + str(e), 'error')

                def wait_process():
                    try:
                        rc = process.wait()
                        self.log_message(friendly_name + ' tamamlandı (kod: ' + str(rc) + ')', 'info')
                        with self.process_lock:
                            self.running_processes.pop(friendly_name, None)
                    except Exception as e:
                        self.log_message('Process bekleme hatası: ' + str(e), 'error')

                Thread(target=read_output, daemon=True).start()
                Thread(target=read_error, daemon=True).start()
                Thread(target=wait_process, daemon=True).start()
            except Exception as e:
                self.log_message('Bot başlatma hatası: ' + str(e), 'error')

        Thread(target=run, daemon=True).start()

    def run_script_with_input(self, script_path, input_value):
        """Script'i input ile çalıştır"""
        def run():
            try:
                friendly_name = self.get_script_friendly_name(script_path)
                bot_internal = self.get_bot_internal_name(script_path)
                base_path = get_base_path()
                python_embedded = os.path.join(base_path, 'python.exe')
                python_exe = python_embedded if os.path.exists(python_embedded) else sys.executable
                cmd = [python_exe, script_path]
                if bot_internal:
                    cmd.extend(['--run-bot', bot_internal])
                process = subprocess.Popen(
                    cmd, stdin=PIPE, stdout=PIPE, stderr=PIPE,
                    text=True, bufsize=1, creationflags=CREATE_NO_WINDOW
                )
                if input_value is not None:
                    process.stdin.write(str(input_value) + '\n')
                    process.stdin.flush()
                process.stdin.close()
                with self.process_lock:
                    self.running_processes[friendly_name] = process
                self.log_message(friendly_name + ' başlatıldı', 'success')

                def read_output():
                    try:
                        for line in process.stdout:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'info')
                    except Exception as e:
                        self.log_message('Output okuma hatası: ' + str(e), 'error')

                def read_error():
                    try:
                        for line in process.stderr:
                            line = line.rstrip() if line else ''
                            if line:
                                self.log_message(self.clean_ansi_codes(line), 'error')
                    except Exception as e:
                        self.log_message('Error okuma hatası: ' + str(e), 'error')

                def wait_process():
                    try:
                        rc = process.wait()
                        self.log_message(friendly_name + ' tamamlandı (kod: ' + str(rc) + ')', 'info')
                        with self.process_lock:
                            self.running_processes.pop(friendly_name, None)
                    except Exception as e:
                        self.log_message('Process bekleme hatası: ' + str(e), 'error')

                Thread(target=read_output, daemon=True).start()
                Thread(target=read_error, daemon=True).start()
                Thread(target=wait_process, daemon=True).start()
            except Exception as e:
                self.log_message('Bot başlatma hatası: ' + str(e), 'error')

        Thread(target=run, daemon=True).start()

    def stop_all_scripts(self):
        """Tüm çalışan script'leri durdur"""
        stopped_count = 0
        with self.process_lock:
            if not self.running_processes:
                self.log_message('Durdurulacak çalışan script yok.', 'info')
                return
            for script_path, process in list(self.running_processes.items()):
                try:
                    process.terminate()
                    try:
                        process.wait(timeout=3)
                    except Exception:
                        process.kill()
                    stopped_count += 1
                    self.log_message('Script durduruldu: ' + script_path, 'info')
                except Exception as e:
                    self.log_message('Script durdurma hatası (' + script_path + '): ' + str(e), 'error')
            self.running_processes.clear()
        self.log_message('Toplam ' + str(stopped_count) + ' script durduruldu.', 'info')

    def setup_keyboard_listener(self):
        """F12 tuşu için keyboard listener"""
        def on_press(key):
            try:
                if key == keyboard.Key.f12:
                    self.stop_all_scripts()
            except Exception:
                pass

        def listener_thread():
            with keyboard.Listener(on_press=on_press) as listener:
                listener.join()

        self.kb_thread = Thread(target=listener_thread, daemon=True)
        self.kb_thread.start()

    def clean_ansi_codes(self, text):
        """ANSI escape kodlarını temizle"""
        ansi_escape = re.compile('\x1b\\[[0-9;]*[a-zA-Z]')
        return ansi_escape.sub('', text)

    def decode_utf8_safe(self, text):
        """UTF-8 encoding ile güvenli decode"""
        if isinstance(text, bytes):
            try:
                return text.decode('utf-8', errors='replace')
            except Exception:
                try:
                    return text.decode('cp1254', errors='replace')
                except Exception:
                    return text.decode('latin-1', errors='replace')
        return str(text)

    def get_bot_internal_name(self, script_path):
        """Script path'inden internal bot ismini al (bot_dispatcher için)"""
        p = script_path.replace('\\', '/').lower()
        if 'diaset' in p:
            return 'diaset'
        if 'titset' in p:
            return 'titset'
        if 'kitap' in p:
            return 'kitap'
        if 'kazma' in p or 'kurek' in p or 'kazma_kurek_kilic' in p:
            return 'kazma_kurek_kilic'
        if 'ciftci' in p:
            return 'ciftci'
        if 'ticaret' in p:
            return 'ticaret'
        if 'kordi' in p or 'bot.py' in p:
            return 'kordi'
        if 'deniz' in p:
            return 'craft_denizfeneri'
        if 'piston' in p:
            return 'craft_piston'
        if 'titanyum' in p:
            return 'craft_titanyum'
        return 'craft'

    def get_script_friendly_name(self, script_path):
        """Script path'inden anlaşılır isim al"""
        p = script_path.replace('\\', '/').lower()
        if 'diaset' in p:
            return 'Diamond Set botu'
        if 'titset' in p:
            return 'Titanyum Set botu'
        if 'kazma' in p or 'kurek' in p or 'kilic' in p:
            return 'Alet botu'
        if 'kitap' in p:
            return 'Kitap botu'
        if 'ciftci' in p:
            return 'Çiftçi botu'
        if 'kordi' in p:
            return 'Koordinat botu'
        if 'ticaret' in p:
            return 'Ticaret botu'
        if 'denizf' in p or 'denizfeneri' in p:
            return 'Deniz Feneri craft botu'
        if 'piston' in p:
            return 'Piston craft botu'
        if 'titanyum' in p:
            return 'Titanyum craft botu'
        return 'Craft botu'

    def log_message(self, message, log_type='info'):
        """Renkli log mesajı"""
        try:
            self.log_text.append_log(message, log_type)
        except Exception:
            pass

    def nav_discord(self):
        """Discord linkini aç"""
        try:
            webbrowser.open('https://discord.gg/norsia')
        except Exception as e:
            self.log_message('Discord açılamadı: ' + str(e), 'error')

    def nav_youtube(self):
        """Youtube linkini aç"""
        try:
            webbrowser.open('https://www.youtube.com/@BayAhahnet')
        except Exception as e:
            self.log_message('Youtube açılamadı: ' + str(e), 'error')

    def nav_log_file(self):
        """Log dosyası aç"""
        self.log_message('Log dosyası açılıyor...', 'info')
        try:
            log_path = os.path.join(get_base_path(), 'crash_log.txt')
            if os.path.exists(log_path):
                os.startfile(log_path)
            else:
                self.log_message('Log dosyası bulunamadı: ' + log_path, 'warning')
        except Exception as e:
            self.log_message('Log dosyası açılamadı: ' + str(e), 'error')

    def save_webhook(self):
        """Webhook'u kaydet"""
        webhook_url = self.webhook_var.text().strip()
        if not webhook_url:
            QMessageBox.warning(self, 'Uyarı', 'Webhook URL boş olamaz!')
            return
        if not webhook_url.startswith('https://discord.com/api/webhooks/'):
            QMessageBox.warning(self, 'Uyarı', 'Geçersiz webhook URL formatı!\n\nDoğru format: https://discord.com/api/webhooks/...')
            return
        try:
            import auth_system
            if auth_system.save_user_webhook(webhook_url):
                self.log_message('Webhook başarıyla kaydedildi!', 'success')
                self.log_message('Discord webhook kaydedildi', 'success')
            else:
                self.log_message('Webhook kaydedilemedi!', 'error')
                QMessageBox.critical(self, 'Hata', 'Webhook kaydedilemedi!')
        except Exception as e:
            self.log_message('Bir hata oluştu: ' + str(e), 'error')
            QMessageBox.critical(self, 'Hata', 'Bir hata oluştu: ' + str(e))

    def format_remaining_time(self, remaining):
        """Kalan süreyi formatla"""
        total_seconds = int(remaining)
        days = total_seconds // 86400
        hours = total_seconds % 86400 // 3600
        minutes = total_seconds % 3600 // 60
        if days > 0:
            return str(days) + ' gün ' + str(hours) + ' saat ' + str(minutes) + ' dakika'
        if hours > 0:
            return str(hours) + ' saat ' + str(minutes) + ' dakika'
        return str(minutes) + ' dakika'

    def update_window_title(self):
        """Pencere başlığını güncelle"""
        try:
            if self.expires_at:
                exp_date = datetime.fromisoformat(str(self.expires_at))
                remaining = (exp_date - datetime.now()).total_seconds()
                if remaining > 0:
                    time_str = self.format_remaining_time(remaining)
                    self.setWindowTitle('Norsia Client - Kalan Süre: ' + time_str)
                else:
                    self.setWindowTitle('Norsia Client - Süre Dolmuş')
            else:
                self.setWindowTitle('Norsia Client')
        except Exception:
            self.setWindowTitle('Norsia Client')

    def closeEvent(self, event):
        """GUI kapatılırken çalışan botları durdur ve çık."""
        try:
            self.stop_all_scripts()
        except Exception as e:
            self.log_message('Kapatma sırasında hata: ' + str(e), 'error')
        event.accept()
        super().closeEvent(event)
        # 3 saniye sonra zorla çık
        def force_exit():
            os._exit(0)
        t = Thread(target=lambda: (time.sleep(3.0), force_exit()), daemon=True)
        t.start()
        try:
            app = QApplication.instance()
            if app:
                app.quit()
        except Exception:
            pass


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = ModernGUI()
    window.show()
    sys.exit(app.exec())
