"""Bot dispatcher - botları isme göre çalıştırır."""
import sys
import os
import importlib
import multiprocessing
import threading
import time
import traceback

# Ana klasörü Python path'ine ekle
sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class dakika_value:
    """Dakika değerini tutan basit sınıf."""
    pass


def run_bot(bot_name, args=None):
    """
    Run a specific bot based on its name.
    args: list of arguments passed to the bot (similar to sys.argv)
    """
    if args is None:
        args = sys.argv

    bot_name = (bot_name or '').strip()

    try:
        # Büyü botları (buyu paketi)
        if bot_name == 'diaset':
            from buyu import diaset
            diaset.run()
            return

        if bot_name == 'titset':
            from buyu import titset
            titset.run()
            return

        if bot_name == 'kitap':
            from buyu import kitap
            if hasattr(kitap, 'run'):
                kitap.run()
            else:
                print('Error: kitap.py does not have a run function')
            return

        if bot_name == 'kazma_kurek_kilic':
            from buyu import kazma_kurek_kilic
            kazma_kurek_kilic.run()
            return

        # Çiftçi satma botu
        if bot_name == 'ciftci':
            from ciftci_satma import ciftci_bot
            # Dakika parametresi stdin'den okunur
            if sys.stdin.isatty():
                line = sys.stdin.readline().strip()
                try:
                    dakika_value = int(line) if line else 60
                except ValueError:
                    dakika_value = 60
            else:
                dakika_value = 60
            main_thread = threading.Thread(target=ciftci_bot.main, args=(dakika_value,), daemon=True)
            main_thread.start()
            # Klavye dinleyici
            kb_thread = threading.Thread(target=ciftci_bot.keyboard_listener, daemon=True)
            kb_thread.start()
            # Bot bitene kadar bekle
            while main_thread.is_alive():
                time.sleep(1)
            return

        # Ticaret botu
        if bot_name == 'ticaret':
            from ticaret_botu import ticaret
            main_thread = threading.Thread(target=ticaret.run, daemon=True)
            main_thread.start()
            kb_thread = threading.Thread(target=ticaret.keyboard_listener, daemon=True)
            kb_thread.start()
            while main_thread.is_alive():
                time.sleep(1)
            return

        # Koord alma botu
        if bot_name == 'kordialmabotu' or bot_name == 'bot':
            from kordialmabotu import bot
            # game_thread + keyboard_listener_thread başlat
            if hasattr(bot, 'auto_start_if_configured'):
                bot.auto_start_if_configured()
            game_thread = threading.Thread(target=bot.start_bot_with_f8, daemon=True)
            game_thread.start()
            keyboard_thread = threading.Thread(target=bot.keyboard_listener_thread, daemon=True)
            keyboard_thread.start()
            while game_thread.is_alive():
                time.sleep(1)
            return

        # Craft. ile başlıyorsa dinamik import
        if bot_name.startswith('craft_'):
            module_name = bot_name.replace('craft_', '')
            mod = importlib.import_module('Craft.' + module_name)
            if hasattr(mod, 'run'):
                mod.run()
            return

        print('Unknown bot name: ' + bot_name)

    except SystemExit:
        raise
    except Exception as e:
        print('CRITICAL ERROR in bot_dispatcher: ', e)
        traceback.print_exc()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    # Komut satırı: --run-bot <bot_ismi> [ek args...]
    if len(sys.argv) >= 3 and sys.argv[1] == '--run-bot':
        name = sys.argv[2]
        extra = sys.argv[3:]
        run_bot(name, extra)
    else:
        print('Kullanım: python bot_dispatcher.py --run-bot <bot_ismi>')
