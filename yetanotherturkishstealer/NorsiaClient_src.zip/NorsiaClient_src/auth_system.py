"""Kimlik doğrulama ve HWID sistemi"""
import os
from datetime import datetime, timedelta
import requests
import discord_logger
import hashlib
import json
import uuid

SETTINGS_FILE = 'settings.json'
API_URL = 'http://188.240.81.35:5000'
API_ENDPOINTS = {
    'login': '/login',
    'register': '/register',
    'extend': '/extend',
    'validate': '/validate',
}


def get_hwid():
    """HWID (Hardware ID) al"""
    return str(uuid.getnode())


def hash_password(password):
    """Şifreyi hash'le"""
    return hashlib.sha256(str(password).encode('utf-8')).hexdigest()


def login(username, password):
    """
    Kullanıcı girişi yap
    Returns: (success: bool, message: str, data: dict)
    """
    hwid = get_hwid()
    password_hash = hash_password(password)
    try:
        response = requests.post(
            API_URL + API_ENDPOINTS['login'],
            json={'username': username, 'password': password_hash, 'hwid': hwid},
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                expires_at = data.get('expires_at', '')
                extra_info = {'expires_at': expires_at[:8] + '...'}
                try:
                    discord_logger.send_auth_log('login', username, True, 'Giriş başarılı!', extra_info)
                except Exception:
                    pass
                user_data = {'username': username, 'expires_at': expires_at}
                return (True, 'Giriş başarılı!', user_data)
            else:
                message = data.get('message', 'Giriş başarısız!')
                try:
                    discord_logger.send_auth_log('login', username, False, message, None)
                except Exception:
                    pass
                return (False, message, None)
        elif response.status_code == 401:
            return (False, 'Kullanıcı adı veya şifre hatalı!', None)
        elif response.status_code == 403:
            return (False, 'Erişim reddedildi! HWID uyuşmazlığı veya süreniz dolmuş olabilir.', None)
        elif response.status_code == 404:
            return (False, 'Kullanıcı bulunamadı!', None)
        else:
            return (False, 'Sunucu hatası: ' + str(response.status_code), None)
    except requests.exceptions.ConnectionError:
        return (False, 'Sunucuya ulaşılamadı! İnternet bağlantınızı kontrol edin veya daha sonra tekrar deneyin.', None)
    except requests.exceptions.RequestException:
        return (False, 'Sunucuya bağlanılamadı! Lütfen internet bağlantınızı kontrol edin.', None)


def register(username, password, key):
    """
    Yeni kullanıcı kaydı yap
    Returns: (success: bool, message: str)
    """
    hwid = get_hwid()
    password_hash = hash_password(password)
    try:
        response = requests.post(
            API_URL + API_ENDPOINTS['register'],
            json={'username': username, 'password': password_hash, 'key': key, 'hwid': hwid},
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                expires_at = data.get('expires_at', '')
                key_display = key[:4] + '...' + key[-4:]
                extra_info = {'expires_at': expires_at, 'key': key_display}
                try:
                    discord_logger.send_auth_log('register', username, True, data.get('message', 'Kayıt başarılı!'), extra_info)
                except Exception:
                    pass
                return (True, data.get('message', 'Kayıt başarılı!'))
            else:
                message = data.get('message', 'Kayıt başarısız!')
                try:
                    discord_logger.send_auth_log('register', username, False, message, None)
                except Exception:
                    pass
                return (False, message)
        elif response.status_code == 400:
            return (False, 'Geçersiz istek! Lütfen tüm alanları doldurun.')
        elif response.status_code == 403:
            return (False, 'Key geçersiz veya kullanılmış!')
        else:
            return (False, 'Sunucu hatası: ' + str(response.status_code))
    except requests.exceptions.ConnectionError:
        return (False, 'Sunucuya ulaşılamadı! İnternet bağlantınızı kontrol edin.')
    except requests.exceptions.RequestException:
        return (False, 'Sunucuya bağlanılamadı! Lütfen internet bağlantınızı kontrol edin.')


def extend_time(username, key):
    """
    Süre uzat
    Returns: (success: bool, message: str)
    """
    hwid = get_hwid()
    try:
        response = requests.post(
            API_URL + API_ENDPOINTS['extend'],
            json={'username': username, 'key': key, 'hwid': hwid},
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                expires_at = data.get('expires_at', '')
                key_display = key[:4] + '...' + key[-4:]
                extra_info = {'expires_at': expires_at, 'key': key_display}
                try:
                    discord_logger.send_auth_log('extend', username, True, data.get('message', 'Süre uzatıldı!'), extra_info)
                except Exception:
                    pass
                return (True, data.get('message', 'Süre uzatıldı!'))
            else:
                message = data.get('message', 'Süre uzatma başarısız!')
                try:
                    discord_logger.send_auth_log('extend', username, False, message, None)
                except Exception:
                    pass
                return (False, message)
        elif response.status_code == 400:
            return (False, 'Geçersiz istek! Key gerekli.')
        elif response.status_code == 403:
            return (False, 'HWID uyuşmazlığı!')
        else:
            return (False, 'Sunucu hatası: ' + str(response.status_code))
    except requests.exceptions.ConnectionError:
        return (False, 'Sunucuya ulaşılamadı! İnternet bağlantınızı kontrol edin.')
    except requests.exceptions.RequestException:
        return (False, 'Sunucuya bağlanılamadı! Lütfen internet bağlantınızı kontrol edin.')


def load_settings():
    """Yerel ayarları yükle (sadece webhook URL için)"""
    try:
        with open(SETTINGS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(data):
    """Yerel ayarları kaydet"""
    try:
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print('Ayar kaydetme hatası: ', e)
        return False


def check_session():
    """Mevcut oturumu kontrol et - Her zaman False döner (güvenlik için)"""
    return (False, None)


def get_remaining_time():
    """Kalan süreyi al - Artık user_data.json kullanılmadığı için None döner"""
    return None


def get_user_webhook():
    """Kullanıcının webhook'unu al (settings.json'dan)"""
    settings = load_settings()
    return settings.get('webhook_url', '')


def save_user_webhook(webhook_url):
    """Kullanıcının webhook'unu kaydet (settings.json'a)"""
    settings = load_settings()
    settings['webhook_url'] = webhook_url
    return save_settings(settings)
