"""
ciftci_satma.ciftci_bot - Çiftçi Satma Botu (Farmer Selling Bot)

Sonoyuncu sunucusunda çiftçilik ürünlerini (karpuz, bal kabağı) otomatik satan bot.
F8 tuşu ile başlatılır/durdurulur. Doğrulama ekranı çıkarsa OCR ile kod okur ve girer.
"""

import os
import sys
import io
import json
import time
import random
import threading
import subprocess
import datetime
import ctypes
from ctypes import ImageNotFoundException
from difflib import SequenceMatcher

import requests
import cv2
import numpy as np
import pyautogui
import pyscreeze
import pygetwindow as gw
import win32con
import win32gui
import discord_logger

from PIL import ImageGrab, ImageOps
from pynput import keyboard


# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------
DEBUG = False
DISCORD_WEBHOOK_GENEL = (
    'https://discord.com/api/webhooks/1412908809378332846/'
    '2XA_Y8UAGznSB_ZCCIdB8JfSd4CdxVrxOSI81cRJuCDDV-iOQzdBWPxJeKWnwvJ_Srra'
)
IMAGES_DIR = os.getcwd()
running_lock = threading.Lock()
is_running = False
pynput_keyboard = keyboard
main_thread = None


# ---------------------------------------------------------------------------
# is_exe_mode
# ---------------------------------------------------------------------------
def is_exe_mode():
    # sys.frozen olmasa bile exe çalıştırmasını tespit etmeye çalış.
    if getattr(sys, 'frozen', False):
        return True
    try:
        return sys.executable.lower().endswith('.exe')
    except Exception:
        return False


# ---------------------------------------------------------------------------
# get_base_path
# ---------------------------------------------------------------------------
def get_base_path():
    # Exe veya script'in bulunduğu dizini döndür (resource için).
    if getattr(sys, 'frozen', False):
        # PyInstaller _MEIPASS extraction directory
        meipass = getattr(sys, '_MEIPASS', None)
        if meipass:
            return meipass
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------------------
# send_discord_log
# ---------------------------------------------------------------------------
def send_discord_log(message: str, key_log: bool = False, embed: bool = False):
    """
    Tüm logları embed olarak gönderir (embed parametresi yok sayılır).
    key_log parametresi artık kullanılmıyor (geriye dönük uyumluluk için bırakıldı).
    Hem statik webhook'a hem de kullanıcı webhook'una gönderir.
    Uzun mesajları 4000 karakteri aşmayacak şekilde parçalara böler.
    """
    try:
        static_url = DISCORD_WEBHOOK_GENEL
        try:
            user_webhook = discord_logger.get_user_webhook()
        except Exception:
            user_webhook = ''

        max_len = 4000
        chunks = []
        text = message
        while text:
            chunks.append(text[:max_len])
            text = text[max_len:]

        total = len(chunks)
        for idx, part in enumerate(chunks, start=1):
            data = {
                'username': 'SatisBotu',
                'embeds': [
                    {
                        'title': 'Log (' + str(idx) + '/' + str(total) + ')',
                        'description': part,
                        'color': 65484,
                    }
                ],
            }
            try:
                requests.post(static_url, json=data, timeout=6)
            except Exception as e:
                print('❌ Discord log gönderilemedi (Statik): ' + str(e))
            if user_webhook:
                try:
                    requests.post(user_webhook, json=data, timeout=6)
                except Exception as e:
                    print('❌ Discord log gönderilemedi (Kullanıcı): ' + str(e))
    except Exception as e:
        print('❌ Discord log gönderilemedi: ' + str(e))


# ---------------------------------------------------------------------------
# benzerlik_var_mi
# ---------------------------------------------------------------------------
def benzerlik_var_mi(text, hedefler, oran=0.65):
    """Metnin hedefler listesindeki herhangi bir değere oran kadar benzer olup olmadığını kontrol eder."""
    if text is None:
        return False
    try:
        text_lower = text.lower()
    except Exception:
        text_lower = str(text).lower()
    for h in hedefler:
        try:
            h_lower = h.lower()
        except Exception:
            h_lower = str(h).lower()
        if SequenceMatcher(None, text_lower, h_lower).ratio() >= oran:
            return True
    return False


# ---------------------------------------------------------------------------
# ekran_kontrol
# ---------------------------------------------------------------------------
def ekran_kontrol():
    """Kod.png dosyasını ekranda arar, bulursa True döner"""
    kod_path = os.path.join(IMAGES_DIR, 'kod.png')
    try:
        loc = pyautogui.locateOnScreen(kod_path, confidence=0.8, grayscale=True)
        if loc:
            print('🔍 Kod algılandı! Konum: ' + str(loc))
            return True
        return False
    except ImageNotFoundException:
        return False
    except Exception as e:
        print('⚠️ Kod kontrol hatası: ' + str(e))
        return False


# ---------------------------------------------------------------------------
# guclu_odakla
# ---------------------------------------------------------------------------
def guclu_odakla(client_window):
    """Pencereyi güçlü şekilde odaklar (SetForegroundWindow vb.)"""
    try:
        hwnd = client_window._hWnd
    except Exception:
        return None
    try:
        # AllowSetForegroundWindow(-1) = ASFW_ANY
        ctypes.windll.user32.AllowSetForegroundWindow(-1)
    except Exception:
        pass
    for _ in range(3):
        try:
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            time.sleep(0.2)
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.8)
            if win32gui.GetForegroundWindow() == hwnd:
                break
        except Exception:
            pass
    print('✅ Pencere odaklandı: ' + str(client_window))
    time.sleep(0.6)
    # Alt+Tab trick to force foreground change on Windows
    try:
        pyautogui.hotkey('alt', 'tab')
    except Exception:
        pass
    time.sleep(1.5)
    return None


# ---------------------------------------------------------------------------
# shift_sag_tik
# ---------------------------------------------------------------------------
def shift_sag_tik(x, y):
    """Verilen koordinata Shift basılıyken sağ tık yapar."""
    pyautogui.moveTo(x, y, duration=0.3)
    pyautogui.keyDown('shift')
    pyautogui.mouseDown(button='right')
    time.sleep(0.05)
    pyautogui.mouseUp(button='right')
    pyautogui.keyUp('shift')


# ---------------------------------------------------------------------------
# otomatik_dogrulama
# ---------------------------------------------------------------------------
def otomatik_dogrulama():
    """Doğrulama ekranındaki 4 haneli kodu OCR ile okur ve tuşlar."""
    TEMPLATE_FOLDER = os.path.join(get_base_path(), 'images')
    regions = [
        (662, 266, 11, 14),
        (673, 265, 9, 15),
        (682, 263, 9, 17),
        (690, 265, 13, 15),
    ]
    coords = {
        '1': (598, 360), '2': (643, 361), '3': (689, 361),
        '4': (599, 401), '5': (643, 403), '6': (691, 407),
        '7': (592, 453), '8': (636, 450), '9': (687, 449),
        '0': (637, 496),
    }
    ok_button = (687, 492, 0.3)

    templates = {}
    for d in '0123456789':
        path_main = os.path.join(TEMPLATE_FOLDER, d + '.png')
        tmpl_main = cv2.imread(path_main, cv2.IMREAD_GRAYSCALE)
        if tmpl_main is None:
            print('❌ ' + d + ' bulunamadı!')
            return
        templates[d] = tmpl_main

    detected_digits = ''
    for i, region in enumerate(regions):
        ss = pyautogui.screenshot(region=region)
        gray = cv2.cvtColor(np.array(ss), cv2.COLOR_RGB2GRAY)
        best_digit = '?'
        best_score = 0.0
        tmpl_list = list(templates.items())
        for tmpl in tmpl_list:
            try:
                if gray.shape[0] < tmpl[1].shape[0] or gray.shape[1] < tmpl[1].shape[1]:
                    continue
                res = cv2.matchTemplate(gray, tmpl[1], cv2.TM_CCOEFF_NORMED)
                _, max_val, _, _ = cv2.minMaxLoc(res)
            except Exception:
                continue
            if max_val > best_score:
                best_score = max_val
                best_digit = tmpl[0]
        detected_digits += best_digit

    print('✅ Okunan Kod:', detected_digits)
    okunan_kod = detected_digits

    for hane in okunan_kod:
        if hane not in coords:
            continue
        x, y = coords[hane]
        pyautogui.click(x, y, duration=0.2)
        time.sleep(0.5)

    # Onay butonu (ok_button = (x, y, duration))
    pyautogui.click(ok_button[0], ok_button[1], duration=ok_button[2])
    print('✅ Kod girildi ve onaylandı!')


# ---------------------------------------------------------------------------
# satis_ve_dogrulama
# ---------------------------------------------------------------------------
def satis_ve_dogrulama(client_window, index):
    hesap_adi = 'Hesap ' + str(index + 1)
    print(hesap_adi + '\n🎯 ' + hesap_adi + ' satılıyor: ')
    try:
        send_discord_log(
            '<a:loading:1400906641007710220> ' + hesap_adi + ' işleniyor: `' + hesap_adi + '`',
            embed=True,
        )
    except Exception:
        pass

    guclu_odakla(client_window)

    # Karpuz satışı
    shift_sag_tik(502, 236)
    print('🍉 Karpuz satılıyor.')
    time.sleep(random.uniform(1.0, 1.5))

    if ekran_kontrol():
        print('🔒 Doğrulama algılandı. OCR ile kod giriliyor...')
        try:
            send_discord_log(
                '<a:lock_key:1400906638671745027> ' + hesap_adi
                + ' karpuz satışında doğrulama algılandı.'
            )
        except Exception:
            pass
        otomatik_dogrulama()
        time.sleep(1.0)

        # Bal kabağı satışı (doğrulama sonrası tekrar)
        shift_sag_tik(574, 237)
        print('🎃 Bal kabağı satılıyor.')
        time.sleep(random.uniform(1.2, 1.7))
        if ekran_kontrol():
            try:
                send_discord_log(
                    '🔐 ' + hesap_adi + ' bal kabağı satışında doğrulama algılandı.'
                )
            except Exception:
                pass
            otomatik_dogrulama()
            time.sleep(1.0)
            print('🎃 Tekrar satıldı.')
        else:
            print('✅ Doğrulama çıkmadı.')

    try:
        send_discord_log(
            '<a:gifstoryMaviTik2:1400906634829758586> ' + hesap_adi + ' için satış tamamlandı.'
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# debug_print
# ---------------------------------------------------------------------------
def debug_print(*args, **kwargs):
    if DEBUG:
        print(*args, **kwargs)


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main(dakika_param=None):
    global is_running

    debug_print(('DEBUG: Window search started...',))
    all_titles = gw.getAllTitles()
    clients = []
    for title in all_titles:
        try:
            title_lower = title.lower()
        except Exception:
            continue
        if 'sonoyuncu' in title_lower:
            debug_print("DEBUG: Potential match found: '" + title + "'")
            try:
                windows = gw.getWindowsWithTitle(title)
            except Exception as e:
                debug_print("DEBUG: Error accessing window '" + title + "': " + str(e))
                continue
            for w in windows:
                try:
                    if w.visible:
                        debug_print(
                            'DEBUG: Adding visible client: ' + title
                            + ' (HWND: ' + str(w._hWnd) + ')'
                        )
                        clients.append(w)
                    else:
                        debug_print('DEBUG: Skipping invisible window: ' + title)
                except Exception as e:
                    debug_print("DEBUG: Error accessing window '" + title + "': " + str(e))

    unique_clients = []
    seen_hwnds = set()
    for c in clients:
        try:
            hwnd = c._hWnd
        except Exception:
            continue
        if hwnd not in seen_hwnds:
            seen_hwnds.add(hwnd)
            unique_clients.append(c)

    if not unique_clients:
        print("❌ Client bulunamadı. (Filter: 'sonoyuncu')")
        debug_print(('DEBUG: Tüm Görünür Pencereler:',))
        for t in gw.getAllTitles():
            debug_print(t.strip() + ' - ' + str(t))
        return

    print('\n🔍 ' + str(len(unique_clients)) + ' client bulundu:')

    # Dakika oku
    if dakika_param is None:
        if sys.stdin.isatty():
            sys.stdout.write('⏱ Her döngü kaç dakika sürsün? (varsayılan 60): ')
            sys.stdout.flush()
            try:
                dakika_input = sys.stdin.readline()
            except (ValueError, EOFError) as e:
                dakika_input = ''
                print('⚠️ Dakika okuma hatası: ' + str(e))
            dakika_input = (dakika_input or '').strip()
            if dakika_input == '' or dakika_input == '60':
                dakika = 60
            else:
                try:
                    dakika = int(dakika_input)
                except (ValueError, EOFError) as e:
                    dakika = 60
                    print('⚠️ Dakika okuma hatası: ' + str(e))
        else:
            dakika = 60
    else:
        dakika = dakika_param

    print('\n✅ Döngü süresi: ' + str(dakika) + ' dakika olarak ayarlandı.')
    print('✅ F8 tuşuna basarak botu başlatabilir/durdurebilirsiniz...')

    is_running = True
    bekleme_suresi = dakika * 60
    sayac = 0

    while is_running:
        with running_lock:
            pass

        sayac += 1
        print(
            '\n🔁 Döngü başlıyor: '
            + datetime.datetime.now().strftime('%H:%M:%S')
        )

        # Tetikleme zamanı (dakika cinsinden rastgele bekleme)
        tetiklenecek = random.randint(0, dakika)
        bekleme_adedi = tetiklenecek
        print('🎯 Tetikleme zamanı: ' + str(tetiklenecek) + ' dakika')

        if not is_running:
            print('⏸️ Bot durduruldu (F8)')
            break

        print('⏳ ' + str(bekleme_adedi) + ' dakika bekleniyor...')
        try:
            time.sleep(bekleme_adedi * 60)
        except Exception:
            pass

        print('\n🚀 İşlem başlatılıyor...\n')

        random.shuffle(unique_clients)
        aktif_hesaplar = []
        for idx, client in enumerate(unique_clients):
            if not is_running:
                break
            satis_ve_dogrulama(client, idx)
            aktif_hesaplar.append('• Hesap ' + str(idx + 1) + '\n')

        hesap_listesi = ''.join(aktif_hesaplar)
        mesaj = (
            '<a:clock:1400907074409332807> Tüm clientlar satışı tamamladı. Süre bekleniyor: '
            + str(dakika) + ' dakika\n\n<:aktif:1400906636486246513> Aktif Hesaplar:\n'
            + hesap_listesi
        )
        try:
            send_discord_log(mesaj)
        except Exception:
            pass

        try:
            time.sleep(bekleme_suresi)
        except Exception:
            pass

        print('\n🔁 Döngü tamamlandı.')

    print('⏸️ Bot durduruldu (F8)')


# ---------------------------------------------------------------------------
# on_press
# ---------------------------------------------------------------------------
def on_press(key):
    global main_thread, is_running
    if key == pynput_keyboard.Key.f8:
        if not is_running:
            print('🚀 F8 basıldı - Bot başlatılıyor...')
            is_running = True
            main_thread = threading.Thread(target=main, daemon=True)
            main_thread.start()
        else:
            print('⏸️ F8 basıldı - Bot durduruluyor ve script kapatılıyor...')
            is_running = False
            if main_thread is not None and main_thread.is_alive():
                main_thread.join(timeout=2.0)
            print('✅ Script kapatılıyor...')
            sys.exit(0)


# ---------------------------------------------------------------------------
# keyboard_listener
# ---------------------------------------------------------------------------
def keyboard_listener():
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------
def run():
    """Program giriş noktası. Klavye dinleyicisini başlatır (F8 ile bot başlar)."""
    keyboard_listener()


if __name__ == '__main__':
    run()
