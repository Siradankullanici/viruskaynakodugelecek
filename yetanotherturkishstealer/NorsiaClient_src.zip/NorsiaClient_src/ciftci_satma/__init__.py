"""ciftci_satma paketi - Çiftçi satma botu."""
