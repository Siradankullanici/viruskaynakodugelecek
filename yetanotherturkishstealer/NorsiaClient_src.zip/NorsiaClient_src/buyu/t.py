"""buyu.t - PIN kodu OCR ve giriş modülü.

Ekran görüntüsünden rakam tanır ve ilgili koordinatlara tıklayarak
PIN kodunu otomatik girer.
"""
import sys
import io
import cv2
import pyautogui
import numpy as np
import os
import time

# UTF-8 stdout/stderr
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

DEBUG = False

# Şablonların bulunduğu klasör
TEMPLATE_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'images')


def debug_print(*args, **kwargs):
    """DEBUG modunda print basar."""
    if DEBUG:
        print(*args, **kwargs)


# PIN hanesi için ekran bölgeleri (x, y, w, h)
regions = [
    (662, 266, 11, 14),
    (673, 265, 9, 15),
    (682, 263, 9, 17),
    (690, 265, 13, 15),
]

# Rakam → tıklanacak koordinat
coords = {
    '1': (598, 360),
    '2': (643, 361),
    '3': (689, 361),
    '4': (599, 401),
    '5': (643, 403),
    '6': (691, 407),
    '7': (592, 453),
    '8': (636, 450),
    '9': (687, 449),
    '0': (637, 496),
}

# OK butonu koordinatı
ok_button = (687, 492)


def read_pin():
    """Ekrandaki 4 haneli PIN kodunu OCR ile okur."""
    time.sleep(1)
    detected_digits = []
    templates = []
    for i in range(10):
        path_main = os.path.join(TEMPLATE_FOLDER, str(i) + '.png')
        if os.path.exists(path_main):
            tmpl_main = cv2.imread(path_main, cv2.IMREAD_GRAYSCALE)
            templates.append((str(i), tmpl_main))
        else:
            print(str(i) + ' bulunamadı! images klasörünü kontrol et.')

    for hane, region in enumerate(regions):
        ss = pyautogui.screenshot(region=region)
        gray = cv2.cvtColor(np.array(ss), cv2.COLOR_RGB2GRAY)
        if DEBUG:
            cv2.imwrite('debug_digit_' + str(hane) + '.png', gray)

        best_digit = '?'
        best_score = -1.0
        for d, tmpl in templates:
            if tmpl is None:
                continue
            res = cv2.matchTemplate(gray, tmpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, _ = cv2.minMaxLoc(res)
            if max_val > best_score:
                best_score = max_val
                best_digit = d

        debug_print(str(hane + 1) + '. hane -> ' + best_digit + ' (skor: ' + str(best_score) + ')')
        detected_digits.append(best_digit)

    okunan_kod = ''.join(detected_digits)
    print('✅ Okunan Kod:', okunan_kod)
    return okunan_kod


def enter_pin(code):
    """Verilen PIN kodunu koordinatlara tıklayarak girer."""
    time.sleep(1)
    for hane in code:
        if hane in coords:
            x, y = coords[hane]
            pyautogui.moveTo(x, y, duration=0.2)
            pyautogui.click()
            print('Tıklandı: ' + hane + ' -> (' + str(x) + ',' + str(y) + ')')
            time.sleep(0.2)
    # OK butonuna tıkla
    pyautogui.moveTo(ok_button[0], ok_button[1], duration=0.3)
    pyautogui.click()
    print('✅ Kod girildi ve onaylandı!')


def main():
    """Ana akış: PIN oku, gir, onayla."""
    # (615, 130) konumuna çift tıkla
    pyautogui.moveTo(615, 130, duration=0.5)
    pyautogui.click(clicks=2, interval=0.2)
    print('✅ (615, 130) konumuna çift tıklandı.')
    time.sleep(5)

    code = read_pin()
    enter_pin(code)

    # Son teyit tıkı
    pyautogui.moveTo(615, 130, duration=0.5)
    pyautogui.click(clicks=3, interval=0.2)


if __name__ == '__main__':
    main()
