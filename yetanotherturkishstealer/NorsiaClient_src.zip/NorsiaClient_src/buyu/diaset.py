"""buyu.diaset - Diamond Set Botu (Auto Set Enchant).

Minecraft benzeri bir oyunda (sonoyuncu) envanterdeki zırh parçalarını
(kask/CP/Pant/Bot) büyü masasına koyup lapis ile Koruma 4 (Protection IV)
büyüsü basmaya çalışan bir bottur.

F8 tuşu ile başlatılır/durdurulur.
"""
import os
import sys
import io
import threading
import time
import subprocess
import traceback

import colorama
import requests
import cv2
import numpy as np
import pyautogui
import discord_logger
from colorama import Fore
from pynput import keyboard
from pyscreeze import ImageNotFoundException

# UTF-8 stdout/stderr (Windows konsolu Türkçe karakterler için)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# colorama: Windows konsolunda ANSI renkleri
colorama.init(autoreset=True, strip=False)

# Ebeveyn klasörü sys.path'e ekle (discord_logger gibi modüller bulunabilsin)
parent_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

CYAN = Fore.CYAN
GREEN = Fore.GREEN
RED = Fore.RED
YELLOW = Fore.YELLOW

DEBUG = False

# Basilanlar (basılan tuşlar) - genel amaçlı dict
basilanlar = {}

# Thread senkronizasyonu
running_lock = threading.Lock()
is_running = False


def set_cord(x, y):
    """Koordinatları ekran boyutuna göre ölçekle.

    Orijinal koordinatlar 1280x720 çözünürlük için tasarlanmıştır. Mevcut
    ekran çözünürlüğüne orantısal olarak ölçeklenir.
    """
    screen_w, screen_h = pyautogui.size()
    eski_w, eski_h = 1280, 720
    return int(x * screen_w / eski_w), int(y * screen_h / eski_h)


# Tarama bölgeleri (envanter, chest). Hepsi 1280x720 referansından ölçeklenir.
SCAN_X, SCAN_Y = set_cord(473, 344)
SCAN_W = 334
SCAN_H = 164

CHEST_SCAN_X, CHEST_SCAN_Y = set_cord(433, 133)
CHEST_SCAN_W = 406
CHEST_SCAN_H = 255

INV_SCAN_X, INV_SCAN_Y = set_cord(473, 397)
INV_SCAN_W = 367
INV_SCAN_H = 163

# Set parçalarının görselleri
ITEM_FILES = {'Kask': 'kask.png', 'CP': 'cp.png', 'Pant': 'pant.png', 'Bot': 'bot.png'}

# Görsel eşleştirme eşiği
CONFIDENCE_THRESHOLD = 0.65
# "Büyülü" kabul edilen minimum parlama (mavi) piksel sayısı
ENCHANT_THRESHOLD = 8

# Chest modülü çevre değişkeni ile açılıp kapatılabilir
chest_enabled = os.environ.get('CHEST_ENABLED', '1') == '1'

# Eski pyscreeze sürümlerinde olmayabilir
try:
    ImageNotFoundException = pyautogui.ImageNotFoundException
except AttributeError:
    ImageNotFoundException = getattr(pyautogui, 'ImageNotFoundException', Exception)

BASE_PATH = os.path.dirname(os.path.abspath(__file__))

# Büyü masası / envanter slot koordinatları (1280x720 -> ölçeklenir)
lapis_x, lapis_y = set_cord(551, 295)          # const 335
kask_slot_x, kask_slot_y = set_cord(606, 220)  # const 328 - Kask
cp_slot_x, cp_slot_y = set_cord(606, 319)      # const 329 - CP (Gogusluk)
pant_slot_x, pant_slot_y = set_cord(517, 303)  # const 330 - Pant (Pantolon)
bot_slot_x, bot_slot_y = set_cord(478, 340)    # const 331 - Bot
trash_x, trash_y = set_cord(606, 340)          # const 332 - Çöp kutusu
con2_x, con2_y = set_cord(478, 400)            # const 333
con1_x, con1_y = set_cord(606, 400)            # const 334

# Bot thread'i (F8 ile başlatılır)
set_thread = None


def debug_print(*args, **kwargs):
    """DEBUG modunda print basar."""
    if DEBUG:
        print(*args, **kwargs)


def envanter_tara_buyulu():
    """Envanteri tarar ve büyülü set item'larını bulur (chest'e atmak için - testt.py mantığı).

    Envanterdeki büyülü zırh parçalarını (mavi parlama var) tespit eder.
    Chest'e atılacak büyülü item'ların koordinatlarını döndürür.
    """
    burst_shots = []
    region = (INV_SCAN_X, INV_SCAN_Y, INV_SCAN_W, INV_SCAN_H)
    for _ in range(0, 12):
        shot = pyautogui.screenshot(region=region)
        burst_shots.append(shot)

    base_img = cv2.cvtColor(np.array(burst_shots[0]), cv2.COLOR_RGB2BGR)
    found_unenchanted_coords = []  # büyülü koordinat listesi (eski adlandırma)
    found_locations = []
    max_p_score = 0

    for item_name, file_name in ITEM_FILES.items():
        template_path = os.path.join(BASE_PATH, 'images', file_name)
        if not os.path.exists(template_path):
            continue
        template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            continue
        h, w = template.shape

        for shot in burst_shots:
            shot_img = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2BGR)
            res = cv2.matchTemplate(shot_img, template, cv2.TM_CCOEFF_NORMED)
            loc = np.where(res >= CONFIDENCE_THRESHOLD)
            for pt in zip(*loc[::-1]):
                # Parlama (mavi) tespiti - HSV renk uzayında mavi aralık
                item_crop = shot_img[pt[1]:pt[1] + h, pt[0]:pt[0] + w]
                hsv = cv2.cvtColor(item_crop, cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv, (105, 10, 35), (182, 255, 255))
                score = np.count_nonzero(mask)
                if score > max_p_score:
                    max_p_score = score
                target_x = pt[0] + w // 2 + INV_SCAN_X
                target_y = pt[1] + h // 2 + INV_SCAN_Y
                found_locations.append((item_name, target_x, target_y, score))

    for item_name, fx, fy, pt in found_locations:
        if pt >= ENCHANT_THRESHOLD:
            found_unenchanted_coords.append((item_name, fx, fy))

    debug_print(CYAN, '[DEBUG] ', len(found_unenchanted_coords),
                ' büyülü item bulundu: (', found_unenchanted_coords,
                '), parlama skoru: ', max_p_score, ': ', len(found_unenchanted_coords),
                ' adet büyülü item bulundu')
    return found_unenchanted_coords


def envanter_tara_buyulu_normal():
    """Normal envanteri tarar ve büyülü set item'larını bulur.

    testt.py mantığıyla, envanterdeki büyülü parçaları tespit eder.
    Mükerrer koordinatları eler ve her bir item'dan kaç adet bulunduğunu
    sayar (item_count_map).
    """
    region = (INV_SCAN_X, INV_SCAN_Y, INV_SCAN_W, INV_SCAN_H)
    burst_shots = [pyautogui.screenshot(region=region) for _ in range(0, 15)]

    base_img_gray = cv2.cvtColor(np.array(burst_shots[0]), cv2.COLOR_RGB2BGR)
    all_detections = []
    final_items = []
    found_enchanted_coords = []
    item_count_map = {}

    for item_name, file_name in ITEM_FILES.items():
        template_path = os.path.join(BASE_PATH, 'images', file_name)
        if not os.path.exists(template_path):
            continue
        template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            continue
        h, w = template.shape

        for shot in burst_shots:
            shot_img = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2BGR)
            res = cv2.matchTemplate(shot_img, template, cv2.TM_CCOEFF_NORMED)
            loc = np.where(res >= CONFIDENCE_THRESHOLD)
            for pt in zip(*loc[::-1]):
                all_detections.append((item_name, pt, w, h))

    # Mükerrer eleme
    for det in all_detections:
        is_duplicate = False
        for f_item in final_items:
            if abs(det[1][0] - f_item[1][0]) < 20 and abs(det[1][1] - f_item[1][1]) < 20:
                is_duplicate = True
                break
        if not is_duplicate:
            final_items.append(det)

    max_p_score = 0
    for item_name, pt, w, h in final_items:
        shot_img = cv2.cvtColor(np.array(burst_shots[0]), cv2.COLOR_RGB2BGR)
        item_crop = shot_img[pt[1]:pt[1] + h, pt[0]:pt[0] + w]
        hsv = cv2.cvtColor(item_crop, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (105, 10, 35), (182, 255, 255))
        score = np.count_nonzero(mask)
        if score > max_p_score:
            max_p_score = score
        target_x = pt[0] + w // 2 + INV_SCAN_X
        target_y = pt[1] + h // 2 + INV_SCAN_Y
        if score >= ENCHANT_THRESHOLD:
            found_enchanted_coords.append((item_name, target_x, target_y))

    for item, _, _, _ in found_enchanted_coords:
        count = item_count_map.get(item, 0) + 1
        item_count_map[item] = count

    debug_print(CYAN, '[DEBUG] ', len(found_enchanted_coords),
                ' büyülü item bulundu: (', found_enchanted_coords,
                '), parlama skoru: ', max_p_score, ': ',
                len(found_enchanted_coords), ' adet büyülü item bulundu')
    return found_enchanted_coords


def chest_tara():
    """Chest'i tarar ve büyüsüz set item'larını bulur.

    Chest'teki büyüsüz (parlama yok) set parçalarını tespit eder.
    Büyü masasında büyülenecek uygun item'lar chest'ten alınır.
    """
    burst_shots = []
    region = (CHEST_SCAN_X, CHEST_SCAN_Y, CHEST_SCAN_W, CHEST_SCAN_H)
    for _ in range(0, 12):
        shot = pyautogui.screenshot(region=region)
        burst_shots.append(shot)

    base_img = cv2.cvtColor(np.array(burst_shots[0]), cv2.COLOR_RGB2BGR)
    found_enchanted_coords = []  # aslında büyüsüz koordinatlar
    found_locations = []
    max_p_score = 0

    for item_name, file_name in ITEM_FILES.items():
        template_path = os.path.join(BASE_PATH, 'images', file_name)
        if not os.path.exists(template_path):
            continue
        template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            continue
        h, w = template.shape

        for shot in burst_shots:
            shot_img = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2BGR)
            res = cv2.matchTemplate(shot_img, template, cv2.TM_CCOEFF_NORMED)
            loc = np.where(res >= CONFIDENCE_THRESHOLD)
            for pt in zip(*loc[::-1]):
                item_crop = shot_img[pt[1]:pt[1] + h, pt[0]:pt[0] + w]
                hsv = cv2.cvtColor(item_crop, cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(hsv, (105, 10, 35), (182, 255, 255))
                score = np.count_nonzero(mask)
                if score > max_p_score:
                    max_p_score = score
                target_x = pt[0] + w // 2 + CHEST_SCAN_X
                target_y = pt[1] + h // 2 + CHEST_SCAN_Y
                # Büyüsüz (parlama yok) ise chest'ten alınacak
                if score < ENCHANT_THRESHOLD:
                    found_locations.append((item_name, target_x, target_y))

    for item_name, fx, fy in found_locations:
        found_enchanted_coords.append((item_name, fx, fy))

    debug_print(CYAN, '[DEBUG] Chest tarama: ', len(found_enchanted_coords),
                ' büyüsüz item bulundu')
    return found_enchanted_coords


def envanter_tara():
    """Envanteri tarar ve büyüsüz set item'larını bulur (testt.py mantığı).

    Envanterdeki büyüsüz (henüz büyülenmemiş) set parçalarını tespit eder.
    Bunlar büyü masasında büyülenecek adaylardır.
    """
    region = (SCAN_X, SCAN_Y, SCAN_W, SCAN_H)
    burst_shots = [pyautogui.screenshot(region=region) for _ in range(0, 5)]

    base_img_gray = cv2.cvtColor(np.array(burst_shots[0]), cv2.COLOR_RGB2BGR)
    all_detections = []
    final_items = []
    found_unenchanted_coords = []

    for item_name, file_name in ITEM_FILES.items():
        template_path = os.path.join(BASE_PATH, 'images', file_name)
        if not os.path.exists(template_path):
            continue
        template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            continue
        h, w = template.shape

        for shot in burst_shots:
            shot_img = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2BGR)
            res = cv2.matchTemplate(shot_img, template, cv2.TM_CCOEFF_NORMED)
            loc = np.where(res >= CONFIDENCE_THRESHOLD)
            for pt in zip(*loc[::-1]):
                all_detections.append((item_name, pt, w, h))

    for det in all_detections:
        is_duplicate = False
        for f_item in final_items:
            if abs(det[1][0] - f_item[1][0]) < 20 and abs(det[1][1] - f_item[1][1]) < 20:
                is_duplicate = True
                break
        if not is_duplicate:
            final_items.append(det)

    max_p_score = 0
    for item_name, pt, w, h in final_items:
        shot_img = cv2.cvtColor(np.array(burst_shots[0]), cv2.COLOR_RGB2BGR)
        item_crop = shot_img[pt[1]:pt[1] + h, pt[0]:pt[0] + w]
        hsv = cv2.cvtColor(item_crop, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (105, 10, 35), (182, 255, 255))
        score = np.count_nonzero(mask)
        if score > max_p_score:
            max_p_score = score
        target_x = pt[0] + w // 2 + SCAN_X
        target_y = pt[1] + h // 2 + SCAN_Y
        # Büyüsüz (parlama yok) ise büyülenecek aday
        if score < ENCHANT_THRESHOLD:
            found_unenchanted_coords.append((item_name, target_x, target_y))

    debug_print(CYAN, '[DEBUG] Envanter tarama: ', len(found_unenchanted_coords),
                ' büyüsüz item bulundu')
    return found_unenchanted_coords


def send_embed(title: str, fields=None):
    """Discord webhook'a embed log gönderir.

    title: embed başlığı
    fields: list of dict with 'name', 'value', 'inline' keys (opsiyonel)
    """
    try:
        if fields is None:
            fields = []
        items = []
        for f in fields:
            items.append({
                'name': f.get('name', ''),
                'value': f.get('value', ''),
                'inline': f.get('inline', False),
            })
        discord_logger.send_discord_log('diaset', title, items, color=65280)
    except Exception as e:
        print(RED, '[WEBHOOK HATA] ', e)


def chest_ac_ve_islemleri():
    """Lapis al, envanter aç, chest komutu gönder, chest'i aç, işlemleri yap, kapat, t.py çalıştır.

    F8 ile durdurulana kadar veya hata olana kadar chest döngüsü çalışır.
    Envanterdeki büyülü item'ları chest'e atar, chest'teki büyüsüz item'ları alır
    ve son olarak t.py (PIN girme) script'ini çalıştırır.
    """
    global is_running
    try:
        print(CYAN, '[INFO] Chest işlemleri başlatılıyor...')
        with running_lock:
            is_running = True
            try:
                print(CYAN, '[INFO] Lapis alınıyor...')
                try:
                    pyautogui.moveTo(lapis_x, lapis_y)
                    pyautogui.keyDown('shift')
                    pyautogui.click()
                    pyautogui.keyUp('shift')
                    time.sleep(0.3)
                except Exception as e:
                    print(RED, '[HATA] Lapis alma hatası: ', e)

                print(CYAN, '[INFO] Envanter açılıyor...')
                pyautogui.press('e')
                time.sleep(0.5)

                print(CYAN, '[INFO] Chest komutu gönderiliyor...')
                pyautogui.write('t/chest', interval=0.1)
                time.sleep(0.2)
                pyautogui.press('enter')
                time.sleep(1.0)

                print(CYAN, '[INFO] Mouse sol üste taşınıyor...')
                pyautogui.moveTo(0, 0)

                print(CYAN, "[INFO] Envanterdeki büyülü item'lar taranıyor...")
                buyulu_items = envanter_tara_buyulu()
                debug_print(CYAN, '[DEBUG] Tarama sonucu: ', buyulu_items)
                debug_print(CYAN, "[DEBUG] Bulunan item'lar: ", buyulu_items)

                if buyulu_items:
                    print(CYAN, '[INFO] ', len(buyulu_items),
                          " adet büyülü item chest'e atılıyor...")
                    for item_name, item_x, item_y in buyulu_items:
                        try:
                            pyautogui.moveTo(item_x, item_y)
                            pyautogui.keyDown('shift')
                            pyautogui.click()
                            pyautogui.keyUp('shift')
                            time.sleep(0.1)
                        except Exception as e:
                            print(RED, '[HATA] Büyülü item atma hatası: ', e)
                else:
                    print(CYAN, '[INFO] Envanterde büyülü item bulunamadı.')

                print(CYAN, "[INFO] Büyülü item'lar koyuldu, mouse sol üste taşınıyor...")
                pyautogui.moveTo(0, 0)

                chest_unenchanted = chest_tara()
                if chest_unenchanted:
                    print(CYAN, '[INFO] ', len(chest_unenchanted),
                          " adet büyüsüz item chest'ten alınıyor...")
                    for item_name, item_x, item_y in chest_unenchanted:
                        try:
                            pyautogui.moveTo(item_x, item_y)
                            pyautogui.keyDown('shift')
                            pyautogui.click()
                            pyautogui.keyUp('shift')
                            time.sleep(0.1)
                        except Exception as e:
                            print(RED, '[HATA] Büyüsüz item alma hatası: ', e)
                    print(GREEN, '[INFO] Chest işlemleri tamamlandı!')
                else:
                    print(CYAN, "[INFO] Chest'te büyüsüz item bulunamadı.")

                print(CYAN, '[INFO] Chest kapatılıyor...')
                print(CYAN, '[INFO] Sağ click yapılıyor...')
                pyautogui.rightClick()
                time.sleep(0.3)

                print(CYAN, '[INFO] t.py çalıştırılıyor...')
                script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 't.py')
                try:
                    subprocess.Popen(['python', script_path])
                    print(CYAN, '[INFO] t.py başlatıldı, 20 saniye bekleniyor...')
                    for i in range(0, 20):
                        time.sleep(1)
                    print(CYAN, '[INFO] 20 saniye beklendi, lapis işlemlerine geçiliyor...')
                except Exception as e:
                    print(RED, '[HATA] t.py çalıştırma hatası: ', e, ', devam ediliyor...')

                print(CYAN, '[INFO] Envanterden lapis masaya konuyor...')
                try:
                    loc = pyautogui.locateOnScreen(
                        os.path.join(BASE_PATH, 'images', 'ttLapis.png'),
                        region=(470, 340, 344, 178),
                        confidence=0.8,
                    )
                    if loc is not None:
                        target_x = loc.left + loc.width // 2
                        target_y = loc.top + loc.height // 2
                        pyautogui.moveTo(target_x, target_y)
                        pyautogui.keyDown('shift')
                        pyautogui.click()
                        pyautogui.keyUp('shift')
                        print(GREEN, '[INFO] Lapis masaya konuldu!')
                    else:
                        print(CYAN, '[INFO] Envanterde lapis bulunamadı.')
                except ImageNotFoundException:
                    print(CYAN, '[INFO] Envanterde lapis bulunamadı.')
                except Exception as e:
                    print(RED, '[HATA] Lapis masaya koyma hatası: ', e)

                print(CYAN, '[INFO] Lapis yenileniyor...')
                try:
                    pyautogui.moveTo(lapis_x, lapis_y)
                    pyautogui.doubleClick()
                    time.sleep(0.2)
                    pyautogui.click()
                    time.sleep(0.2)
                    buyulu_normal = envanter_tara_buyulu_normal()
                    print(YELLOW, '[UYARI] ', len(buyulu_normal),
                          ' adet büyülü item bulundu: ', buyulu_normal)
                    print(GREEN, '[INFO] Lapis yenileme tamamlandı!')
                except Exception as e:
                    print(RED, '[HATA] Lapis yenileme hatası: ', e)
            finally:
                is_running = False
                print(YELLOW, '[DURDUR] Chest işlemleri durduruldu (F8)')
    except Exception as e:
        print(YELLOW, '[DURDUR] Chest işlemleri durduruldu (F8)')
        print(RED, '[HATA] Chest işlemi hatası: ', e)


def xp_kontrol_1lvl():
    """Level 1'de XP barında parlama olup olmadığını kontrol eder (genexpr ile).

    Belirli bir piksel aralığında yeşil piksel sayısını sayar.
    """
    sol_ust = (582, 237)
    sag_alt = (592, 247)
    ekran = pyautogui.screenshot()
    time.sleep(0.5)
    # yeşil piksel sayısı -> 150<=r<=240, 130<=g<=220, 2<=b<=100, 100<=a<=180
    def _gen():
        for x in range(sol_ust[0], sag_alt[0]):
            r, g, b = ekran.getpixel((x, sol_ust[1]))
            if 150 <= r <= 240 and 130 <= g <= 220 and 2 <= b <= 100:
                yield (x, sol_ust[1])
    xp = list(_gen())
    return len(xp) > 0


def xp_kontrol():
    """XP barında parlama olup olmadığını kontrol eder (genexpr ile).

    Belirli bir piksel aralığında yeşil piksel sayısını sayar.
    """
    sol_ust = (585, 305)
    sag_alt = (597, 323)
    ekran = pyautogui.screenshot()
    time.sleep(0.5)
    # yeşil piksel sayısı -> 150<=r<=240, 130<=g<=220, 2<=b<=100, 100<=a<=180
    def _gen():
        for x in range(sol_ust[0], sag_alt[0]):
            r, g, b = ekran.getpixel((x, sol_ust[1]))
            if 150 <= r <= 240 and 130 <= g <= 220 and 2 <= b <= 100:
                yield (x, sol_ust[1])
    xp = list(_gen())
    return len(xp) > 0


def set_basma():
    """Ana büyü basma döngüsü.

    - Önce başlangıç lapis kontrolü yapar (masaya koyar).
    - Sonra lapis yeniler.
    - running_lock altında ana döngü:
        * Envanterdeki büyüsüz item'ları tara
        * Her bir item için: slot'a koy, Koruma 3/4 kontrol et, büyü bas
        * Tüm set parçaları denendiyse boş kitap bas (RNG sıfırla)
        * Envanterde büyüsüz item kalmadıysa chest_ac_ve_islemleri çağır
    - F8 ile durdurulana kadar devam eder.
    """
    global is_running
    try:
        send_embed('🚀 Auto Set Enchant Başladı')
        time.sleep(2)
        print(CYAN, '[INFO] Başlangıç Lapis kontrolü yapılıyor...')
        try:
            loc = pyautogui.locateOnScreen(
                os.path.join(BASE_PATH, 'images', 'ttLapis.png'),
                region=(470, 340, 344, 178),
                confidence=0.8,
            )
            if loc is not None:
                target_x = loc.left + loc.width // 2
                target_y = loc.top + loc.height // 2
                pyautogui.moveTo(target_x, target_y)
                pyautogui.keyDown('shift')
                pyautogui.click()
                pyautogui.keyUp('shift')
                time.sleep(0.2)
                print(GREEN, '[INFO] Başlangıçta lapis masaya konuldu!')
            else:
                print(CYAN, '[INFO] Başlangıçta Lapis bulunamadı (normal, devam ediliyor)')
        except ImageNotFoundException:
            print(CYAN, '[INFO] Başlangıçta Lapis bulunamadı (normal, devam ediliyor)')
        except Exception as e:
            print(RED, '[HATA] Başlangıç Lapis hatası: ', e)

        print(CYAN, '[INFO] Başlangıç lapis yenileme yapılıyor...')
        try:
            pyautogui.moveTo(lapis_x, lapis_y)
            pyautogui.doubleClick()
            time.sleep(0.2)
            pyautogui.click()
            time.sleep(0.2)
            print(GREEN, '[INFO] Başlangıç lapis yenileme tamamlandı!')
        except Exception as e:
            print(RED, '[HATA] Başlangıç lapis yenileme hatası: ', e)

        # Koruma 4 sayaçları
        klasor = {'Koruma 4 (Kask)': 0, 'Koruma 4 (CP)': 0,
                  'Koruma 4 (Pant)': 0, 'Koruma 4 (Bot)': 0}

        with running_lock:
            is_running = True
            try:
                while is_running:
                    denenen_item_tipleri = set()
                    loc = None
                    hx, hy = 0, 0

                    try:
                        buyulu_items = envanter_tara()
                        unenchanted_items = buyulu_items
                        print(CYAN, '[INFO] ', len(unenchanted_items),
                              ' adet büyüsüz item bulundu')

                        if not unenchanted_items:
                            if chest_enabled:
                                print(CYAN, '[INFO] Envanterde büyüsüz item kalmadı, chest işlemleri yapılıyor...')
                                chest_ac_ve_islemleri()
                                chest_items = chest_tara()
                                if not chest_items:
                                    print(YELLOW, "[DURDUR] Chest'ten de büyüsüz item alınamadı! İşlem durduruluyor...")
                                    send_embed('⛔ Büyüsüz Item Bitti - İşlem Durduruldu')
                                    break
                            else:
                                print(YELLOW, "[DURDUR] Chest'te de büyüsüz item yok! İşlem durduruluyor...")
                                send_embed('⛔ Büyüsüz Item Bitti - İşlem Durduruldu')
                                break

                        # Slot eşlemesi
                        slot_map = {
                            'Kask': (kask_slot_x, kask_slot_y),
                            'CP': (cp_slot_x, cp_slot_y),
                            'Pant': (pant_slot_x, pant_slot_y),
                            'Bot': (bot_slot_x, bot_slot_y),
                        }

                        candidates = list(unenchanted_items)
                        for item_name, item_x, item_y in candidates:
                            if item_name not in slot_map:
                                continue
                            slot_x, slot_y = slot_map[item_name]
                            denenen_item_tipleri.add(item_name)

                            try:
                                # Item'ı büyü masasına koy
                                pyautogui.moveTo(item_x, item_y)
                                pyautogui.keyDown('shift')
                                pyautogui.click()
                                pyautogui.keyUp('shift')
                                time.sleep(0.2)
                                pyautogui.moveTo(slot_x, slot_y)
                                pyautogui.click()
                                time.sleep(0.2)

                                # Koruma 3 kontrolü
                                loc_p3 = pyautogui.locateOnScreen(
                                    os.path.join(BASE_PATH, 'images', 'p3.png'),
                                    confidence=0.93,
                                    grayscale=True,
                                )
                                if loc_p3 is not None:
                                    print(GREEN, '[OK] ', item_name,
                                          ' için Koruma 3 bulundu! Tüm setler atlanıyor, boş kitap basılıyor...')
                                    klasor.update({k: v for k, v in klasor.items()})
                                    # Boş kitap bas
                                    try:
                                        loc = pyautogui.locateOnScreen(
                                            os.path.join(BASE_PATH, 'images', 'kitap.png'),
                                            grayscale=True,
                                        )
                                        if loc is not None:
                                            xp_kontrol_1lvl()
                                            pyautogui.moveTo(trash_x, trash_y)
                                            pyautogui.keyDown('shift')
                                            pyautogui.click()
                                            pyautogui.keyUp('shift')
                                            pyautogui.press('q')
                                            print(GREEN, '[INFO] Boş kitap basıldı ve atıldı, RNG sıfırlandı.')
                                        else:
                                            print(CYAN, '[INFO] Kitap bulunamadı, devam ediliyor...')
                                    except Exception as e:
                                        print(RED, '[HATA] Boş kitap işlemi hatası: ', e)
                                    # Tüm setleri atla
                                    denenen_item_tipleri.update(['Kask', 'CP', 'Pant', 'Bot'])
                                    break

                                # Koruma 4 kontrolü
                                loc_p4 = pyautogui.locateOnScreen(
                                    os.path.join(BASE_PATH, 'images', 'p4.png'),
                                    confidence=0.93,
                                    grayscale=True,
                                )
                                if loc_p4 is not None:
                                    print(GREEN, '[OK] ', item_name, ' için Koruma 4 bulundu!')
                                    xp_kontrol()
                                    key_str = 'Koruma 4 (' + item_name + ')'
                                    klasor[key_str] = klasor.get(key_str, 0) + 1
                                    send_embed('🛡️ ' + item_name + ' için Koruma 4 basıldı!')
                                    print(GREEN, '[OK] ', item_name,
                                          ' için Koruma 4 basıldı! Toplam: ', klasor[key_str])
                                    # Item'ı geri al
                                    pyautogui.moveTo(con1_x, con1_y)
                                    pyautogui.keyDown('shift')
                                    pyautogui.click()
                                    pyautogui.keyUp('shift')
                                else:
                                    print(YELLOW, '[UYARI] ', item_name,
                                          ' için Koruma 4 bulunamadı, geri alınıyor...')
                                    pyautogui.moveTo(con2_x, con2_y)
                                    pyautogui.keyDown('shift')
                                    pyautogui.click()
                                    pyautogui.keyUp('shift')
                            except Exception as e:
                                print(RED, '[HATA] İşlem hatası: ',
                                      __name__, ' - ', e)
                                traceback.print_exc()
                                print(CYAN, '[INFO] Hata sonrası eşya geri alınıyor...')

                        # Tüm set parçaları denendiyse ve Koruma 4 bulunamadıysa
                        if denenen_item_tipleri >= set(['Kask', 'CP', 'Pant', 'Bot']):
                            print(CYAN, '[INFO] Tüm set parçaları denendi, hiçbiri olmadı. Boş kitap basılıyor...')
                            try:
                                loc = pyautogui.locateOnScreen(
                                    os.path.join(BASE_PATH, 'images', 'kitap.png'),
                                    grayscale=True,
                                )
                                if loc is not None:
                                    xp_kontrol_1lvl()
                                    pyautogui.moveTo(trash_x, trash_y)
                                    pyautogui.keyDown('shift')
                                    pyautogui.click()
                                    pyautogui.keyUp('shift')
                                    pyautogui.press('q')
                                    print(GREEN, '[INFO] Boş kitap basıldı ve atıldı, RNG sıfırlandı.')
                                else:
                                    print(CYAN, '[INFO] Kitap bulunamadı, devam ediliyor...')
                            except Exception as e:
                                print(RED, '[HATA] Boş kitap işlemi hatası: ', e)

                    except Exception as e:
                        print(RED, '[HATA] Genel döngü hatası: ', __name__, ' - ', e)
                        traceback.print_exc()

                    time.sleep(1)
            finally:
                is_running = False
                print(YELLOW, '[DURDUR] Bot durduruldu (F8)')
                send_embed('⏸️ Bot Durduruldu')
    except Exception as e:
        print(RED, '[HATA] Genel döngü hatası: ', e)
        traceback.print_exc()
        time.sleep(1)
        print(RED, '[HATA] Başlangıç Lapis hatası: ', e)
    finally:
        print(CYAN, "[INFO] Bot thread'i kapatıldı.")


def on_press(key):
    """F8 tuşu ile botu başlatır/durdurur."""
    global set_thread, is_running
    if key == keyboard.Key.f8:
        if not is_running:
            print(CYAN, '[BAŞLAT] F8 basıldı - Bot başlatılıyor...')
            set_thread = threading.Thread(target=set_basma, daemon=True)
            set_thread.start()
        else:
            print(YELLOW, '[DURDUR] F8 basıldı - Bot durduruluyor ve script kapatılıyor...')
            is_running = False
            if set_thread is not None and set_thread.is_alive():
                set_thread.join(timeout=2.0)
            print(RED, '[KAPAT] Script kapatılıyor...')
            sys.exit(0)


def keyboard_listener():
    """pynput keyboard listener başlatır ve join eder."""
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()


def run():
    """Bot dispatcher için giriş noktası.

    Bilgi mesajı yazdırır ve klavye dinleyicisini başlatır.
    F8 ile bot başlatılır/durdurulur.
    """
    kb_thread = None
    print(CYAN, '[INFO] Diamond Set Botu')
    print(CYAN, '[INFO] F8 tuşuna basarak botu başlatabilir/durdurebilirsiniz...')
    keyboard_listener()


if __name__ == '__main__':
    run()
