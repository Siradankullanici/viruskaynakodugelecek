"""buyu paketi - Büyü (enchant) botları."""
