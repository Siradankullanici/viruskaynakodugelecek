"""buyu.kitap - Kitap (Book) Enchant Botu.

Minecraft benzeri bir oyunda (sonoyuncu) envanterdeki kitaplara büyü masasında
lapis ile seçili büyüleri basmaya çalışan bir bottur. GUI'den seçili kitaplar
(selected_books_from_gui) kullanılarak hangi büyülerin basılacağı belirlenir.
Envanter yenileme (envanter_yenileme) özelliği ile periyodik olarak envanter
home'a gönderilip t.py (PIN girişi) çalıştırılarak yenilenir.

F8 tuşu ile başlatılır/durdurulur.
"""
import os
import sys
import io
import json
import threading
import time
import subprocess
import traceback

import colorama
import requests
import pyautogui
import discord_logger
from colorama import Fore
from pynput import keyboard

# UTF-8 stdout/stderr (Windows konsolu Türkçe karakterler için)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# colorama: Windows konsolunda ANSI renkleri
colorama.init(autoreset=True, strip=False)

# Ebeveyn klasörü sys.path'e ekle (discord_logger gibi modüller bulunabilsin)
parent_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

CYAN = Fore.CYAN
GREEN = Fore.GREEN
RED = Fore.RED
YELLOW = Fore.YELLOW

DEBUG = False

# Basilanlar (basılan tuşlar) - genel amaçlı dict
basilanlar = {}

# Thread senkronizasyonu
running_lock = threading.Lock()
envanter_lock = threading.Lock()

# Bot durumları
is_running = False
envanter_yenileme_durum = False


def set_cord(x, y):
    """Koordinatları ekran boyutuna göre ölçekle.

    Orijinal koordinatlar 1280x720 çözünürlük için tasarlanmıştır. Mevcut
    ekran çözünürlüğüne orantısal olarak ölçeklenir.
    """
    screen_w, screen_h = pyautogui.size()
    eski_w, eski_h = 1280, 720
    return int(x * screen_w / eski_w), int(y * screen_h / eski_h)


# Büyü masası / envanter slot koordinatları (1280x720 -> ölçeklenir)
trash_x, trash_y = set_cord(606, 220)            # idx 183 - enchant slot / çöp
con2_x, con2_y = set_cord(606, 319)              # idx 184 - con2 (geri alma 2)
con1_x, con1_y = set_cord(517, 303)              # idx 185 - con1 (geri alma 1)

# Lapis koordinatları (envanterdeki olası lapis konumları)
lapis_koords = [
    set_cord(530, 141),  # idx 186
    set_cord(449, 146),  # idx 187
    set_cord(497, 139),  # idx 188
    set_cord(495, 139),  # idx 189
    set_cord(466, 146),  # idx 190
]

# Envanter slot koordinatları (36 slot, envanter_yenileme için)
envanter_slotlari = [
    set_cord(492, 457), set_cord(525, 456), set_cord(565, 455), set_cord(605, 458),
    set_cord(646, 460), set_cord(679, 457), set_cord(709, 458), set_cord(746, 456),
    set_cord(782, 453),
    set_cord(487, 498), set_cord(530, 497), set_cord(570, 494), set_cord(606, 492),
    set_cord(642, 492), set_cord(680, 495), set_cord(712, 495), set_cord(747, 493),
    set_cord(781, 495),
    set_cord(489, 529), set_cord(518, 524), set_cord(570, 523), set_cord(605, 527),
    set_cord(638, 527), set_cord(669, 527), set_cord(705, 527), set_cord(746, 527),
    set_cord(783, 528),
    set_cord(494, 570), set_cord(533, 571), set_cord(569, 577), set_cord(605, 578),
    set_cord(637, 575), set_cord(670, 576), set_cord(716, 574), set_cord(761, 576),
    set_cord(785, 575),
]

# Kitap koordinatları (GUI'den ayarlanır, book_name -> coord)
kitap_koords = {}

# GUI'den seçili kitaplar (book_key -> is_selected)
selected_books_from_gui = {}

# Çevre değişkenlerinden ayarları oku
try:
    _selected_books_json = os.environ.get('SELECTED_BOOKS', '')
    if _selected_books_json:
        selected_books_from_gui = json.loads(_selected_books_json)
except Exception as e:
    print(RED, '[HATA] SELECTED_BOOKS okuma hatası: ', e)

envanter_yenileme_enabled = os.environ.get('ENVANTER_YENILEME', '') == '1'

BASE_PATH = os.path.dirname(os.path.abspath(__file__))

# Bot thread'leri (F8 ile başlatılır)
kitap_thread = None
envanter_thread = None


def debug_print(*args, **kwargs):
    """DEBUG modunda print basar."""
    if DEBUG:
        print(*args, **kwargs)


def send_embed(title: str, fields=None):
    """Discord webhook'a embed log gönderir.

    title: embed başlığı
    fields: list of dict with 'name', 'value', 'inline' keys (opsiyonel)
    """
    try:
        if fields is None:
            fields = []
        items = []
        for f in fields:
            items.append({
                'name': f.get('name', ''),
                'value': f.get('value', ''),
                'inline': f.get('inline', False),
            })
        discord_logger.send_discord_log('kitap', title, items, color=65280)
    except Exception as e:
        print(RED, '[WEBHOOK HATA] ', e)


def xp_kontrol_1lvl():
    """Level 1'de XP barında parlama olup olmadığını kontrol eder (genexpr ile).

    Belirli bir piksel aralığında yeşil piksel sayısını sayar.
    Sol-üst (582, 237) - Sağ-alt (592, 247) bölgesini tarar.
    """
    sol_ust = (582, 237)
    sag_alt = (592, 247)
    ekran = pyautogui.screenshot()
    time.sleep(0.5)
    # yeşil piksel sayısı -> 150<=r<=240, 130<=g<=220, 2<=b<=100, 100<=a<=180
    xp = list((x, y) for x in range(sol_ust[0], sag_alt[0]) for y in range(sol_ust[1], sag_alt[1]) if 150 <= ekran.getpixel((x, y))[0] <= 240 and 130 <= ekran.getpixel((x, y))[1] <= 220 and 2 <= ekran.getpixel((x, y))[2] <= 100)
    return len(xp) > 0


def xp_kontrol():
    """XP barında parlama olup olmadığını kontrol eder (genexpr ile).

    Belirli bir piksel aralığında yeşil piksel sayısını sayar.
    Sol-üst (585, 305) - Sağ-alt (597, 323) bölgesini tarar.
    """
    sol_ust = (585, 305)
    sag_alt = (597, 323)
    ekran = pyautogui.screenshot()
    time.sleep(0.5)
    # yeşil piksel sayısı -> 150<=r<=240, 130<=g<=220, 2<=b<=100, 100<=a<=180
    xp = list((x, y) for x in range(sol_ust[0], sag_alt[0]) for y in range(sol_ust[1], sag_alt[1]) if 150 <= ekran.getpixel((x, y))[0] <= 240 and 130 <= ekran.getpixel((x, y))[1] <= 220 and 2 <= ekran.getpixel((x, y))[2] <= 100)
    return len(xp) > 0


def kitap():
    """Ana kitap büyü basma döngüsü.

    - Önce başlangıç lapis kontrolü yapar (masaya koyar).
    - Envanterdeki kitap.png'i arar, kitabı büyü masasına (trash slot) koyar.
    - buyu_kontrol nested function ile seçili büyüleri kontrol eder.
    - Büyü bulunduysa: xp_kontrol, sayacı artır, Discord'a bildir,
      kitabı con1 slotundan geri al.
    - Büyü bulunamadıysa: 1lvl2.png ile level 1 kontrolü yap (xp_kontrol_1lvl),
      kitabı con2 slotundan geri al, boş kitap basıp press('q') ile at (RNG sıfırla).
    - envanter_yenileme_durum True ise bekle (yenileme sırasında işlem yapma).
    - F8 ile durdurulana kadar devam eder.
    """
    global is_running, trash_x, trash_y, con2_x, con2_y, selected_books_from_gui
    try:
        print(GREEN, '[INFO] Auto Enchant Başlatıldı')
        send_embed('🚀 Auto Enchant Başladı')
        time.sleep(2)

        # Başlangıç lapis kontrolü
        try:
            loc = pyautogui.locateOnScreen(
                'images\\' + 'ttLapis.png',
                region=(470, 340, 344, 178),
            )
            if loc is not None:
                hx = loc.left + loc.width // 2
                hy = loc.top + loc.height // 2
                pyautogui.moveTo(hx, hy)
                pyautogui.keyDown('shift')
                pyautogui.click()
                pyautogui.keyUp('shift')
                time.sleep(0.2)
                print(GREEN, '[INFO] Başlangıçta lapis masaya konuldu!')
            else:
                print(CYAN, '[INFO] Başlangıçta Lapis bulunamadı (normal, devam ediliyor)')
        except Exception as e:
            print(RED, '[HATA] Başlangıç Lapis hatası: ', e)

        # Büyü sayaçları (her büyü için)
        klasor = {
            'Keskinlik 4': 0,
            'Kırılmazlık': 0,
            'Derin Koşucu 3': 0,
            'Derin Koşucu 2': 0,
            'ipeksi Dokunuş': 0,
            'Koruma': 0,
            'Servet  3': 0,
            'Savurma 2': 0,
            'Verimlilik4': 0,
            'servet2': 0,
            'Keskinlik 3': 0,
            'Alevden Çehre': 0,
        }

        # Büyü kontrol listesi: (resim dosyası, büyü adı)
        kontrol_listesi = [
            ('keskinlik4.png', 'Keskinlik 4'),
            ('kirilmazlik.png', 'Kırılmazlık'),
            ('derinkos.png', 'Derin Koşucu 3'),
            ('derinkos2.png', 'Derin Koşucu 2'),
            ('ipeksidok.png', 'ipeksi Dokunuş'),
            ('p4.png', 'Koruma'),
            ('servet3.png', 'Servet  3'),
            ('sav2.png', 'Savurma 2'),
            ('verim4.png', 'Verimlilik4'),
            ('servet2.png', 'servet2'),
            ('keskinlik3.png', 'Keskinlik 3'),
            ('alev2.png', 'Alevden Çehre'),
        ]

        # GUI anahtarı -> büyü adı eşlemesi (selected_books_from_gui'den çözümle)
        key_mapping = {
            'keskinlik4': 'Keskinlik 4',
            'kirilmazlik': 'Kırılmazlık',
            'derinkosucu3': 'Derin Koşucu 3',
            'derinkosucu2': 'Derin Koşucu 2',
            'ipeksidok': 'ipeksi Dokunuş',
            'koruma': 'Koruma',
            'servet3': 'Servet  3',
            'savurma2': 'Savurma 2',
            'verimlilik4': 'Verimlilik4',
            'servet2': 'servet2',
            'keskinlik3': 'Keskinlik 3',
            'alevdencehre': 'Alevden Çehre',
        }

        # selected_books_from_gui'den seçili büyü isimlerini çıkar
        selected_keys = []
        if selected_books_from_gui:
            for gui_key, is_selected in selected_books_from_gui.items():
                if is_selected and gui_key in key_mapping:
                    selected_keys.append(key_mapping[gui_key])

        # Büyü kontrolü nested function - seçili büyüleri ekranda arar
        def buyu_kontrol():
            """Ekrandaki büyü görsellerini kontrol eder, seçili olanları arar.

            Bulunan ilk seçili büyüyü (resim, key, loc) olarak döndürür.
            Bulunamazsa None döner. klasor closure değişkenidir.
            """
            for resim, key in kontrol_listesi:
                if key not in selected_keys:
                    continue
                try:
                    buyu_loc = pyautogui.locateOnScreen(
                        'images\\' + resim,
                        confidence=0.93,
                        grayscale=True,
                    )
                except Exception:
                    buyu_loc = None
                if buyu_loc is not None:
                    # klasor closure üzerinden sayaç artırımı outer scope'ta yapılır
                    _ = klasor.get(key, 0)
                    return (resim, key, buyu_loc)
            return None

        with running_lock:
            is_running = True
            try:
                while is_running:
                    # Envanter yenileme aktifse bekle
                    if envanter_yenileme_durum:
                        time.sleep(1)
                        continue

                    try:
                        # Envanterde kitap (büyüsüz kitap) ara
                        loc = pyautogui.locateOnScreen(
                            'images\\' + 'kitap.png',
                            grayscale=True,
                        )
                        if loc is None:
                            print(CYAN, '[INFO] Kitap bulunamadı, bekleniyor...')
                            time.sleep(1)
                            continue

                        hx = loc.left + loc.width // 2
                        hy = loc.top + loc.height // 2

                        # Kitabı büyü masasına koy (trash slot)
                        pyautogui.moveTo(hx, hy)
                        pyautogui.keyDown('shift')
                        pyautogui.click()
                        pyautogui.keyUp('shift')
                        time.sleep(0.2)
                        pyautogui.moveTo(trash_x, trash_y)
                        pyautogui.click()
                        time.sleep(0.3)

                        # Büyü kontrolü
                        kontrol_sonuc = buyu_kontrol()

                        if kontrol_sonuc is not None:
                            resim, key, buyu_loc = kontrol_sonuc
                            xp_kontrol()
                            klasor[key] = klasor.get(key, 0) + 1
                            send_embed('📘 ' + key.upper() + ' basıldı!')
                            print(GREEN, '[OK] ', key, ' basıldı! Toplam: ', klasor[key])
                            # Kitabı con1 slotundan geri al (büyülü)
                            pyautogui.moveTo(con1_x, con1_y)
                            pyautogui.keyDown('shift')
                            pyautogui.click()
                            pyautogui.keyUp('shift')
                        else:
                            # Büyü bulunamadı - level 1 kontrolü
                            try:
                                loc_1lvl = pyautogui.locateOnScreen(
                                    'images\\' + '1lvl2.png',
                                    grayscale=True,
                                )
                                if loc_1lvl is not None:
                                    xp_kontrol_1lvl()
                            except Exception:
                                pass
                            # Kitabı con2 slotundan geri al (büyüsüz)
                            pyautogui.moveTo(con2_x, con2_y)
                            pyautogui.keyDown('shift')
                            pyautogui.click()
                            pyautogui.keyUp('shift')
                            # Boş kitap bas ve at (RNG sıfırla)
                            pyautogui.moveTo(trash_x, trash_y)
                            pyautogui.keyDown('shift')
                            pyautogui.click()
                            pyautogui.keyUp('shift')
                            pyautogui.press('q')
                            print(GREEN, '[INFO] Boş kitap basıldı ve atıldı, RNG sıfırlandı.')
                    except Exception as e:
                        print(RED, '[HATA] Genel döngü hatası: ', e)
                        traceback.print_exc()

                    time.sleep(1)
            finally:
                is_running = False
                print(YELLOW, '[DURDUR] Bot durduruldu (F8)')
                send_embed('⏸️ Bot Durduruldu')
    except Exception as e:
        print(RED, '[HATA] Genel döngü hatası: ', e)
        traceback.print_exc()
    finally:
        print(CYAN, "[INFO] Kitap thread'i kapatıldı.")


def envanter_yenileme():
    """Periyodik envanter yenileme döngüsü.

    800 saniye (~13 dakika) bekler, sonra envanteri yeniler:
    1. con1'den item al
    2. Envanter aç (press 'e'), 3 sn bekle
    3. /home t komutu ile home'a ışınlan, 13 sn bekle
    4. Her envanter slotu için:
       - moveTo(slot), click(button='right') - itemı yere at
       - sleep(0.5)
       - moveTo(slot), keyDown('shift'), click, keyUp - itemı geri al
       - sleep(0.05)
    5. 90 sn bekle, press('a'), sleep(0.4), sleep(2)
    6. Lapis ve kitap koordinatlarını kullan (GUI'den ayarlanmış)
    7. /home bas ile geri dön, 13 sn bekle
    8. t.py çalıştır (PIN girişi), 80 sn bekle
    """
    global envanter_yenileme_durum, lapis_koords, kitap_koords
    while True:
        time.sleep(800)
        with envanter_lock:
            envanter_yenileme_durum = True
            try:
                print(CYAN, '[ENV] Envanter yenileme başladı')
                send_embed('🔄 Envanter Yenileme Başladı')

                # con1'den item al
                pyautogui.moveTo(con1_x, con1_y)
                pyautogui.keyDown('shift')
                pyautogui.click()
                pyautogui.keyUp('shift')

                # Envanteri aç
                pyautogui.press('e')
                time.sleep(3)

                # /home t komutu - home'a ışınlan
                pyautogui.press('t')
                time.sleep(0.1)
                pyautogui.typewrite('/home t')
                pyautogui.press('enter')
                time.sleep(13)

                # Envanter slotlarını sağ tıkla, sonra shift+click ile geri al
                for slot in envanter_slotlari:
                    pyautogui.moveTo(slot[0], slot[1])
                    pyautogui.click(button='right')
                    time.sleep(0.5)
                    pyautogui.moveTo(slot[0], slot[1])
                    pyautogui.keyDown('shift')
                    pyautogui.click()
                    pyautogui.keyUp('shift')
                    time.sleep(0.05)

                # Ek bekleme ve tuş basışı
                time.sleep(90)
                pyautogui.press('a')
                time.sleep(0.4)
                time.sleep(2)

                # Lapis ve kitap koordinatlarını kullan (GUI'den ayarlanmış)
                if lapis_koords:
                    pyautogui.moveTo(lapis_koords[0][0], lapis_koords[0][1])
                    pyautogui.click()
                if kitap_koords:
                    first_coord = next(iter(kitap_koords.values()))
                    pyautogui.moveTo(first_coord[0], first_coord[1])
                    pyautogui.click()

                # /home bas ile geri dön
                pyautogui.press('t')
                time.sleep(0.1)
                pyautogui.typewrite('/home bas')
                pyautogui.press('enter')
                time.sleep(13)

                # t.py çalıştır (PIN girişi)
                try:
                    subprocess.Popen(['python', 't.py'])
                    print(CYAN, '[INFO] t.py başlatıldı, 80 saniye bekleniyor...')
                    for _ in range(0, 80):
                        time.sleep(1)
                except Exception as e:
                    print(RED, '[HATA] t.py çalıştırma hatası: ', e)

                print(GREEN, '[ENV] Envanter yenileme tamamlandı')
                send_embed('✅ Envanter Yenileme Tamamlandı')
            finally:
                envanter_yenileme_durum = False


def on_press(key):
    """F8 tuşu ile botu başlatır/durdurur.

    İlk F8 basışında: kitap_thread başlatır. envanter_yenileme_enabled True ise
    envanter_thread da başlatılır.
    İkinci F8 basışında: is_running=False yapar, kitap_thread'e join(timeout=2.0)
    uygular ve sys.exit(0) ile scripti kapatır.
    """
    global kitap_thread, envanter_thread, is_running
    if key == keyboard.Key.f8:
        if not is_running:
            print(CYAN, '[BAŞLAT] F8 basıldı - Bot başlatılıyor...')
            kitap_thread = threading.Thread(target=kitap, daemon=True)
            kitap_thread.start()
            if envanter_yenileme_enabled:
                print(GREEN, '[INFO] Envanter yenileme aktif')
                envanter_thread = threading.Thread(target=envanter_yenileme, daemon=True)
                envanter_thread.start()
            else:
                print(YELLOW, '[INFO] Envanter yenileme kapalı')
        else:
            print(YELLOW, '[DURDUR] F8 basıldı - Bot durduruluyor ve script kapatılıyor...')
            is_running = False
            if kitap_thread is not None and kitap_thread.is_alive():
                kitap_thread.join(timeout=2.0)
            print(RED, '[KAPAT] Script kapatılıyor...')
            sys.exit(0)


def keyboard_listener():
    """pynput keyboard listener başlatır ve join eder."""
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()


def run():
    """Bot dispatcher için giriş noktası.

    Bilgi mesajı yazdırır ve klavye dinleyicisini başlatır.
    F8 ile bot başlatılır/durdurulur.
    """
    kb_thread = None
    print(CYAN, '[INFO] F8 tuşuna basarak botu başlatabilir/durdurebilirsiniz...')
    print(CYAN, "[INFO] Program çalışıyor, F8'ye basın...")
    keyboard_listener()


if __name__ == '__main__':
    run()
