"""buyu.kazma_kurek_kilic - Auto Kazma-Kurek-Kilic-Yay Enchant Botu.

Minecraft benzeri bir oyunda (sonoyuncu) envanterdeki büyüsüz aletleri
(kazma/kürek/kılıç/yay) büyü masasına koyup lapis ile uygun büyü
(Servet 3 / Verimlilik 4 / Saldırı / Yumruk 2 / Sonsuzluk) basmaya
çalışan bir bottur. Zırh set botlarından farklı olarak chest işlemi ve
armor slotları yoktur; sadece envanteri tarar ve büyüler.

F8 tuşu ile başlatılır/durdurulur.
"""
import os
import sys
import io
import threading
import time
import traceback

import colorama
import requests
import cv2
import numpy as np
import pyautogui
import discord_logger
from colorama import Fore
from pynput import keyboard
from pyscreeze import ImageNotFoundException

# UTF-8 stdout/stderr (Windows konsolu Türkçe karakterler için)
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

# colorama: Windows konsolunda ANSI renkleri
colorama.init(autoreset=True, strip=False)

# Ebeveyn klasörü sys.path'e ekle (discord_logger gibi modüller bulunabilsin)
parent_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

CYAN = Fore.CYAN
GREEN = Fore.GREEN
RED = Fore.RED
YELLOW = Fore.YELLOW

DEBUG = False

# Basilanlar (basılan tuşlar) - genel amaçlı dict
basilanlar = {}

# Thread senkronizasyonu
running_lock = threading.Lock()
is_running = False


def set_cord(x, y):
    """Koordinatları ekran boyutuna göre ölçekle.

    Orijinal koordinatlar 1280x720 çözünürlük için tasarlanmıştır. Mevcut
    ekran çözünürlüğüne orantısal olarak ölçeklenir.
    """
    screen_w, screen_h = pyautogui.size()
    eski_w, eski_h = 1280, 720
    return int(x * screen_w / eski_w), int(y * screen_h / eski_h)


# Tarama bölgesi (envanter). 1280x720 referansından ölçeklenir.
SCAN_X, SCAN_Y = set_cord(473, 344)
SCAN_W = 334
SCAN_H = 164

# Taranacak alet görselleri (envanter tarama)
ITEM_FILES = {'Kazma': 'kazma.png', 'Kurek': 'kurek.png', 'Kilic': 'kilic.png', 'Yay': 'yay.png'}

# Her alet tipi için hedef büyü görselleri (masa üstünde aranır).
# Yay için iki farklı büyü adayı vardır; ilk bulunan kabul edilir.
BUYU_FILES = {
    'Kazma': 'servet3.png',
    'Kurek': 'verim4.png',
    'Kilic': 'keskinlik4.png',
    'Yay': ['yumruk.png', 'sonsuzluk.png'],
}

# Görsel eşleştirme eşiği
CONFIDENCE_THRESHOLD = 0.65
# "Büyülü" kabul edilen minimum parlama (mavi) piksel sayısı
ENCHANT_THRESHOLD = 8

# Eski pyscreeze sürümlerinde olmayabilir
try:
    ImageNotFoundException = pyautogui.ImageNotFoundException
except AttributeError:
    ImageNotFoundException = getattr(pyautogui, 'ImageNotFoundException', Exception)

BASE_PATH = os.path.dirname(os.path.abspath(__file__))

# Kaynak/ikon klasörleri (örtüşen referanslar)
ICON_DIRS = ('resources', 'icons')

# Büyü masası slot koordinatları (1280x720 -> ölçeklenir)
trash_x, trash_y = set_cord(606, 220)            # eşya slotu / çöp
con2_x, con2_y = set_cord(606, 319)              # geri alma slotu 2
con1_x, con1_y = set_cord(517, 303)              # geri alma slotu 1
lapis_x, lapis_y = set_cord(551, 295)            # lapis slotu

# Bot thread'i (F8 ile başlatılır)
set_thread = None


def debug_print(*args, **kwargs):
    """DEBUG modunda print basar."""
    if DEBUG:
        print(*args, **kwargs)


def envanter_tara():
    """Envanteri tarar ve büyüsüz alet'ları bulur (testt.py mantığı).

    Envanterdeki büyüsüz (henüz büyülenmemiş) aletleri tespit eder.
    Bunlar büyü masasında büyülenecek adaylardır.
    """
    region = (SCAN_X, SCAN_Y, SCAN_W, SCAN_H)
    burst_shots = [pyautogui.screenshot(region=region) for _ in range(0, 12)]

    base_img_gray = cv2.cvtColor(np.array(burst_shots[0]), cv2.COLOR_RGB2BGR)
    all_detections = []
    final_items = []
    found_unenchanted_coords = []

    for item_name, file_name in ITEM_FILES.items():
        template_path = os.path.join(BASE_PATH, 'images', file_name)
        if not os.path.exists(template_path):
            continue
        template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            continue
        h, w = template.shape

        for shot in burst_shots:
            shot_img = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2BGR)
            res = cv2.matchTemplate(shot_img, template, cv2.TM_CCOEFF_NORMED)
            loc = np.where(res >= CONFIDENCE_THRESHOLD)
            for pt in zip(*loc[::-1]):
                all_detections.append((item_name, pt, w, h))

    # Mükerrer eleme
    for det in all_detections:
        is_duplicate = False
        for f_item in final_items:
            if abs(det[1][0] - f_item[1][0]) < 20 and abs(det[1][1] - f_item[1][1]) < 20:
                is_duplicate = True
                break
        if not is_duplicate:
            final_items.append(det)

    max_p_score = 0
    for item_name, pt, w, h in final_items:
        shot_img = cv2.cvtColor(np.array(burst_shots[0]), cv2.COLOR_RGB2BGR)
        item_crop = shot_img[pt[1]:pt[1] + h, pt[0]:pt[0] + w]
        hsv = cv2.cvtColor(item_crop, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, (105, 10, 35), (182, 255, 255))
        score = np.count_nonzero(mask)
        if score > max_p_score:
            max_p_score = score
        target_x = pt[0] + w // 2 + SCAN_X
        target_y = pt[1] + h // 2 + SCAN_Y
        # Büyüsüz (parlama yok) ise büyülenecek aday
        if score < ENCHANT_THRESHOLD:
            found_unenchanted_coords.append((item_name, target_x, target_y))

    for item in found_unenchanted_coords:
        debug_print(CYAN, '[DEBUG] Item: ', item)

    debug_print(CYAN, '[DEBUG] Envanter tarama: ', len(found_unenchanted_coords),
                ' büyüsüz item bulundu')
    return found_unenchanted_coords


def send_embed(title: str, fields=None):
    """Discord webhook'a embed log gönderir.

    title: embed başlığı
    fields: list of dict with 'name', 'value', 'inline' keys (opsiyonel)
    """
    try:
        if fields is None:
            fields = []
        items = []
        for f in fields:
            items.append({
                'name': f.get('name', ''),
                'value': f.get('value', ''),
                'inline': f.get('inline', False),
            })
        discord_logger.send_discord_log('kazma-kurek-kilic', title, items, color=65280)
    except Exception as e:
        print(RED, '[WEBHOOK HATA] ', e)


def xp_kontrol_1lvl():
    """Level 1'de XP barında parlama olup olmadığını kontrol eder (genexpr ile).

    Belirli bir piksel aralığında yeşil piksel sayısını sayar.
    """
    sol_ust = (582, 237)
    sag_alt = (592, 247)
    ekran = pyautogui.screenshot()
    time.sleep(0.5)
    # yeşil piksel sayısı -> 150<=r<=240, 130<=g<=220, 2<=b<=100, 100<=a<=180
    def _gen():
        for x in range(sol_ust[0], sag_alt[0]):
            r, g, b = ekran.getpixel((x, sol_ust[1]))
            if 150 <= r <= 240 and 130 <= g <= 220 and 2 <= b <= 100:
                yield (x, sol_ust[1])
    xp = list(_gen())
    return len(xp) > 0


def xp_kontrol():
    """XP barında parlama olup olmadığını kontrol eder (genexpr ile).

    Belirli bir piksel aralığında yeşil piksel sayısını sayar.
    """
    sol_ust = (585, 305)
    sag_alt = (597, 323)
    ekran = pyautogui.screenshot()
    time.sleep(0.5)
    # yeşil piksel sayısı -> 150<=r<=240, 130<=g<=220, 2<=b<=100, 100<=a<=180
    def _gen():
        for x in range(sol_ust[0], sag_alt[0]):
            r, g, b = ekran.getpixel((x, sol_ust[1]))
            if 150 <= r <= 240 and 130 <= g <= 220 and 2 <= b <= 100:
                yield (x, sol_ust[1])
    xp = list(_gen())
    return len(xp) > 0


def buyu_basma():
    """Ana büyü basma döngüsü (kazma/kürek/kılıç/yay için).

    - Önce başlangıç lapis kontrolü yapar (masaya koyar).
    - Sonra lapis yeniler.
    - running_lock altında ana döngü:
        * Envanterdeki büyüsüz alet'ları tara
        * Her bir alet için: masaya koy, hedef büyü görselini ara
        * Büyü bulunduysa: xp_kontrol, sayacı artır, discord'a bildir,
          eşyayı con1 slotundan geri al
        * Büyü bulunamadıysa: con2 slotundan geri al
        * Tüm alet türleri denendiyse boş kitap bas (RNG sıfırla)
        * Envanterde büyüsüz alet kalmadıysa durdur
    - F8 ile durdurulana kadar devam eder.
    """
    global is_running
    try:
        print(GREEN, '[INFO] Auto Kazma-Kurek-Kilic-Yay Enchant Başlatıldı')
        send_embed('🚀 Auto Kazma-Kurek-Kilic-Yay Enchant Başladı')
        time.sleep(2)
        print(CYAN, '[INFO] Başlangıç Lapis kontrolü yapılıyor...')
        try:
            loc = pyautogui.locateOnScreen(
                os.path.join(BASE_PATH, 'images', 'ttLapis.png'),
                region=(470, 340, 344, 178),
                confidence=0.8,
            )
            if loc is not None:
                target_x = loc.left + loc.width // 2
                target_y = loc.top + loc.height // 2
                pyautogui.moveTo(target_x, target_y)
                pyautogui.keyDown('shift')
                pyautogui.click()
                pyautogui.keyUp('shift')
                time.sleep(0.2)
                print(GREEN, '[INFO] Başlangıçta lapis masaya konuldu!')
            else:
                print(YELLOW, '[INFO] Başlangıçta Lapis bulunamadı (normal, devam ediliyor)')
        except ImageNotFoundException:
            print(YELLOW, '[INFO] Başlangıçta Lapis bulunamadı (normal, devam ediliyor)')
        except Exception as e:
            print(RED, '[HATA] Başlangıç Lapis hatası: ', e)

        print(CYAN, '[INFO] Başlangıç lapis yenileme yapılıyor...')
        try:
            pyautogui.moveTo(lapis_x, lapis_y)
            pyautogui.doubleClick()
            time.sleep(0.2)
            pyautogui.click()
            time.sleep(0.2)
            print(GREEN, '[INFO] Başlangıç lapis yenileme tamamlandı!')
        except Exception as e:
            print(RED, '[HATA] Başlangıç lapis yenileme hatası: ', e)

        # Büyü sayaçları (her hedef büyü için)
        klasor = {
            'Servet 3 (Kazma)': 0,
            'Verimlilik 4 (Kurek)': 0,
            'Saldırı (Kılıç)': 0,
            'Yumruk 2 (Yay)': 0,
            'Sonsuzluk (Yay)': 0,
        }

        with running_lock:
            is_running = True
            try:
                while is_running:
                    denenen_item_tipleri = set()
                    loc = None
                    hx, hy = 0, 0

                    try:
                        unenchanted_items = envanter_tara()
                        print(CYAN, '[INFO] ', len(unenchanted_items),
                              ' adet büyüsüz item bulundu')

                        if not unenchanted_items:
                            print(YELLOW, '[DURDUR] Büyüsüz item kalmadı! İşlem durduruluyor...')
                            send_embed('⛔ Büyüsüz Item Bitti - İşlem Durduruldu')
                            break

                        buyu_map = BUYU_FILES
                        candidates = list(unenchanted_items)
                        for item_name, item_x, item_y in candidates:
                            denenen_item_tipleri.add(item_name)

                            try:
                                # Item'ı büyü masasına koy
                                pyautogui.moveTo(item_x, item_y)
                                pyautogui.keyDown('shift')
                                pyautogui.click()
                                pyautogui.keyUp('shift')
                                time.sleep(0.2)

                                # Bu alet için hedef büyü görsellerini al
                                buyu_dosyasi = buyu_map.get(item_name)
                                buyu_bulundu = False
                                bulunan_buyu = None
                                buyu_file = None
                                loc_buyu = None

                                if item_name == 'Yay' and isinstance(buyu_dosyasi, list):
                                    # Yay için birden fazla büyü adayı dene
                                    for aday in buyu_dosyasi:
                                        buyu_file = 'images\\' + aday
                                        try:
                                            loc_buyu = pyautogui.locateOnScreen(
                                                os.path.join(BASE_PATH, 'images', aday),
                                                confidence=0.93,
                                                grayscale=True,
                                            )
                                        except ImageNotFoundException:
                                            loc_buyu = None
                                        if loc_buyu is not None:
                                            buyu_bulundu = True
                                            bulunan_buyu = aday
                                            break
                                else:
                                    if isinstance(buyu_dosyasi, list):
                                        buyu_listesi = buyu_dosyasi
                                    else:
                                        buyu_listesi = [buyu_dosyasi] if buyu_dosyasi else []
                                    for aday in buyu_listesi:
                                        buyu_file = 'images\\' + aday
                                        try:
                                            loc_buyu = pyautogui.locateOnScreen(
                                                os.path.join(BASE_PATH, 'images', aday),
                                                confidence=0.93,
                                                grayscale=True,
                                            )
                                        except ImageNotFoundException:
                                            loc_buyu = None
                                        if loc_buyu is not None:
                                            buyu_bulundu = True
                                            bulunan_buyu = aday
                                            break

                                if buyu_bulundu and bulunan_buyu is not None:
                                    # Büyü bulundu, ismini çöz
                                    base_name = bulunan_buyu.replace('.png', '')
                                    if base_name == 'servet3':
                                        title = 'Servet 3 (Kazma)'
                                    elif base_name == 'verim4':
                                        title = 'Verimlilik 4 (Kurek)'
                                    elif base_name == 'keskinlik4':
                                        title = 'Saldırı (Kılıç)'
                                    elif base_name == 'yumruk':
                                        title = 'Yumruk 2 (Yay)'
                                    elif base_name == 'sonsuzluk':
                                        title = 'Sonsuzluk (Yay)'
                                    else:
                                        title = 'Genel'

                                    print(GREEN, '[OK] ', item_name, ' için ',
                                          title, ' bulundu!')
                                    xp_kontrol()
                                    key = title
                                    klasor[key] = klasor.get(key, 0) + 1
                                    send_embed('✨ ' + title + ' basıldı!')
                                    print(GREEN, '[OK] ', item_name, ' için ', title,
                                          ' basıldı! Toplam: ', klasor[key])
                                    # Eşyayı con1 slotundan geri al
                                    pyautogui.moveTo(con1_x, con1_y)
                                    pyautogui.keyDown('shift')
                                    pyautogui.click()
                                    pyautogui.keyUp('shift')
                                else:
                                    print(YELLOW, item_name,
                                          ' için büyü bulunamadı, geri alınıyor...')
                                    # Eşyayı con2 slotundan geri al
                                    pyautogui.moveTo(con2_x, con2_y)
                                    pyautogui.keyDown('shift')
                                    pyautogui.click()
                                    pyautogui.keyUp('shift')
                            except Exception as e:
                                print(RED, '[HATA] İşlem hatası: ',
                                      __name__, ' - ', e)
                                traceback.print_exc()
                                print(CYAN, '[INFO] Hata sonrası eşya geri alınıyor...')

                        # Tüm alet türleri denendiyse boş kitap bas (RNG sıfırla)
                        if denenen_item_tipleri >= set(['Kazma', 'Kurek', 'Kilic', 'Yay']):
                            print(CYAN, '[INFO] Tüm eşyalar denendi, boş kitap basılıyor...')
                            try:
                                loc = pyautogui.locateOnScreen(
                                    os.path.join(BASE_PATH, 'images', 'kitap.png'),
                                    grayscale=True,
                                )
                                if loc is not None:
                                    xp_kontrol_1lvl()
                                    pyautogui.moveTo(trash_x, trash_y)
                                    pyautogui.keyDown('shift')
                                    pyautogui.click()
                                    pyautogui.keyUp('shift')
                                    time.sleep(0.3)
                                    pyautogui.moveTo(con2_x, con2_y)
                                    time.sleep(0.1)
                                    pyautogui.press('q')
                                    print(GREEN, '[INFO] Boş kitap basıldı ve atıldı, RNG sıfırlandı.')
                                    denenen_item_tipleri.clear()
                                    # Kitap basıldıktan sonra lapis yenile
                                    try:
                                        pyautogui.moveTo(lapis_x, lapis_y)
                                        pyautogui.doubleClick()
                                        time.sleep(0.2)
                                        pyautogui.click()
                                        time.sleep(0.2)
                                    except Exception as e:
                                        print(RED, '[HATA] Lapis yenileme hatası: ', e)
                                else:
                                    print(CYAN, '[INFO] Kitap bulunamadı, devam ediliyor...')
                            except Exception as e:
                                print(RED, '[HATA] Boş kitap işlemi hatası: ', e)

                    except Exception as e:
                        print(RED, '[HATA] Genel döngü hatası: ', __name__, ' - ', e)
                        traceback.print_exc()

                    time.sleep(1)
            finally:
                is_running = False
                print(YELLOW, '[DURDUR] Bot durduruldu (F8)')
                send_embed('⏸️ Bot Durduruldu')
    except Exception as e:
        print(RED, '[HATA] Genel döngü hatası: ', e)
        traceback.print_exc()
        time.sleep(1)
        print(RED, '[HATA] Başlangıç Lapis hatası: ', e)
    finally:
        print(CYAN, "[INFO] Bot thread'i kapatıldı.")


def on_press(key):
    """F8 tuşu ile botu başlatır/durdurur."""
    global set_thread, is_running
    if key == keyboard.Key.f8:
        if not is_running:
            print(CYAN, '[BAŞLAT] F8 basıldı - Bot başlatılıyor...')
            set_thread = threading.Thread(target=buyu_basma, daemon=True)
            set_thread.start()
        else:
            print(YELLOW, '[DURDUR] F8 basıldı - Bot durduruluyor ve script kapatılıyor...')
            is_running = False
            if set_thread is not None and set_thread.is_alive():
                set_thread.join(timeout=2.0)
            print(RED, '[KAPAT] Script kapatılıyor...')
            sys.exit(0)


def keyboard_listener():
    """pynput keyboard listener başlatır ve join eder."""
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()


def run():
    """Bot dispatcher için giriş noktası.

    Bilgi mesajı yazdırır ve klavye dinleyicisini başlatır.
    F8 ile bot başlatılır/durdurulur.
    """
    auto_start = False
    kb_thread = None
    if not sys.stdin.isatty():
        print(GREEN, "[INFO] GUI'den başlatıldı, F8 tuşuna basarak botu başlatabilirsiniz...")
    print(GREEN, '[INFO] F8 tuşuna basarak botu başlatabilir/durdurebilirsiniz...')
    print(CYAN, "[INFO] Program çalışıyor, F8'ye basın...")
    keyboard_listener()


if __name__ == '__main__':
    run()
