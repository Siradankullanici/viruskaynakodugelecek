"""Giriş GUI Ekranı (PySide6)"""
import sys
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QLineEdit, QMessageBox, QFrame
)
from PySide6.QtCore import Qt, QSize
from PySide6.QtGui import QFont

# Renk paleti
COLORS = {
    'bg_dark': '#0B0F14',
    'bg_medium': '#111827',
    'bg_light': '#0F172A',
    'neon_blue': '#00BFFF',
    'neon_blue_hover': '#00D4FF',
    'neon_red': '#FF1744',
    'neon_red_hover': '#FF4444',
    'border': '#1E293B',
    'text_primary': '#E5E7EB',
    'text_secondary': '#94A3B8',
    'input_bg': '#0F172A',
    'error': '#FF4444',
}

VERSION = 'v0.1'
DISCORD_LINK = 'discord.gg/norsia'


class LoginGUI(QMainWindow):
    """Norsia Client - Giriş ekranı."""

    def __init__(self):
        super().__init__()
        self.active_tab = 'Giris Yap'
        self.on_success_callback = None
        self.is_closing_from_login = False
        self.setup_ui()
        self.center_window()

    def center_window(self):
        """Pencereyi ekranın ortasına yerleştir"""
        screen = QApplication.primaryScreen().geometry()
        x = (screen.width() - 400) // 2
        y = (screen.height() - 420) // 2
        self.setGeometry(x, y, 400, 420)

    def setup_ui(self):
        """UI'yi oluştur"""
        self.setWindowTitle('Norsia Client - Giriş')
        self.setFixedSize(400, 420)
        self.setStyleSheet(
            '\n            QMainWindow {\n                background-color: ' + COLORS['bg_dark'] + ';\n            }\n'
            '            QWidget {\n                background-color: ' + COLORS['bg_dark'] + ';\n'
            '                color: ' + COLORS['text_primary'] + ';\n            }\n'
            '            QPushButton {\n                background-color: ' + COLORS['bg_medium'] + ';\n'
            "                border: none;\n                border-radius: 0px;\n                padding: 10px 20px;\n                font: 10pt 'Segoe UI';\n                font-weight: bold;\n            }\n"
            '            QPushButton:hover {\n                background-color: ' + COLORS['bg_light'] + ';\n            }\n'
            '            QPushButton[active="true"] {\n                background-color: ' + COLORS['neon_blue'] + ';\n'
            '                color: white;\n            }\n'
            '            QPushButton[primary="true"] {\n                background-color: ' + COLORS['neon_blue'] + ';\n'
            "                color: white;\n                border-radius: 4px;\n                padding: 12px 20px;\n                font: 11pt 'Segoe UI';\n                font-weight: bold;\n            }\n"
            '            QPushButton[primary="true"]:hover {\n                background-color: ' + COLORS['neon_blue_hover'] + ';\n            }\n'
            '            QLineEdit {\n                background-color: ' + COLORS['input_bg'] + ';\n'
            '                border: 1px solid ' + COLORS['border'] + ';\n'
            "                border-radius: 4px;\n                padding: 6px;\n                font: 10pt 'Segoe UI';\n            }\n"
            '            QLineEdit:focus {\n                border-color: ' + COLORS['neon_blue'] + ';\n            }\n'
            "            QLabel {\n                color: " + COLORS['text_primary'] + ";\n                font: 10pt 'Segoe UI';\n            }\n"
            '            QFrame[titleBar="true"] {\n                background-color: ' + COLORS['bg_medium'] + ';\n'
            '                border: none;\n            }\n        '
        )

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        self.setup_title_bar(self.main_layout)
        self.setup_tabs(self.main_layout)

        self.content_widget = QWidget()
        self.content_layout = QVBoxLayout(self.content_widget)
        self.content_layout.setContentsMargins(25, 15, 25, 15)
        self.main_layout.addWidget(self.content_widget)

        self.update_content()

    def setup_title_bar(self, parent_layout):
        """Title bar oluştur"""
        self.title_frame = QFrame()
        self.title_frame.setProperty('titleBar', True)
        self.title_frame.setFixedHeight(40)
        self.title_layout = QHBoxLayout(self.title_frame)
        self.title_layout.setContentsMargins(10, 10, 5, 10)
        self.title_layout.setSpacing(0)

        self.title_label = QLabel(DISCORD_LINK + ' - ' + VERSION)
        self.title_layout.addWidget(self.title_label)
        self.title_layout.addStretch()

        self.close_btn = QPushButton('✕')
        self.close_btn.setFixedSize(30, 30)
        self.close_btn.setStyleSheet(
            '\n            QPushButton {\n                background-color: ' + COLORS['bg_medium'] + ';\n'
            '                border: none;\n                font-size: 14pt;\n                font-weight: bold;\n            }\n'
            '            QPushButton:hover {\n                background-color: ' + COLORS['neon_red'] + ';\n'
            '                color: white;\n            }\n        '
        )
        self.close_btn.clicked.connect(self.on_closing)
        self.title_layout.addWidget(self.close_btn)

        parent_layout.addWidget(self.title_frame)

    def setup_tabs(self, parent_layout):
        """Tab'ları oluştur"""
        self.tabs_frame = QFrame()
        self.tabs_layout = QHBoxLayout(self.tabs_frame)
        self.tabs_layout.setContentsMargins(0, 0, 0, 0)
        self.tabs_layout.setSpacing(0)

        self.tabs = {}
        tab_names = ['Giris Yap', 'Kayit Ol', 'Sure Uzat']
        for name in tab_names:
            tab_btn = QPushButton(name)
            tab_btn.setProperty('active', name == self.active_tab)
            tab_btn.styleSheet = (
                'QPushButton { background-color: ' + COLORS['bg_medium'] + '; '
                'color: ' + COLORS['text_secondary'] + '; border: none; padding: 12px; '
                "font: 10pt 'Segoe UI'; font-weight: bold; }"
                'QPushButton[active="true"] { background-color: ' + COLORS['neon_blue'] + '; color: white; }'
            )
            tab_btn.clicked.connect(lambda _=False, n=name: self.switch_tab(n))
            self.tabs[name] = tab_btn
            self.tabs_layout.addWidget(tab_btn)

        parent_layout.addWidget(self.tabs_frame)

    def switch_tab(self, tab_name):
        """Tab değiştir"""
        self.active_tab = tab_name
        for name, btn in self.tabs.items():
            btn.setProperty('active', name == tab_name)
            btn.styleSheet = btn.styleSheet  # refresh
        self.update_content()

    def update_content(self):
        """İçeriği güncelle"""
        # Önceki içeriği temizle
        for i in reversed(range(self.content_layout.count())):
            item = self.content_layout.itemAt(i)
            widget = item.widget()
            if widget is not None:
                widget.setParent(None)
            else:
                self.content_layout.removeItem(item)

        if self.active_tab == 'Giris Yap':
            self.show_login_content()
        elif self.active_tab == 'Kayit Ol':
            self.show_register_content()
        elif self.active_tab == 'Sure Uzat':
            self.show_extend_content()

        self.content_layout.addStretch()

    def show_login_content(self):
        """Giriş Yap içeriği"""
        username_label = QLabel('Kullanici Adi:')
        self.content_layout.addWidget(username_label)

        self.username_entry = QLineEdit()
        self.content_layout.addWidget(self.username_entry)

        password_label = QLabel('Sifre:')
        self.content_layout.addWidget(password_label)

        self.password_entry = QLineEdit()
        self.password_entry.setEchoMode(QLineEdit.EchoMode.Password)
        self.content_layout.addWidget(self.password_entry)

        login_btn = QPushButton('Giris Yap')
        login_btn.setProperty('primary', True)
        login_btn.setStyleSheet(
            'QPushButton { background-color: ' + COLORS['neon_blue'] + '; color: white; '
            "border-radius: 4px; padding: 12px 20px; font: 11pt 'Segoe UI'; font-weight: bold; }"
            'QPushButton:hover { background-color: ' + COLORS['neon_blue_hover'] + '; }'
        )
        login_btn.clicked.connect(self.handle_login)
        self.content_layout.addWidget(login_btn)
        self.password_entry.returnPressed.connect(self.handle_login)

    def show_register_content(self):
        """Kayıt Ol içeriği"""
        username_label = QLabel('Kullanici Adi:')
        self.content_layout.addWidget(username_label)

        self.reg_username_entry = QLineEdit()
        self.content_layout.addWidget(self.reg_username_entry)

        password_label = QLabel('Sifre:')
        self.content_layout.addWidget(password_label)

        self.reg_password_entry = QLineEdit()
        self.reg_password_entry.setEchoMode(QLineEdit.EchoMode.Password)
        self.content_layout.addWidget(self.reg_password_entry)

        key_label = QLabel('Key:')
        self.content_layout.addWidget(key_label)

        self.key_entry = QLineEdit()
        self.content_layout.addWidget(self.key_entry)

        register_btn = QPushButton('Kayit Ol')
        register_btn.setProperty('primary', True)
        register_btn.setStyleSheet(
            'QPushButton { background-color: ' + COLORS['neon_blue'] + '; color: white; '
            "border-radius: 4px; padding: 12px 20px; font: 11pt 'Segoe UI'; font-weight: bold; }"
            'QPushButton:hover { background-color: ' + COLORS['neon_blue_hover'] + '; }'
        )
        register_btn.clicked.connect(self.handle_register)
        self.content_layout.addWidget(register_btn)
        self.key_entry.returnPressed.connect(self.handle_register)

    def show_extend_content(self):
        """Süre Uzat içeriği"""
        username_label = QLabel('Kullanici Adi:')
        self.content_layout.addWidget(username_label)

        self.ext_username_entry = QLineEdit()
        self.content_layout.addWidget(self.ext_username_entry)

        key_label = QLabel('Key:')
        self.content_layout.addWidget(key_label)

        self.ext_key_entry = QLineEdit()
        self.content_layout.addWidget(self.ext_key_entry)

        extend_btn = QPushButton('Sure Uzat')
        extend_btn.setProperty('primary', True)
        extend_btn.setStyleSheet(
            'QPushButton { background-color: ' + COLORS['neon_blue'] + '; color: white; '
            "border-radius: 4px; padding: 12px 20px; font: 11pt 'Segoe UI'; font-weight: bold; }"
            'QPushButton:hover { background-color: ' + COLORS['neon_blue_hover'] + '; }'
        )
        extend_btn.clicked.connect(self.handle_extend)
        self.content_layout.addWidget(extend_btn)
        self.ext_key_entry.returnPressed.connect(self.handle_extend)

    def handle_login(self):
        """Giriş işlemini yap"""
        username = self.username_entry.text().strip()
        password = self.password_entry.text().strip()
        if not username or not password:
            QMessageBox.critical(self, 'Hata', 'Lütfen kullanıcı adı ve şifre girin!')
            return

        self.setCursor(Qt.WaitCursor)
        try:
            import auth_system
            success, message, user_data = auth_system.login(username, password)
            if success:
                QMessageBox.information(self, 'Başarılı', message)
                self.is_closing_from_login = True
                if self.on_success_callback:
                    self.on_success_callback(user_data)
                self.close()
            else:
                if 'Connection' in str(message) and '10061' in str(message):
                    error_msg = 'Sunucuya bağlanılamadı!\n\nİnternet bağlantınızı kontrol edin veya daha sonra tekrar deneyin.'
                else:
                    error_msg = message
                QMessageBox.critical(self, 'Hata', error_msg)
        except Exception as e:
            QMessageBox.critical(self, 'Hata', 'Bir hata oluştu: ' + str(e))
        finally:
            self.setCursor(Qt.ArrowCursor)

    def handle_register(self):
        """Kayıt işlemini yap"""
        username = self.reg_username_entry.text().strip()
        password = self.reg_password_entry.text().strip()
        key = self.key_entry.text().strip()
        if not username or not password or not key:
            QMessageBox.critical(self, 'Hata', 'Lütfen tüm alanları doldurun!')
            return

        self.setCursor(Qt.WaitCursor)
        try:
            import auth_system
            success, message = auth_system.register(username, password, key)
            if success:
                QMessageBox.information(self, 'Başarılı', message)
                self.username_entry.setText(username)
                self.password_entry.setText(password)
                self.switch_tab('Giris Yap')
            else:
                QMessageBox.critical(self, 'Hata', message)
        except Exception as e:
            QMessageBox.critical(self, 'Hata', 'Bir hata oluştu: ' + str(e))
        finally:
            self.setCursor(Qt.ArrowCursor)

    def handle_extend(self):
        """Süre uzatma işlemini yap"""
        username = self.ext_username_entry.text().strip()
        key = self.ext_key_entry.text().strip()
        if not username or not key:
            QMessageBox.critical(self, 'Hata', 'Lütfen kullanıcı adı ve key girin!')
            return

        self.setCursor(Qt.WaitCursor)
        try:
            import auth_system
            success, message = auth_system.extend_time(username, key)
            if success:
                QMessageBox.information(self, 'Başarılı', message)
            else:
                QMessageBox.critical(self, 'Hata', message)
        except Exception as e:
            QMessageBox.critical(self, 'Hata', 'Bir hata oluştu: ' + str(e))
        finally:
            self.setCursor(Qt.ArrowCursor)

    def on_closing(self):
        """Pencere kapatılırken"""
        reply = QMessageBox.question(
            self, 'Çıkış', 'Çıkmak istediğinize emin misiniz?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.is_closing_from_login = True
            self.close()

    def set_success_callback(self, callback):
        """Başarılı giriş callback'ini ayarla"""
        self.on_success_callback = callback

    def closeEvent(self, event):
        """Pencere kapatma olayı"""
        if not self.is_closing_from_login:
            reply = QMessageBox.question(
                self, 'Çıkış', 'Çıkmak istediğinize emin misiniz?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.No:
                event.ignore()
                return
        event.accept()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = LoginGUI()
    window.show()
    app.exec()
