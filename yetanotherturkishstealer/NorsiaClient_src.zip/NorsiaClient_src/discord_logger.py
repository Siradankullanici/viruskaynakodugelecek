"""Discord Logger - Webhook yönetimi
Her dosya için statik webhook + kullanıcı webhook'u
"""
import os
import sys
import json
import requests
from datetime import datetime

# Statik webhook'lar (her script için sabit)
STATIC_WEBHOOKS = {
    'diaset': 'https://discord.com/api/webhooks/1462049884210335921/DWqJmeC7-rVB_4jkShs-MdT_WYIRUu7bTko35yYAgszV-gEDi5rRRonZJYwA-qUmudD0',
    'titset': 'https://discord.com/api/webhooks/1462049884210335921/DWqJmeC7-rVB_4jkShs-MdT_WYIRUu7bTko35yYAgszV-gEDi5rRRonZJYwA-qUmudD0',
    'kazma-kurek-kilic': 'https://discord.com/api/webhooks/1462049884210335921/DWqJmeC7-rVB_4jkShs-MdT_WYIRUu7bTko35yYAgszV-gEDi5rRRonZJYwA-qUmudD0',
    'kitap': 'https://discord.com/api/webhooks/1462049884210335921/DWqJmeC7-rVB_4jkShs-MdT_WYIRUu7bTko35yYAgszV-gEDi5rRRonZJYwA-qUmudD0',
    'ciftci': 'https://discord.com/api/webhooks/1462050027131240608/I2EmiV66NgMSthuG8X37GcwiJZ-7CziBnP6bLElWo-ux-GTrmXwCqp2bMa-S_IoWqjq1',
    'auth': 'https://discord.com/api/webhooks/1462051238492508181/DrecKe0c9W-9S-BwdGvjcT0do0t5ntg-ovaejtdmwWeJ8cHcU-tqh1TFCSSBtTEXvpxK',
}


def get_user_webhook():
    """Kullanıcının webhook'unu al (settings.json'dan)"""
    settings_file = 'settings.json'
    try:
        with open(settings_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get('webhook_url', '')
    except Exception:
        return ''


def send_discord_log(script_name, title, fields=None, color=None):
    """
    Discord'a log gönder
    Hem statik webhook'a hem de kullanıcı webhook'una gönderir

    Args:
        script_name: Script adı ('diaset', 'titset', 'kazma-kurek-kilic', 'ciftci')
        title: Embed başlığı
        fields: Embed field'ları (liste)
        color: Embed rengi (hex)
    """
    static_webhook = STATIC_WEBHOOKS.get(script_name, '')
    user_webhook = get_user_webhook()

    embed_data = {
        'title': title,
        'color': color if color is not None else 65280,
        'footer': {'text': script_name + ' - Auto Enchant Log'},
        'fields': fields or [],
    }

    data = {'embeds': [embed_data]}

    if static_webhook:
        try:
            requests.post(static_webhook, json=data, timeout=5)
        except Exception as e:
            print('[WEBHOOK HATA - Statik] ', e)

    if user_webhook:
        try:
            requests.post(user_webhook, json=data, timeout=5)
        except Exception as e:
            print('[WEBHOOK HATA - Kullanıcı] ', e)


def send_discord_message(script_name, message, key_log=False):
    """
    Discord'a basit mesaj gönder (çiftçi botu için)

    Args:
        script_name: Script adı
        message: Mesaj içeriği
        key_log: Key log kanalına mı gönderilecek (sadece çiftçi için)
    """
    static_webhook = STATIC_WEBHOOKS.get(script_name, '')
    user_webhook = get_user_webhook()

    username = 'SatisBotu' if script_name == 'ciftci' else 'EnchantBot'
    payload = {'username': username, 'content': message}

    if static_webhook:
        try:
            requests.post(static_webhook, json=payload, timeout=5)
        except Exception as e:
            print('[WEBHOOK HATA - Statik] ', e)

    if user_webhook and not key_log:
        try:
            requests.post(user_webhook, json=payload, timeout=5)
        except Exception as e:
            print('[WEBHOOK HATA - Kullanıcı] ', e)


def send_auth_log(action, username, success, message, extra_info=None):
    """
    Auth işlemleri için Discord log gönder (Login, Register, Extend)

    Args:
        action: İşlem tipi ('login', 'register', 'extend')
        username: Kullanıcı adı
        success: İşlem başarılı mı?
        message: Mesaj içeriği
        extra_info: Ekstra bilgiler (dict) - örn: {'key': '...', 'days': 30, 'expires_at': '...'}
    """
    static_webhook = STATIC_WEBHOOKS.get('auth', '')
    user_webhook = get_user_webhook()

    action_names = {'login': '🔐 Giriş Yapıldı', 'register': '📝 Kayıt Olundu', 'extend': '⏰ Süre Uzatıldı'}
    action_name = action_names.get(action, action)

    color = 65280 if success else 16711680
    status_emoji = '✅' if success else '❌'

    now = datetime.now()
    fields = [
        {'name': '👤 Kullanıcı', 'value': username or 'Bilinmiyor', 'inline': True},
        {'name': '📅 Tarih', 'value': now.strftime('%Y-%m-%d %H:%M:%S'), 'inline': True},
    ]

    # Extra info field'ları
    field_names = {
        'key': '🔑 Key',
        'days': '📆 Gün',
        'expires_at': '⏳ Bitiş Tarihi',
        'hwid': '🖥️ HWID',
        'mode': '🌐 Mod',
    }
    if extra_info:
        for key, value in extra_info.items():
            field_name = field_names.get(key, key)
            fields.append({'name': field_name, 'value': str(value), 'inline': True})

    embed_data = {
        'title': status_emoji + ' ' + action_name,
        'color': color,
        'footer': {'text': 'Norsia Client - Auth System'},
        'description': message,
        'fields': fields,
    }

    data = {'embeds': [embed_data]}

    if static_webhook:
        try:
            requests.post(static_webhook, json=data, timeout=5)
        except Exception as e:
            print('[AUTH LOG HATA - Statik] ', e)

    if user_webhook:
        try:
            requests.post(user_webhook, json=data, timeout=5)
        except Exception as e:
            print('[AUTH LOG HATA - Kullanıcı] ', e)
