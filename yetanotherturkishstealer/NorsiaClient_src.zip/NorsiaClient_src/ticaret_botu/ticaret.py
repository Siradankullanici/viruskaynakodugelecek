"""
ticaret_botu.ticaret - Ticaret Botu (Trade Bot)

Sonoyuncu sunucusunda oyuncularin 'sana ticaret' isteklerini log dosyasindan
takip eder, ticaret menusunu acar, envanterdeki set item'larini koyar,
para miktarini OCR ile okur ve istenen miktarsa ticareti kabul eder.
Periyodik olarak da reklam mesaji gonderir.

F8 tusu ile baslatilir/durdurulur.
"""

import os
import sys
import io
import time
import threading
import traceback
import re

# ---------------------------------------------------------------------------
# Windows console UTF-8 setup
# ---------------------------------------------------------------------------
if sys.stdout.encoding is None or sys.stdout.encoding.lower() != 'utf-8' or os.environ.get('PYTHONIOENCODING', '').lower() != 'utf-8':
    try:
        import subprocess
        subprocess.run(['chcp', '65001'], shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        pass
    try:
        os.system('chcp 65001 >nul 2>&1')
    except Exception:
        pass

import numpy as np
from colorama import Fore, init
init(autoreset=True, strip=False, convert=False)
from pynput import keyboard

import cv2
import pyautogui

# Re-wrap stdout/stderr for UTF-8 (Turkish characters)
try:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace', line_buffering=True)
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace', line_buffering=True)
except Exception as e:
    pass


# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------
CYAN = Fore.CYAN
GREEN = Fore.GREEN
RED = Fore.RED
YELLOW = Fore.YELLOW

USERPROFILE = os.environ.get('USERPROFILE', '') or os.environ.get('USER_PROFILE', '')
LOG_FILE = os.path.join(USERPROFILE, 'AppData', 'Roaming', '.sonoyuncu', 'logs', 'latest.log')
ICON_DIRS = ('resources', 'icons')
BASE_PATH = os.getcwd()

# Set secenekleri (GUI'den veya kullanicidan secilir)
SET_OPTIONS = {
    '1': {
        'name': 'Tit Set',
        'items': {'Kask': 'tkask.png', 'CP': 'tcp.png', 'Pant': 'tpant.png', 'Bot': 'tbot.png'},
        'items_to_place': ['Kask', 'CP', 'Pant', 'Bot'],
    },
    '2': {
        'name': 'Dia Set',
        'items': {'Kask': 'kask.png', 'CP': 'cp.png', 'Pant': 'pant.png', 'Bot': 'bot.png'},
        'items_to_place': ['Kask', 'CP', 'Pant', 'Bot'],
    },
    '3': {
        'name': 'Duel Kiti',
        'items': {'Kask': 'kask.png', 'CP': 'cp.png', 'Pant': 'pant.png', 'Bot': 'bot.png',
                  'Kilic': 'kilic.png', 'Yay': 'yay.png'},
        'items_to_place': ['Kask', 'CP', 'Pant', 'Bot', 'Kilic', 'Yay'],
    },
}

# Ticaret envanteri tarama bolgesi (x, y, w, h)
TRADE_INV_REGION = (470, 411, 337, 154)

# Ticaret menu butonlari
CANCEL_BUTTON = (593, 357)
ACCEPT_BUTTON = (642, 356)

# Ticaret menusu acik mi kontrol bolgesi ve dosyasi
TRADE_MENU_REGION = (387, 132, 49, 22)
TRADE_MENU_CHECK_PATH = os.path.join('resources', 'ticaretsayi', 'tic.png')

# Para okuma (OCR) bolgesi ve sablon klasoru
PARA_COORDS = {'left': 771, 'top': 368, 'width': 112, 'height': 23}
PARA_TEMPLATE_PATH = ('resources', 'ticaretsayi')

# Chest envanteri tarama bolgesi
CHEST_SCAN_X = 433
CHEST_SCAN_Y = 133
CHEST_SCAN_W = 406
CHEST_SCAN_H = 255
CHEST_INV_REGION = (CHEST_SCAN_X, CHEST_SCAN_Y, CHEST_SCAN_W, CHEST_SCAN_H)

# VIP prefix'leri (parse_trade_request icin)
VIP_PREFIXES = ['svip', 'svip+', 'suvip', 'suvip+', 'vip', 'uvip', 'uvip+',
                'mvp', 'mvp+', 'hvip', 'hvip+']

# Eslesme guven esikleri
CONFIDENCE_THRESHOLD = 0.5
LOCATE_CONFIDENCE = 0.65
OCR_TEMPLATE_THRESHOLD = 0.85

# Ticaret bekleme suresi (saniye) - ayni kisiyle tekrar ticaret icin cooldown
TRADE_COOLDOWN = 5

# Reklam gonderim araligi varsayilani (saniye); ortam degiskeninden overwrite edilir
AD_INTERVAL_DEFAULT = 60

# Lock'lar ve global durum
running_lock = threading.Lock()
is_running = False
is_sending_ad = False
is_trading = False

# Log dosyasi pozisyon takibi
last_file_position = 0

# Ticaret ayarlari (on_press tarafindan set edilir)
selected_set = None
ITEM_FILES = {}
ITEMS_TO_PLACE = []
requested_amount = 0
ad_message = ''
chest_enabled = False
last_trade_time = 0

# Thread referanslari
trade_thread = None
ad_thread = None


# ===========================================================================
# ocr_final_v3 - Para miktarini OCR ile okur (tt.py'deki para okuma fonksiyonu)
# ===========================================================================
def ocr_final_v3():
    """tt.py'deki para okuma fonksiyonu"""
    try:
        screenshot = pyautogui.screenshot(
            region=(PARA_COORDS['left'], PARA_COORDS['top'],
                    PARA_COORDS['width'], PARA_COORDS['height'])
        )
        img_gray = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2GRAY)
    except Exception as e:
        print(RED, '[HATA] Ekran görüntüsü alınamadı: ' + str(e))
        return '0'

    template_dir = os.path.join(*PARA_TEMPLATE_PATH)
    if not os.path.isdir(template_dir):
        print(RED, '[HATA] Para template klasoru bulunamadi: ' + template_dir)
        return '0'

    bulunan_adaylar = []
    for dosya in os.listdir(template_dir):
        if not dosya.endswith('.png'):
            continue
        char = dosya.replace('.png', '')
        tpl = cv2.imread(os.path.join(template_dir, dosya), cv2.IMREAD_GRAYSCALE)
        if tpl is None:
            continue
        res = cv2.matchTemplate(img_gray, tpl, cv2.TM_CCOEFF_NORMED)
        loc = np.where(res >= OCR_TEMPLATE_THRESHOLD)
        for pt in zip(*loc[::-1]):
            score = res[pt[1], pt[0]]
            bulunan_adaylar.append((pt[0], char, score, tpl.shape[1]))

    # X pozisyonuna gore sirala (soldan saga okuma)
    bulunan_adaylar.sort(key=lambda x: x[0], reverse=False)

    # Yakindaki duplikatlari ele
    kesin_listesi = []
    for aday in bulunan_adaylar:
        x, char, score, w = aday
        is_duplicate = False
        for kesin in kesin_listesi:
            tolerans = max(kesin[3], w) // 2
            if tolerans < 4:
                tolerans = 4
            elif tolerans > 10:
                tolerans = 10
            if abs(x - kesin[0]) < tolerans:
                is_duplicate = True
                break
        if not is_duplicate:
            kesin_listesi.append(aday)

    sonuc = ''.join([k[1] for k in kesin_listesi if k[1].isdigit()])
    print(CYAN, '[INFO] Okunan para: ' + sonuc)
    return sonuc


# ===========================================================================
# ticaret_menusu_acik_mi - Ticaret menusunun acik olup olmadigini kontrol eder
# ===========================================================================
def ticaret_menusu_acik_mi():
    """Ticaret menüsünün açık olup olmadığını kontrol eder"""
    try:
        if not os.path.exists(TRADE_MENU_CHECK_PATH):
            print(YELLOW, '[UYARI] Ticaret menü kontrol dosyası bulunamadı: ' + TRADE_MENU_CHECK_PATH)
            return False

        # Sablonun boyutunu al
        img = cv2.imread(TRADE_MENU_CHECK_PATH, cv2.IMREAD_GRAYSCALE)
        if img is None:
            return False
        img_height, img_width = img.shape[:2]

        # Bolgeyi sablon boyutundan biraz genislet
        region_x, region_y, region_w, region_h = TRADE_MENU_REGION
        expanded_w = max(region_w, img_width + 100)
        expanded_h = max(region_h, img_height + 50)
        expanded_x = max(0, region_x - 50)
        expanded_y = max(0, region_y - 25)
        expanded_region = (expanded_x, expanded_y, expanded_w, expanded_h)

        try:
            loc = pyautogui.locateOnScreen(
                TRADE_MENU_CHECK_PATH,
                region=expanded_region, confidence=0.7, grayscale=True
            )
            if loc:
                print(GREEN, '[OK] Ticaret menüsü açık')
                return True
        except pyautogui.ImageNotFoundException as inf:
            msg = str(inf).lower()
            if 'exceed' in msg and 'dimension' in msg:
                # Sablon bolgeden buyuk - menusu tam ekran ara
                pass
            else:
                raise
        except Exception:
            raise

        # Tum ekranda tekrar dene
        try:
            loc = pyautogui.locateOnScreen(
                TRADE_MENU_CHECK_PATH,
                confidence=0.7, grayscale=True
            )
            if loc:
                print(GREEN, '[OK] Ticaret menüsü açık (tüm ekranda bulundu)')
                return True
        except pyautogui.ImageNotFoundException:
            return False
        except Exception:
            return False

        return False
    except Exception as e:
        error_msg = str(e)
        print(RED, '[HATA] Ticaret menü kontrolü genel hatası: ' + error_msg)
        return False


# ===========================================================================
# envanter_tara - Envanterde secilen set item'larini bulur
# ===========================================================================
def envanter_tara():
    """Envanterde seçilen set item'larını bulur"""
    region = TRADE_INV_REGION
    try:
        screenshot = pyautogui.screenshot(region=region)
        img = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    except Exception as e:
        print(RED, '[HATA] Ekran goruntusu alinamadi: ' + str(e))
        return {}

    found_items = {}
    for item_name, file_name in ITEM_FILES.items():
        template_path = os.path.join(*ICON_DIRS, file_name) if not os.path.isabs(file_name) else file_name
        if not os.path.exists(template_path):
            template_path = os.path.join(os.getcwd(), file_name)
        template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
        if template is None:
            continue
        res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
        adjusted_threshold = max(CONFIDENCE_THRESHOLD, max_val - 0.1)
        loc = np.where(res >= adjusted_threshold)

        candidates = []
        for pt in zip(*loc[::-1]):
            score = res[pt[1], pt[0]]
            candidates.append((pt[0], pt[1], score, template.shape[1]))
        candidates.sort(key=lambda c: c[2], reverse=True)

        selected = []
        for cand in candidates:
            x, y, score, w = cand
            is_duplicate = False
            for sel in selected:
                sel_x, sel_y = sel[0], sel[1]
                if abs(x - sel_x) < max(w // 2, 15) and abs(y - sel_y) < 10:
                    is_duplicate = True
                    break
            if not is_duplicate:
                global_x = region[0] + x
                global_y = region[1] + y
                selected.append((global_x, global_y, score, w))
            if len(selected) >= 12:
                break
        found_items[item_name] = selected
    return found_items


# ===========================================================================
# chest_ten_item_al - Chest'ten item alir
# ===========================================================================
def chest_ten_item_al(chest_already_open):
    r"""Chest'ten item alır\n    \n    Args:\n        chest_already_open: Eğer True ise, chest zaten açık kabul edilir ve /chest komutu yazılmaz\n    """
    if not chest_already_open:
        print(CYAN, "[INFO] Chest'ten item alınıyor...")
        pyautogui.press('t')
        time.sleep(0.5)
        pyautogui.typewrite('/chest', interval=0.05)
        time.sleep(0.2)
        pyautogui.press('enter')
        time.sleep(2)

    with running_lock:
        is_running_state = is_running
    # Secilen set'e gore her item'den kac tane alinacagi
    if selected_set in ('1', '2'):
        item_count_per_type = 8
    elif selected_set == '3':
        item_count_per_type = 6
    else:
        item_count_per_type = 8

    print(CYAN, "[INFO] Her item'den " + str(item_count_per_type) + " tane alınacak...")

    region = CHEST_INV_REGION
    total_alindi = 0
    for item_name in ITEMS_TO_PLACE:
        file_name = ITEM_FILES.get(item_name, item_name.lower() + '.png')
        template_path = os.path.join(*ICON_DIRS, file_name) if not os.path.isabs(file_name) else file_name
        if not os.path.exists(template_path):
            template_path = os.path.join(os.getcwd(), file_name)
        if not os.path.exists(template_path):
            print(YELLOW, '[UYARI] ' + item_name + ' template dosyası bulunamadı: ' + template_path)
            continue
        try:
            screenshot = pyautogui.screenshot(region=region)
            img = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
            img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            template = cv2.imread(template_path, cv2.IMREAD_GRAYSCALE)
            if template is None:
                print(YELLOW, "[UYARI] Chest'te " + item_name + ' bulunamadı')
                continue
            res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
            min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
            adjusted_threshold = max(CONFIDENCE_THRESHOLD, max_val - 0.1)
            loc = np.where(res >= adjusted_threshold)

            candidates = []
            for pt in zip(*loc[::-1]):
                score = res[pt[1], pt[0]]
                candidates.append((pt[0], pt[1], score, template.shape[1]))
            candidates.sort(key=lambda c: c[2], reverse=True)

            selected = []
            for cand in candidates:
                x, y, score, w = cand
                is_duplicate = False
                for sel in selected:
                    sel_x, sel_y = sel[0], sel[1]
                    if abs(x - sel_x) < max(w // 2, 15) and abs(y - sel_y) < 10:
                        is_duplicate = True
                        break
                if not is_duplicate:
                    global_x = region[0] + x
                    global_y = region[1] + y
                    selected.append((global_x, global_y, score, w))

            if not selected:
                print(YELLOW, "[UYARI] Chest'te " + item_name + ' bulunamadı')
                continue

            print(CYAN, '[INFO] ' + item_name + ': ' + str(len(selected)) + ' tane bulundu, alınıyor...')

            alinacak_miktar = min(item_count_per_type, len(selected))
            for i in range(alinacak_miktar):
                sel_x, sel_y = selected[i][0], selected[i][1]
                pyautogui.moveTo(sel_x, sel_y, duration=0.1)
                time.sleep(0.05)
                pyautogui.keyDown('shift')
                pyautogui.click()
                pyautogui.keyUp('shift')
                time.sleep(0.1)
                total_alindi += 1
        except Exception as e:
            print(RED, '[HATA] ' + item_name + ' alınırken hata: ' + str(e))

    print(CYAN, '[INFO] Chest menüsü kapatılıyor...')
    pyautogui.press('e')
    print(GREEN, "[OK] Chest'ten toplam " + str(total_alindi) + ' adet item alındı ve chest kapatıldı')
    return total_alindi


# ===========================================================================
# set_koy - Envanterdeki set item'larini ticaret ekranina koyar
# ===========================================================================
def set_koy():
    """Envanterdeki set item'larını ticaret ekranına koyar"""
    found_items = envanter_tara()
    placed_count = 0
    used_positions = []

    # Ticaret ekranindaki slotlar (4x3 = 12 slot, kaba koordinatlar)
    trade_slots = []
    start_x, start_y = 350, 230
    step_x, step_y = 50, 50
    for row in range(3):
        for col in range(4):
            trade_slots.append((start_x + col * step_x, start_y + row * step_y))

    for item_name in ITEMS_TO_PLACE:
        item_list = found_items.get(item_name, [])
        if not item_list:
            continue
        for source_x, source_y in [(it[0], it[1]) for it in item_list]:
            item_placed = False
            for slot_x, slot_y in trade_slots:
                is_used = False
                for used_x, used_y in used_positions:
                    if abs(slot_x - used_x) < 5 and abs(slot_y - used_y) < 5:
                        is_used = True
                        break
                if is_used:
                    continue
                try:
                    pyautogui.moveTo(source_x, source_y, duration=0.1)
                    time.sleep(0.05)
                    pyautogui.keyDown('shift')
                    pyautogui.click()
                    pyautogui.keyUp('shift')
                    time.sleep(0.1)
                    used_positions.append((slot_x, slot_y))
                    placed_count += 1
                    item_placed = True
                    break
                except Exception as e:
                    print(RED, item_name + ' konulurken hata: ' + str(e))
                    continue
            if not item_placed:
                print(YELLOW, item_name + ' icin kullanilabilir pozisyon bulunamadi veya tum pozisyonlar zaten kullanildi!')
                break

    if placed_count == 0:
        print(RED, "[HATA] Hicbir set item'i bulunamadi!")

    missing = [name for name in ITEMS_TO_PLACE if not found_items.get(name)]
    if missing:
        print(YELLOW, "[UYARI] Eksik item'lar: " + ', '.join(missing))

    print(GREEN, '[OK] ' + str(placed_count) + '/' + str(len(ITEMS_TO_PLACE)) + ' adet item ticaret ekranina konuldu.')
    return placed_count, len(ITEMS_TO_PLACE)


# ===========================================================================
# read_new_lines - Log dosyasindan yeni satirlari okur
# ===========================================================================
def read_new_lines():
    """Log dosyasından yeni satırları okur"""
    global last_file_position
    new_lines = []
    try:
        current_size = os.path.getsize(LOG_FILE)
        if current_size < last_file_position:
            # Log dosyasi dondu / sifirlandi
            last_file_position = 0
        with open(LOG_FILE, 'r', encoding='utf-8', errors='ignore') as f:
            f.seek(last_file_position)
            new_lines = f.readlines()
            new_position = f.tell()
        last_file_position = new_position
        if new_lines:
            incomplete_line = new_lines[-1]
            if not incomplete_line.endswith('\n'):
                # Son satir tamamlanmamis olabilir, bir sonraki okumaya birak
                completed_text = ''.join(new_lines[:-1])
                last_file_position -= len(incomplete_line)
                if not completed_text:
                    return []
                result = completed_text.split('\n')
                if result and not result[-1].strip():
                    result.pop()
                return [line.strip() for line in result if line.strip()]
            result = [line.rstrip('\n').strip() for line in new_lines if line.strip()]
            return result
        return []
    except Exception as e:
        print(RED, '[HATA] Log dosyasi okuma hatasi: ' + str(e))
        traceback.print_exc()
        return []


# ===========================================================================
# parse_trade_request - Log satirindan ticaret istegini parse eder
# ===========================================================================
def parse_trade_request(line):
    """Log satırından ticaret isteğini parse eder"""
    try:
        line_lower = line.lower()
        # Yaygin yazim hatalarini duzelt
        for wrong, correct in [('iste?i', 'istek'), ('isteği', 'istek'),
                               ('gnderdi', 'gönderdi'), ('gönderdi', 'gonderdi')]:
            line_lower = line_lower.replace(wrong, correct)

        has_ticaret = 'ticaret' in line_lower
        has_gonderdi = ('gönderdi' in line_lower) or ('gonderdi' in line_lower)
        has_iste = 'iste' in line_lower
        has_sana = 'sana' in line_lower
        has_sana_ticaret = 'sana ticaret' in line_lower

        if not (has_sana and has_ticaret):
            return None

        sana_pos = line_lower.find('sana')
        ticaret_pos = line_lower.find('ticaret')
        sana_word_pos = line_lower.find('sana ticaret') if has_sana_ticaret else -1
        ticaret_word_pos = sana_word_pos + len('sana ticaret') if sana_word_pos >= 0 else ticaret_pos

        before_sana = line_lower[:sana_pos] if sana_pos >= 0 else ''
        chat_pos = before_sana.rfind('[chat]')
        if chat_pos < 0:
            chat_pos = before_sana.rfind('[CHAT]')
        after_chat = before_sana[chat_pos:] if chat_pos >= 0 else before_sana

        # '§' renk kodlarini ve '+' VIP ayiracini kaldır
        section_pos = after_chat.rfind('§')
        after_section = after_chat[section_pos:] if section_pos >= 0 else after_chat
        parts = after_section.split('+')

        player_name = None
        for part in parts:
            part_original = part
            part_lower = part.lower()
            part_clean = re.sub('[^a-zA-Z0-9_]', '', part_lower)
            if not part_clean:
                continue
            # VIP prefix kontrolu
            is_vip_prefix = False
            for vip_prefix in VIP_PREFIXES:
                vip_lower = vip_prefix.lower()
                if part_clean.startswith(vip_lower):
                    is_vip_prefix = True
                    # Prefix'ten sonraki kisim oyuncu adi olabilir
                    remaining = part_clean[len(vip_lower):]
                    if remaining and re.match('^[a-zA-Z0-9_]+$', remaining):
                        player_name = remaining
                    break
            if is_vip_prefix:
                if player_name:
                    break
                continue
            # VIP prefix yoksa, temiz parca oyuncu adi olabilir
            if re.match('^[a-zA-Z0-9_]{2,}$', part_clean):
                player_name = part_clean
                break

        if not player_name:
            # Regex desenleriyle dene
            patterns = [
                r'§[^\s]+\s+([a-zA-Z0-9_]+)\s+sana\s+ticaret',
                r'(?:svip|vip|uvip|mvp|premium)\+?\s+([a-zA-Z0-9_]+)\s+sana\s+ticaret',
                r'([a-zA-Z0-9_]{2,})\s+sana\s+ticaret',
                r'\[CHAT\].*?([a-zA-Z0-9_]{2,})\s+sana\s+ticaret',
            ]
            for pattern in patterns:
                match = re.search(pattern, line, re.IGNORECASE)
                if match:
                    player_name = match.group(1)
                    break

        if player_name:
            player_name = player_name.replace('+', '')
            return player_name
        return None
    except Exception as e:
        print(RED, '[HATA] parse_trade_request: ' + str(e))
        return None


# ===========================================================================
# process_trade - Ticaret islemini gerceklestirir
# ===========================================================================
def process_trade(player_name):
    """Ticaret işlemini gerçekleştirir"""
    global is_trading, is_running, last_trade_time
    menu_acik = False
    try:
        is_trading = True
        # Oyuncuya ticaret istegi gonder
        with running_lock:
            pass
        pyautogui.write('/ticaret ' + player_name, interval=0.05)
        time.sleep(3)

        print(CYAN, '[INFO] Ticaret menüsü kontrol ediliyor...')
        for i in range(0, 10):
            if not is_running:
                return False
            menu_acik = ticaret_menusu_acik_mi()
            if menu_acik:
                break
            time.sleep(1)
        if not menu_acik:
            print(YELLOW, '[UYARI] Ticaret menüsü açılmadı, yine de devam ediliyor...')
            print(YELLOW, '[UYARI] Ticaret menüsü açılmadı, devam ediliyor...')

        # Set item'larini ticaret ekranina koy
        try:
            placed, total = set_koy()
            if placed == 0:
                print(RED, "[HATA] Set item'lari konulamadi, ticaret reddediliyor.")
                print(CYAN, '[INFO] Ticaret iptal ediliyor...')
                pyautogui.moveTo(CANCEL_BUTTON[0], CANCEL_BUTTON[1], duration=0.3)
                time.sleep(0.3)
                return False
        except Exception as e:
            print(RED, "[HATA] Set item'lari konulamadi, ticaret reddediliyor.")
            print(CYAN, '[INFO] Ticaret iptal ediliyor...')
            pyautogui.moveTo(CANCEL_BUTTON[0], CANCEL_BUTTON[1], duration=0.3)
            time.sleep(0.3)
            return False

        print(CYAN, '[INFO] 2 saniye bekleniyor...')
        time.sleep(2)

        if chest_enabled:
            print(CYAN, '[INFO] /chest yazıldı, 2 saniye bekleniyor...')
            try:
                chest_ten_item_al(chest_already_open=False)
                print(GREEN, "[OK] Chest'ten item alındı ve chest kapatıldı, reklama devam ediliyor ve ticaret isteği bekleniyor...")
            except Exception as e:
                print(YELLOW, "[UYARI] Chest'ten item alınamadı, reklama devam ediliyor...")
        else:
            print(YELLOW, '[UYARI] Chest yenileme kapalı, reklama devam ediliyor...')

        # Para kontrolü
        print(GREEN, "[OK] Item'lar başarıyla konuldu, para kontrolüne geçiliyor...")
        print(CYAN, '[INFO] Para kontrolü başlatılıyor... (İstenen: ' + str(requested_amount) + ')')

        try:
            para_okunan = ocr_final_v3()
            try:
                para_miktar = int(para_okunan)
            except Exception:
                para_miktar = 0
            start_time = time.time()
            print(CYAN, ' (İstenen: ' + str(requested_amount) + ')')
            if para_miktar >= requested_amount:
                print(GREEN, '[OK] Para yeterli! (' + str(para_miktar) + ' >= ' + str(requested_amount) + ')')
                para_yeterli = True
            else:
                print(YELLOW, '[UYARI] Para yetersiz! (' + str(para_miktar) + ' < ' + str(requested_amount) + ')')
                para_yeterli = False

            if para_yeterli:
                print(GREEN, str(para_miktar) + ') - Ticaret kabul ediliyor...')
                pyautogui.moveTo(ACCEPT_BUTTON[0], ACCEPT_BUTTON[1], duration=0.2)
                last_trade_time = time.time()
                return True
            else:
                print(YELLOW, str(para_miktar) + ') - Ticaret iptal ediliyor...')
                pyautogui.moveTo(CANCEL_BUTTON[0], CANCEL_BUTTON[1], duration=0.2)
                return False
        except Exception as e:
            print(RED, '[HATA] Para okuma hatası: ' + str(e))
            traceback.print_exc()
            pyautogui.moveTo(CANCEL_BUTTON[0], CANCEL_BUTTON[1], duration=0.2)
            return False
    except Exception as e:
        print(RED, '[HATA] Item koyma sonrası hata: ' + str(e))
        traceback.print_exc()
        return False
    finally:
        is_trading = False


# ===========================================================================
# send_advertisement - Surekli reklam mesaji gonderir
# ===========================================================================
def send_advertisement():
    """Sürekli reklam mesajı gönderir"""
    global is_sending_ad, is_running
    is_sending_ad = True
    try:
        while is_running:
            try:
                with running_lock:
                    pass
                time.sleep(AD_INTERVAL_DEFAULT)
                if not is_running:
                    break
                with running_lock:
                    pass
                if is_trading:
                    time.sleep(1)
                    continue
                pyautogui.press('t')
                time.sleep(0.5)
                pyautogui.typewrite(ad_message, interval=0.05)
                time.sleep(0.2)
                pyautogui.press('enter')
                time.sleep(1)
            except Exception:
                time.sleep(1)
    finally:
        is_sending_ad = False


# ===========================================================================
# trade_monitor - Log dosyasini takip eder ve ticaret isteklerini isler
# ===========================================================================
def trade_monitor():
    """Log dosyasını takip eder ve ticaret isteklerini işler"""
    global is_running, last_trade_time
    try:
        # Baslangicta log dosyasinin sonuna konumlan
        try:
            with open(LOG_FILE, 'r', encoding='utf-8', errors='ignore') as f:
                f.seek(0, io.SEEK_END)
                last_file_position = f.tell()
        except Exception as e:
            print(RED, '[HATA] Log dosyasi pozisyon hatasi: ' + str(e))

        while is_running:
            try:
                current_time = time.time()
                time_since_trade = current_time - last_trade_time
                new_lines = read_new_lines()
                for line in new_lines:
                    if not is_running:
                        break
                    player_name = parse_trade_request(line)
                    if player_name:
                        print(GREEN, '[OK] Ticaret istegi bulundu: ' + player_name)
                        if time_since_trade < TRADE_COOLDOWN:
                            continue
                        process_trade(player_name)
                time.sleep(0.5)
            except Exception as e:
                print(RED, '[HATA] trade_monitor: ' + str(e))
                traceback.print_exc()
                time.sleep(1)
    except Exception as e:
        print(RED, '[HATA] trade_monitor dis: ' + str(e))
        traceback.print_exc()


# ===========================================================================
# on_press - F8 tusu ile botu baslatir/durdurur
# ===========================================================================
def on_press(key):
    """F8 tusuna basildiginda botu baslatir veya durdurur"""
    global is_running, selected_set, ITEM_FILES, ITEMS_TO_PLACE
    global requested_amount, ad_message, chest_enabled
    global trade_thread, ad_thread

    if key != keyboard.Key.f8:
        return

    if not is_running:
        print(CYAN, '[BASLAT] F8 basildi - Bot baslatiliyor...')

        gui_set = os.environ.get('TRADE_SET', '')
        gui_price = os.environ.get('TRADE_PRICE', '')
        gui_message = os.environ.get('TRADE_MESSAGE', '')
        gui_chest = os.environ.get('TRADE_CHEST', '0')

        if gui_set:
            print(GREEN, "[OK] GUI'den gelen ayarlar kullaniliyor:")
            print(GREEN, '[OK] Set: ' + SET_OPTIONS.get(gui_set, {}).get('name', gui_set))
            print(GREEN, '[OK] Fiyat: ' + gui_price)
            print(GREEN, '[OK] Mesaj: ' + gui_message)
            print(GREEN, '[OK] Chest Yenileme: ' + ('Açık' if gui_chest == '1' else 'Kapalı'))
            set_choice = gui_set
        else:
            print(GREEN, '[OK] Ayarlar zaten yuklendi:')
            print('\n[SET SECIMI]')
            print('1. Tit Set')
            print('2. Dia Set')
            print('3. Duel Kiti')
            set_choice = input('[SORU] Satılacak seti seçin (1/2/3): ').strip()
            if set_choice not in ('1', '2', '3'):
                print(YELLOW, '[UYARI] Gecersiz secim, varsayilan Tit Set kullaniliyor.')
                set_choice = '1'
            amount_input = input('[SORU] İstenen para miktarını girin: ').strip()
            try:
                requested_amount = int(amount_input)
            except Exception:
                requested_amount = 0
            ad_message = input('[SORU] Reklam mesajını girin: ').strip()
            if not gui_price:
                gui_price = str(requested_amount)
            if not gui_message:
                gui_message = ad_message
            gui_chest = '0'

        selected_set = set_choice
        ITEMS_TO_PLACE = SET_OPTIONS[selected_set]['items_to_place']
        ITEM_FILES = SET_OPTIONS[selected_set]['items']
        try:
            requested_amount = int(gui_price) if gui_price else requested_amount
        except Exception:
            pass
        if gui_message:
            ad_message = gui_message
        chest_enabled = (gui_chest == '1')

        print(GREEN, '[OK] Secilen set: ' + SET_OPTIONS[selected_set]['name'])

        is_running = True
        trade_thread = threading.Thread(target=trade_monitor, daemon=True)
        trade_thread.start()
        ad_thread = threading.Thread(target=send_advertisement, daemon=True)
        ad_thread.start()
    else:
        print(YELLOW, '[DURDUR] F8 basildi - Bot durduruluyor ve script kapatılıyor...')
        is_running = False
        try:
            if trade_thread is not None and trade_thread.is_alive():
                trade_thread.join(timeout=2.0)
        except Exception:
            pass
        try:
            if ad_thread is not None and ad_thread.is_alive():
                ad_thread.join(timeout=2.0)
        except Exception:
            pass
        print(RED, '[KAPAT] Script kapatılıyor...')
        sys.exit(0)


# ===========================================================================
# keyboard_listener - pynput keyboard Listener'i baslatir
# ===========================================================================
def keyboard_listener():
    """keyboard.Listener baslatir ve join eder"""
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()


# ===========================================================================
# run - Programin giris noktasi
# ===========================================================================
def run():
    """Programin giris noktasi"""
    print(CYAN, '[INFO] Ticaret Botu')
    print(CYAN, '[INFO] F8 tusuna basarak botu baslatabilir/durdurebilirsiniz...')

    gui_set = os.environ.get('TRADE_SET', '')
    gui_price = os.environ.get('TRADE_PRICE', '')
    gui_message = os.environ.get('TRADE_MESSAGE', '')

    if gui_set and gui_price:
        print(GREEN, "[OK] GUI'den gelen ayarlar yuklendi: Set=" + gui_set + ', Fiyat=' + gui_price
              + ', Chest=' + os.environ.get('TRADE_CHEST', '0'))

    print(CYAN, "[INFO] Program calisiyor, F8'ye basin...")

    kb_thread = threading.Thread(target=keyboard_listener, daemon=True)
    kb_thread.start()
    kb_thread.join()


if __name__ == '__main__':
    run()
