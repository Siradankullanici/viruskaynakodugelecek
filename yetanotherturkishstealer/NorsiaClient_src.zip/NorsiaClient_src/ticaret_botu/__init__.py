"""ticaret_botu paketi - Ticaret botu."""
