"""
Norsia Client - Ana Başlatma Dosyası
"""
import sys
import multiprocessing
import traceback
from PySide6.QtWidgets import QApplication


def main():
    """Ana fonksiyon"""
    # Bot başlatma hatası: ''
    if len(sys.argv) >= 2 and sys.argv[1] == '--run-bot':
        # Bot başlatma modu
        import bot_dispatcher
        bot_name = sys.argv[2]
        args = sys.argv[3:]
        try:
            bot_dispatcher.run_bot(bot_name, args)
        except SystemExit:
            raise
        except Exception as e:
            print('Bot başlatma hatası: ', e)
            return
        return

    # Normal GUI modu - Başarılı girişten sonra ana GUI'yi aç
    app = QApplication(sys.argv)

    def on_login_success(user_data):
        """Başarılı girişten sonra ana GUI'yi aç"""
        from gui import ModernGUI
        from login_gui import LoginGUI
        main_window = ModernGUI()
        if user_data and isinstance(user_data, dict):
            main_window.expires_at = user_data.get('expires_at')
        main_window.update_window_title()
        main_window.show()
        login_window.close()

    from login_gui import LoginGUI
    login_window = LoginGUI()
    login_window.set_success_callback(on_login_success)
    login_window.show()
    app.exec()


if __name__ == '__main__':
    multiprocessing.freeze_support()
    try:
        main()
    except Exception as e:
        with open('crash_log.txt', 'w', encoding='utf-8') as f:
            f.write('CRITICAL ERROR: ' + str(e) + '\n')
            f.write(traceback.format_exc())
        traceback.print_exc()
        input('Press Enter to exit...')
