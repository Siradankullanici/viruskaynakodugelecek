[bits 16]
[org 0x7c00]

main:
	call clear_screen
	mov ax, cs
	mov ds, ax
	mov si, msg
	
	push ax
	cld
	
	.print_loop:
		lodsb
		or al, al
		je .end
		call .check
		inc word [calc]
		jmp .print_loop
		
	.check:
		cmp word [calc], 11
		je delay_struct.set_delay
	
		cmp word [calc], 20
		je .stage2
		
		cmp word [delay], 1
		jne .printchar
		je .printdelaychar
	ret

	.delay_second:
		mov cx, 30
		mov dx, 10
		mov ah, 86h
		int 15h
	ret
	
	.printdelaychar:
		call .delay_second
		mov ah, 0EH
		int 10h
	ret
		
	.printchar:
		mov ah, 0EH
		int 10h
	ret
  
	.stage2:
		call clear_screen
		call delay_struct.remove_delay
		mov ah, 0x06
		mov al, 0x01
		mov bh, 0xF0
		mov ch, 0
		xor cl, cl
		mov dh, 0
		mov dl, 32
		int 0x10
	ret
	
	.end:
		pop ax
	ret
ret

delay_struct:
	.set_delay:
		mov word [delay], 1
	ret
	.remove_delay:
		mov word [delay], 0
	ret
ret

	
clear_screen:
	mov ax, 0x2
	int 10h

	mov ah, 0x06
	xor al, al
	xor cx, cx
	mov dx, 0x184f
	mov bh, 0x0F
	int 10h
ret

; data labels
calc: dw 0
delay: dw 0
msg: db "Please wait..........You just got OIETIFed. Game Over!", 13, 10, 13, 10, "DEATH> ", 0
	
times 510 - ($ - $$) db 0
dw 0xAA55 ; signature